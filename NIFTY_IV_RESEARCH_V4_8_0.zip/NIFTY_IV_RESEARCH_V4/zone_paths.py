#!/usr/bin/env python3
"""Path engine: simulate every possible trade ONCE and record its whole bar-by-bar life, so that every exit rule
(take-profit x stop-loss, see zone_grid.py) can be applied afterwards exactly, without re-simulating.

A path is (signal bar, side, structure, strike offset). It runs from its entry fill to its natural end:
  zone change (all structures); naked short: expiry (cash settled on the 15:00-15:29 spot TWAP);
  calendar: at 15:15 on the short expiry, or when the long reaches 30 days, the pair is closed and a new pair opened
  at the current index while the zone holds; futures_zone: zone change only; futures_expiry: also the nearest
  expiry at least --min-short-days away.
At every 45-minute bar close of its life the path stores (all in rupees at --lots):
  cash_total  cash flows so far (entries, roll exits, roll re-entries)
  cash_pair   cash flows of the pair now held (base for take-profit and premium stops)
  base        credit (naked) or debit (calendar) of the pair now held
  value       bar-close value of the open legs if every leg printed with volume in the bar's last minute, else NaN
  mark        cash_total plus open legs at their latest known close (boundary valuation, daily mark-to-market)
  exit_cash   cash from closing everything if the exit is decided at this bar close (minute fills, see below)
  exit_bar    bar whose following minutes completed that exit (a later signal can only be taken after it)
  exit_day    day of the last exit fill (date ordinal); exit_forced: a long was booked at a modelled price
  roll        1 on a calendar roll bar (a take-profit cannot fire there; a stop can, and then no new pair opens)
  forced_before  number of earlier roll exits in this path that needed a forced long booking
A roll exit that spills past its bar (thin long) completes first; the new pair opens on the bar it completed if the
zone still holds (as zone_backtest.py does); bars in between hold no legs. If the zone changes meanwhile, no new pair
opens and the path ends when the old pair's last fill happens.
Bar convention: a decision at bar k fills in the minutes after bar k's close. end_bar / exit_bar = the bar after whose
close the last fill happens (it holds the one-position lock); end_fill_day = the date of that last fill.

Fills (decided at a bar close, executed in the next bar's minutes; 09:15-09:59 next session after the last bar):
  every leg is sliced minute by minute, taking at most --max-participation of that minute's traded volume, in whole
  lots, at the minute's (open+high+low+close)/4; slippage (tenor and volume scaled) and dated statutory charges are
  applied to each leg's total. An entry must complete inside its bar, or it is not taken. An exit buys shorts back
  before selling longs; whatever is left carries into later bars; a short reaching expiry settles; a long still open
  --max-exit-lag-bars after its shorts are gone is booked at its last close less --forced-exit-haircut (flagged).
  A minute's own volume is used for that minute (user's decision).
Futures paths use NIFTY spot minutes as the price (no futures volume or basis data): first minute open of the next bar
  plus --slippage-points, dated futures charges.
"""
from __future__ import annotations
import argparse,collections,datetime as dt,json,math,os,sqlite3,sys,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from calendar_research import fill_detail,hedge_cost
from contract_specs_v2 import LotMaster
import zone_signals as zs
import zone_backtest as zb

OPTION_STRUCTURES=('naked','calendar');FUTURES_STRUCTURES=('futures_zone','futures_expiry')
FLOATS=('cash_total','cash_pair','base','value','mark','exit_cash')
INTS=('exit_bar','exit_day','exit_forced','roll','forced_before')
def ordinal(day):return dt.date.fromisoformat(day).toordinal()

def pack(rows):
    return b''.join([np.asarray(rows[n],dtype=np.float64).tobytes() for n in FLOATS]+[np.asarray(rows[n],dtype=np.int64).tobytes() for n in INTS])

def unpack(blob,n):
    out={};pos=0
    for name in FLOATS:out[name]=np.frombuffer(blob,dtype=np.float64,count=n,offset=pos);pos+=8*n
    for name in INTS:out[name]=np.frombuffer(blob,dtype=np.int64,count=n,offset=pos);pos+=8*n
    return out

class Path_:
    __slots__=('side','structure','offset','signal_bar','colour','lot','units','held','entry_px','short','long','cash_total','cash_pair','base','rows','head','pairs','wait','forced_rolls','pend','cancel','unwind')
    def __init__(self,**kw):
        for k,v in kw.items():setattr(self,k,v)

NMIN=zs.CLOSE-zs.OPEN   # minutes 09:15..15:29

class DayArrays:
    """One session of the extraction as numpy arrays per contract: fill price (O+H+L+C)/4 (open if a field is missing),
    close and volume by minute index; a minute is tradable when open > 0 and volume > 0."""
    __slots__=('px','close','vol')
    def __init__(self,day_dict):
        acc={}
        for minute,quotes in day_dict.items():
            i=zs.minute_of(minute)-zs.OPEN
            if not 0<=i<NMIN:continue
            for key,(o,h,l,c,v,_) in quotes.items():
                a=acc.get(key)
                if a is None:a=acc[key]=np.zeros((4,NMIN))
                o=o or 0.;v=v or 0
                ohlc=(o,h or 0.,l or 0.,c or 0.)
                a[0,i]=sum(ohlc)/4 if all(x>0 for x in ohlc) else o
                a[1,i]=c or 0.;a[2,i]=v;a[3,i]=1. if (o>0 and v>0) else 0.
        self.px={k:a[0] for k,a in acc.items()};self.close={k:a[1] for k,a in acc.items()}
        self.vol={k:np.where(a[3]>0,a[2],0.) for k,a in acc.items()}

def load_day(db,day):
    """DayArrays straight from the extraction: one SQL read, numpy throughout. Where both vendors printed a minute, the
    one with more volume is kept (ties: the first row read), exactly as zone_backtest.Market.day does."""
    rows=db.execute('SELECT minute,expiry,strike,cp,COALESCE(open,0),COALESCE(high,0),COALESCE(low,0),COALESCE(close,0),COALESCE(volume,0) FROM opt_1m WHERE day=? ORDER BY provider,minute',(day,)).fetchall()
    d=DayArrays.__new__(DayArrays)
    if not rows:d.px={};d.close={};d.vol={};return d
    minute,e,k,cp,o,h,l,c,v=zip(*rows);kid={}
    ids=np.fromiter((kid.setdefault((x,float(y),z),len(kid)) for x,y,z in zip(e,k,cp)),np.int64,len(rows))
    mi=np.fromiter(((int(m[:2])*60+int(m[3:5]))-zs.OPEN for m in minute),np.int64,len(rows))
    o,h,l,c,v=(np.asarray(x,dtype=float) for x in (o,h,l,c,v))
    keep=(mi>=0)&(mi<NMIN);order=np.lexsort((np.arange(len(rows)),-v,mi,ids))
    order=order[keep[order]];first=np.ones(len(order),bool);first[1:]=(ids[order][1:]!=ids[order][:-1])|(mi[order][1:]!=mi[order][:-1])
    r=order[first];K=len(kid);px=np.zeros((K,NMIN));cl=np.zeros((K,NMIN));vo=np.zeros((K,NMIN))
    allpos=(o[r]>0)&(h[r]>0)&(l[r]>0)&(c[r]>0)
    px[ids[r],mi[r]]=np.where(allpos,(o[r]+h[r]+l[r]+c[r])/4,o[r]);cl[ids[r],mi[r]]=c[r]
    vo[ids[r],mi[r]]=np.where((o[r]>0)&(v[r]>0),v[r],0.)
    d.px={key:px[i] for key,i in kid.items()};d.close={key:cl[i] for key,i in kid.items()};d.vol={key:vo[i] for key,i in kid.items()}
    return d

class PathSim:
    def __init__(self,market,bars,final,cfg,minutes=None,cache_days=12):
        self.m=market;self.bars=bars;self.final=final;self.cfg=cfg;self.lots=LotMaster(cfg.contract_master);self.counts=collections.Counter()
        self.spot={}
        for d,rows in (minutes or {}).items():
            a=np.full(NMIN,np.nan)
            for m,o,h,l,c in rows:
                if 0<=m-zs.OPEN<NMIN and o:a[m-zs.OPEN]=o
            self.spot[d]=a
        self.lc={};self.memo={};self.done=[];self.live=[];self.days=collections.OrderedDict();self.cache_days=cache_days
    def arrays(self,day):
        d=self.days.get(day)
        if d is None:
            d=self.days[day]=load_day(self.m.db,day) if hasattr(self.m,'db') else DayArrays(self.m.day(day))
            while len(self.days)>self.cache_days:self.days.popitem(last=False)
        return d
    def window(self,k):
        """(day, first minute index, end minute index) of the bar after k, where a decision at bar k's close fills."""
        b=self.bars[k]
        if b.end<zs.CLOSE:return b.day,b.end-zs.OPEN,min(b.end+45,zs.CLOSE)-zs.OPEN
        return (self.bars[k+1].day,0,45) if k+1<len(self.bars) else None
    def key(self,c):return (c[0],float(c[1]),c[2])
    def mark(self,day,minute,c):
        """(close, volume) at a minute, zeros if absent."""
        d=self.arrays(day);k=self.key(c);i=zs.minute_of(minute)-zs.OPEN
        cl=d.close.get(k)
        return (cl[i],d.vol[k][i]) if cl is not None else (0.,0.)
    def extracted(self,day,c):
        """Whether the contract has any minute that day in the extraction (False: a data gap, not illiquidity)."""
        return self.key(c) in self.arrays(day).px
    def slice(self,day,i0,i1,c,want,lot):
        """Trade up to `want` units of c over minutes [i0,i1): each minute at most --max-participation of its volume, whole lots.
        Returns (units, notional, volume used, index of the minute the last unit traded or None)."""
        d=self.arrays(day);k=self.key(c);px=d.px.get(k)
        if px is None or i0>=i1 or want<=0:return 0,0.,0.,None
        vol=d.vol[k][i0:i1];cap=np.floor(vol*self.cfg.max_participation)//lot*lot;cs=np.cumsum(cap)
        total=int(cs[-1])
        if total<=0:return 0,0.,0.,None
        if total<want:j=int(np.flatnonzero(cap)[-1]);taken=cap
        else:
            j=int(np.searchsorted(cs,want));taken=cap[:j+1].copy();taken[j]=want-(cs[j-1] if j else 0.)
        n=int(taken.sum());p=px[i0:i0+len(taken)]
        return n,float(taken@p),float(vol[:len(taken)][taken>0].sum()),i0+j
    def book(self,acc,c,trade_sign,lot):
        notional,qty,vol,day=acc
        if not qty:return 0.
        cash,_,_,_=fill_detail(notional/qty,trade_sign*qty,day,self.cfg,c[0],vol/lot,None,None,lot)
        return cash
    def settle_px(self,c):
        ref=self.m.settlement(c[0])
        if ref is None:return None
        s=ref[0];return max(0.,s-c[1]) if c[2]=='CE' else max(0.,c[1]-s)
    def last_close(self,c,k,t):
        """Latest bar-close price of c at or before bar t, known from bar k's state plus bars k+1..t."""
        for j in range(t,k,-1):
            b=self.bars[j];cl,_=self.mark(b.day,b.mark_minute,c)
            if cl:return cl
        return self.lc.get(c)
    # ---------- entry ----------
    def enter(self,k,legs,lot,start=None):
        """legs: [(contract, signed units)], all to complete inside the next bar, from minute index `start` if given
        (after an exit that used earlier minutes of the same bar). Returns dict(status='ok'|'none'|'partial', ...).
        partial: some legs completed and some did not; the completed legs are a real position (see Path_.unwind)."""
        w=self.window(k)
        if w is None:return dict(status='none')
        day,i0,i1=w;i0=max(i0,start) if start is not None else i0;cash=0.;px={};filled=[];last=i0
        for c,u in legs:
            n,notional,vol,j=self.slice(day,i0,i1,c,abs(u),lot)
            if n>=abs(u):cash+=self.book([notional,n,vol,day],c,1 if u>0 else -1,lot);px[c]=notional/n;last=max(last,j);filled.append((c,u))
        if not filled:return dict(status='none')
        out=dict(cash=cash,px=px,day=day,ix=self.index_at(day,i0,last+1),filled=tuple(filled))
        return dict(out,status='ok' if len(filled)==len(legs) else 'partial')
    def index_at(self,day,i0,i1):
        """Spot at the last printed minute in [i0,i1) (the minute the entry completed), NaN if none."""
        a=self.spot.get(day)
        if a is None:return math.nan
        ok=np.flatnonzero(~np.isnan(a[i0:i1]));return float(a[i0+ok[-1]]) if len(ok) else math.nan
    # ---------- exit, memoised on (held, bar) ----------
    def exit(self,held,k,lot):
        key=(held,k,lot)
        if key in self.memo:return self.memo[key]
        rem={c:u for c,u in held};acc={c:[0.,0,0.,None] for c,_ in held};cash=0.;last=self.bars[k].day;forced=False;pending=0;t=k;ok=True;lastt=None
        sched=collections.defaultdict(float);legq={c:[] for c,_ in held};rems=[];lastmin=-1   # cash known by each bar close; remaining legs after each bar
        while rem:
            if t>=len(self.bars):ok=None;t-=1;break                          # data ran out: no value, path stays open
            b=self.bars[t]
            for c in list(rem):
                if c[0]<b.day or (c[0]==b.day and b.end==zs.CLOSE):
                    px=self.settle_px(c)
                    if px is None:ok=None if c[0]>self.bars[-1].day else False;break   # False: settlement price missing
                    x=rem.pop(c)*px;cash+=x;sched[t]+=x;last=max(last,c[0])
            if not ok:break
            w=self.window(t)
            if rem and w:
                day,i0,i1=w;start=i0;shorts_done=True
                for c in [c for c,u in rem.items() if u<0 and c[0]>=day]:          # shorts first, from the first minute
                    n,notional,vol,j=self.slice(day,i0,i1,c,-rem[c],lot)
                    if n:a=acc[c];a[0]+=notional;a[1]+=n;a[2]+=vol;a[3]=a[3] or day;last=max(last,day);rem[c]+=n;legq[c].append((t+1,n));lastmin=max(lastmin if lastt==t else -1,j);lastt=t
                    if rem[c]==0:del rem[c];start=max(start,j)
                    else:shorts_done=False
                if shorts_done and not any(u<0 for u in rem.values()):                # longs from the minute the last short finished
                    for c in [c for c,u in rem.items() if u>0 and c[0]>=day]:
                        n,notional,vol,j=self.slice(day,start,i1,c,rem[c],lot)
                        if n:a=acc[c];a[0]+=notional;a[1]+=n;a[2]+=vol;a[3]=a[3] or day;last=max(last,day);rem[c]-=n;legq[c].append((t+1,n));lastmin=max(lastmin if lastt==t else -1,j);lastt=t
                        if rem[c]==0:del rem[c]
            rems.append((t+1,tuple(rem.items())))
            if not rem:break
            pending+=1
            if 0<=self.cfg.max_exit_lag_bars<pending and not any(u<0 for u in rem.values()):
                for c in list(rem):
                    px=self.last_close(c,k,t)
                    if px is None:continue
                    x=rem.pop(c)*px*(1-self.cfg.forced_exit_haircut);cash+=x;sched[t+1]+=x;forced=True
                rems.append((t+1,tuple(rem.items())))
                if not rem:break
            t+=1
        for c,u in held:
            x=self.book(acc[c],c,1 if u<0 else -1,lot);cash+=x;q=acc[c][1]
            for bar,n in legq[c]:sched[bar]+=x*n/q                  # a leg's booked cash, spread over the bars its fills happened in
        if lastt!=t:lastmin=-1                                   # finished by settlement or forced booking: no minute used in bar t's window
        out=(cash if ok else math.nan,t,ordinal(last),forced,ok,tuple(sorted(sched.items())),tuple(rems),lastmin)   # ok: True, False (unresolved) or None (data end)
        self.memo[key]=out;return out
    # ---------- option pairs ----------
    def open_pair(self,k,side,structure,offset,start=None):
        b=self.bars[k];cp='PE' if side=='bull' else 'CE';strike=float(round(b.close/100)*100+offset);w=self.window(k)
        if w is None:return None,'no_next_bar'
        day=w[0];exps=self.m.expiries(b.day,b.mark_minute)
        short=next((e for e in exps if zb.days_between(day,e)>=self.cfg.min_short_days),None)
        if short is None:return None,'no_short_expiry'
        lot=self.lots.get(day,short).qty
        if not lot:return None,'lot_unknown'
        units=lot*self.cfg.lots;legs=[((short,strike,cp),-units)];long=None
        if structure=='calendar':
            far=[e for e in exps if e>short and zb.days_between(day,e)>30]
            if not far:return None,'no_long_expiry'
            long=min(far,key=lambda e:(abs(zb.days_between(day,e)-self.cfg.long_target),e))
            if self.lots.get(day,long).qty!=lot:return None,'lot_mismatch'
            legs.append(((long,strike,cp),units))
        r=self.enter(k,legs,lot,start)
        if r['status']=='none':return None,'no_liquid_entry' if all(self.extracted(day,c) for c,_ in legs) else 'not_extracted'
        for c,p in r['px'].items():self.lc[c]=p
        partial=r['status']=='partial'
        if partial:self.counts['partial_entry_'+('short_filled' if r['filled'][0][1]<0 else 'long_filled')]+=1
        cash=r['cash'];base=math.nan if partial else cash if structure=='naked' else -cash
        return dict(held=r['filled'],px=r['px'],lot=lot,units=units,short=short,long=long,day=r['day'],cash=cash,base=base,strike=strike,entry_index=r['ix'],
                    partial=partial,short_px=r['px'].get(legs[0][0],math.nan)),None
    def start(self,t,side,structure,offset):
        pair,why=self.open_pair(t,side,structure,offset)
        if pair is None:self.counts['reject_'+why]+=1;self.done.append(dict(side=side,structure=structure,offset=offset,signal_bar=t,status='no_fill',reason=why));return
        p=Path_(side=side,structure=structure,offset=offset,signal_bar=t,colour='G' if side=='bull' else 'R',lot=pair['lot'],units=pair['units'],held=pair['held'],entry_px=pair['px'],
                short=pair['short'],long=pair['long'],cash_total=pair['cash'],cash_pair=pair['cash'],base=pair['base'],rows=collections.defaultdict(list),pairs=1,wait=None,forced_rolls=0,pend=None,cancel=False,unwind=pair['partial'],
                head=dict(entry_day=pair['day'],lot=pair['lot'],units=pair['units'],short_expiry=pair['short'],long_expiry=pair['long'],strike=pair['strike'],entry_index=pair['entry_index'],entry_short_px=pair['short_px']))
        self.live.append(p)
    def record(self,p,vals,ints):
        for name,v in zip(FLOATS,vals):p.rows[name].append(v)
        for name,v in zip(INTS,ints+(p.forced_rolls,)):p.rows[name].append(v)
    def step(self,p,k):
        """Record bar k for a live option path. Returns True when the path has ended."""
        b=self.bars[k]
        if p.wait is not None:                                   # between pairs: the roll exit is still filling
            q=p.pend;asof=q['before']+sum(x for bar,x in q['sched'] if bar<=k)
            left=next((r for bar,r in reversed(q['rems']) if bar<=k),q['held']);stale=0.
            for c,u in left:
                cl,_=self.mark(b.day,b.mark_minute,c)
                if cl:self.lc[c]=cl
                stale+=u*self.lc.get(c,q['px'][c])
            # as of this close: cash already received plus legs still to sell at their last close; an exit decided now ends when the roll exit does
            self.record(p,(asof,0.,math.nan,math.nan,asof+stale,p.cash_total-asof),(max(k,p.wait),q['day'],int(q['forced']),0))
            if self.final[k]!=p.colour:p.cancel=True              # no new pair; the old one is still being sold
            if k<p.wait:return False
            if p.cancel:return self.finish(p,k,'zone_flip',p.cash_total)    # ends on the bar its last fill completes
            return self.reopen(p,k,q['lastmin']+1 if self.cfg.roll_entry_after_exit else None)
        value=0.;fresh=True;stale=0.
        for c,u in p.held:
            cl,v=self.mark(b.day,b.mark_minute,c)
            if cl:self.lc[c]=cl
            if not cl or not v:fresh=False
            else:value+=u*cl
            stale+=u*self.lc.get(c,p.entry_px[c])
        end=None
        if self.final[k]!=p.colour:end='zone_flip'
        elif p.structure=='naked' and (b.day>p.short or (b.day==p.short and b.end==zs.CLOSE)):end='expiry'
        roll=p.structure=='calendar' and end is None and ((b.day>=p.short and (b.end>=zb.ROLL_BAR_END or b.day>p.short)) or zb.days_between(b.day,p.long)<=30)
        x_cash,x_bar,x_day,x_forced,ok,sched,rems,lastmin=self.exit(p.held,k,p.lot)
        mark=p.cash_total+stale
        self.record(p,(p.cash_total,p.cash_pair,p.base,value if fresh else math.nan,mark,x_cash),(x_bar,x_day,int(x_forced),int(bool(roll))))
        if p.unwind:end=('roll_reopen_' if p.pairs>1 else '')+'partial_entry_unwound'   # one leg filled, the other not: sell it back at once
        if ok is False:return self.finish(p,k,'unresolved',math.nan)
        if ok is None and (end or roll):return self.finish(p,k,'open_at_data_end',mark)
        if end:return self.finish(p,k,end,p.cash_total+x_cash)
        if roll:
            p.pend=dict(before=p.cash_total,sched=sched,rems=rems,held=p.held,px=p.entry_px,day=x_day,forced=x_forced,lastmin=lastmin)
            p.cash_total+=x_cash;p.held=();p.cash_pair=0.;p.base=math.nan;p.forced_rolls+=int(x_forced)
            if x_bar==k:return self.reopen(p,k,lastmin+1 if self.cfg.roll_entry_after_exit else None)   # the new pair fills only after the old pair's last exit minute
            p.wait=x_bar;self.counts['roll_exit_spilled']+=1
        return False
    def reopen(self,p,k,start=None):
        p.wait=None;new,why=self.open_pair(k,p.side,p.structure,p.offset,start if start and start>0 else None)
        if new is None:self.counts['roll_reopen_'+why]+=1;return self.finish(p,k,'roll_reopen_failed',p.cash_total)
        p.cash_total+=new['cash'];p.cash_pair=new['cash'];p.base=new['base'];p.held=new['held'];p.entry_px=new['px'];p.short=new['short'];p.long=new['long'];p.pairs+=1
        p.unwind=new['partial']
        return False
    def finish(self,p,k,reason,pnl):
        status='closed' if reason not in ('open_at_data_end','unresolved') else reason
        last=p.rows['exit_day'][-1] if p.rows['exit_day'] else None
        self.done.append(dict(p.head,side=p.side,structure=p.structure,offset=p.offset,signal_bar=p.signal_bar,status=status,reason=reason,pairs=p.pairs,
                              first_bar=p.signal_bar+1,end_bar=k,end_pnl=pnl,end_fill_day=dt.date.fromordinal(int(last)).isoformat() if last and last<10**8 else None,rows=p.rows))
        self.counts['end_'+reason]+=1;return True
    # ---------- futures (spot price proxy) ----------
    def fut_fill(self,k):
        w=self.window(k)
        if w is None:return None
        day,i0,i1=w;a=self.spot.get(day)
        if a is None:return None
        seg=a[i0:i1];ok=np.flatnonzero(~np.isnan(seg))
        return (day,float(seg[ok[0]])) if len(ok) else None
    def fut_exit(self,k):
        """First executable exit for a decision at bar k: the next bar with a spot print, however late. None: data ran out."""
        for t in range(k,len(self.bars)):
            f=self.fut_fill(t)
            if f:return f[0],f[1],t
        return None
    def fut_cost(self,units,price,day):return hedge_cost(units,price,day,self.cfg)+abs(units)*self.cfg.slippage_points
    def futures_path(self,t,side,horizon):
        f=self.fut_fill(t);b=self.bars[t]
        if f is None:return self.done.append(dict(side=side,structure=horizon,offset=0.,signal_bar=t,status='no_fill',reason='no_next_bar'))
        day,px=f
        expiry=next((e for e in self.m.expiries(b.day,b.mark_minute) if zb.days_between(day,e)>=self.cfg.min_short_days),None)
        if horizon=='futures_expiry' and expiry is None:return self.done.append(dict(side=side,structure=horizon,offset=0.,signal_bar=t,status='no_fill',reason='no_short_expiry'))
        lot=self.lots.get(day,expiry or (dt.date.fromisoformat(day)+dt.timedelta(days=7)).isoformat()).qty
        if not lot:   # lot size not determinable (e.g. the mid-2021 transition): rejected, as zone_futures.py does
            self.counts['reject_futures_lot_unknown']+=1
            return self.done.append(dict(side=side,structure=horizon,offset=0.,signal_bar=t,status='no_fill',reason='lot_unknown'))
        units=lot*self.cfg.lots*(1 if side=='bull' else -1);cash=-units*px-self.fut_cost(units,px,day);colour='G' if side=='bull' else 'R'
        rows=collections.defaultdict(list);head=dict(entry_day=day,lot=lot,units=abs(units),short_expiry=expiry,long_expiry=None,strike=px,entry_index=px)
        for k in range(t+1,len(self.bars)):
            b=self.bars[k];value=units*b.close;end=None
            if self.final[k]!=colour:end='zone_flip'
            elif horizon=='futures_expiry' and (b.day>expiry or (b.day==expiry and b.end>=zb.ROLL_BAR_END)):end='expiry'
            f=self.fut_exit(k)
            if f:xd,xp,xb=f;x_cash=units*xp-self.fut_cost(-units,xp,xd)
            else:xd,x_cash,xb=self.bars[-1].day,math.nan,len(self.bars)-1          # no print before the data ends: no exit value
            for name,v in (('cash_total',cash),('cash_pair',cash),('base',math.nan),('value',value),('mark',cash+value),('exit_cash',x_cash)):rows[name].append(v)
            for name,v in (('exit_bar',xb),('exit_day',ordinal(xd)),('exit_forced',0),('roll',0),('forced_before',0)):rows[name].append(v)
            if end and not f:return self.done.append(dict(head,side=side,structure=horizon,offset=0.,signal_bar=t,status='open_at_data_end',reason='open_at_data_end',pairs=1,first_bar=t+1,end_bar=k,end_pnl=cash+value,rows=rows))
            if end:return self.done.append(dict(head,side=side,structure=horizon,offset=0.,signal_bar=t,status='closed',reason=end,pairs=1,first_bar=t+1,end_bar=k,end_pnl=cash+x_cash,rows=rows))
        self.done.append(dict(head,side=side,structure=horizon,offset=0.,signal_bar=t,status='open_at_data_end',reason='open_at_data_end',pairs=1,first_bar=t+1,end_bar=len(self.bars)-1,
                              end_pnl=rows['mark'][-1] if rows['mark'] else math.nan,rows=rows))
    # ---------- driver ----------
    def run(self,entries,structures,offsets,sink=None,progress=True):
        month=None;t0=time.time();n=0
        for k,b in enumerate(self.bars):
            nxt=[]
            for p in self.live:
                if not self.step(p,k):nxt.append(p)
            self.live=nxt
            for side in entries.get(k,()):
                for s in structures:
                    if s in FUTURES_STRUCTURES:self.futures_path(k,side,s);continue
                    for off in offsets:self.start(k,side,s,off)
            for key in [x for x in self.memo if x[1]<k]:del self.memo[key]
            if sink and self.done:n+=len(self.done);sink(self.done);self.done=[]
            if progress and b.day[:7]!=month:month=b.day[:7];print(f'{month} live paths {len(self.live)} stored {n} ({time.time()-t0:.0f}s)',flush=True)
        for p in self.live:
            if not p.rows['mark']:self.done.append(dict(side=p.side,structure=p.structure,offset=p.offset,signal_bar=p.signal_bar,status='no_fill',reason='no_bar_after_entry'));continue
            self.finish(p,len(self.bars)-1,'open_at_data_end',p.rows['mark'][-1])
        self.live=[]
        if sink and self.done:sink(self.done);self.done=[]

DDL='''CREATE TABLE meta(name TEXT PRIMARY KEY,value TEXT);
CREATE TABLE bars(idx INTEGER PRIMARY KEY,day TEXT,end_minute TEXT,open REAL,high REAL,low REAL,close REAL,zone TEXT);
CREATE TABLE signals(config TEXT,side TEXT,bar INTEGER);
CREATE TABLE paths(id INTEGER PRIMARY KEY,side TEXT,structure TEXT,offset REAL,signal_bar INTEGER,status TEXT,reason TEXT,entry_day TEXT,lot INTEGER,units INTEGER,
 short_expiry TEXT,long_expiry TEXT,strike REAL,pairs INTEGER,first_bar INTEGER,end_bar INTEGER,end_pnl REAL,entry_index REAL,entry_short_px REAL,end_fill_day TEXT,data BLOB);
CREATE INDEX paths_key ON paths(side,structure,offset,signal_bar);CREATE INDEX signals_cfg ON signals(config,side);'''
PATH_COLS=('side','structure','offset','signal_bar','status','reason','entry_day','lot','units','short_expiry','long_expiry','strike','pairs','first_bar','end_bar','end_pnl','entry_index','entry_short_px','end_fill_day')

def writer(db):
    def sink(rows):
        db.executemany(f'INSERT INTO paths({",".join(PATH_COLS)},data) VALUES({",".join("?"*(len(PATH_COLS)+1))})',
                       [tuple(r.get(c) for c in PATH_COLS)+(pack(r['rows']) if 'rows' in r else None,) for r in rows])
    return sink

def config(a):
    return SimpleNamespace(slippage=a.slippage,slippage_mode='tenor_volume',fill_model='sliced_minutes',brokerage=a.brokerage,gst=.18,exchange_bps=None,sebi_bps=.01,stt=None,stamp=.00003,
        brokerage_order_mode='per_lot_orders',lots=a.lots,max_participation=a.max_participation,min_short_days=a.min_short_days,long_target=a.long_target,contract_master=a.contract_master,
        max_exit_lag_bars=a.max_exit_lag_bars,forced_exit_haircut=a.forced_exit_haircut,hedge_bps=0.,hedge_statutory=True,slippage_points=a.slippage_points,
        roll_entry_after_exit=getattr(a,'roll_entry_after_exit',True))

def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter);zb.add_common(ap)
    ap.add_argument('--options',required=True,help='zone_options.sqlite from zone_contracts.py');ap.add_argument('--out',default='zone_paths.sqlite')
    ap.add_argument('--structures',default=','.join(OPTION_STRUCTURES+FUTURES_STRUCTURES))
    ap.add_argument('--slippage',type=float,default=.5);ap.add_argument('--brokerage',type=float,default=20.);ap.add_argument('--max-participation',type=float,default=.10)
    ap.add_argument('--max-exit-lag-bars',type=int,default=9);ap.add_argument('--forced-exit-haircut',type=float,default=.02)
    ap.add_argument('--slippage-points',type=float,default=1.,help='Futures: index points of slippage per unit per side')
    ap.add_argument('--cache-days',type=int,default=12,help='Option days kept in memory')
    ap.set_defaults(lots=10)
    a=ap.parse_args();a.offsets=zb.parse_offsets(a.offsets);structures=[s for s in a.structures.split(',') if s]
    bad=set(structures)-set(OPTION_STRUCTURES+FUTURES_STRUCTURES)
    if bad:sys.exit(f'Unknown structures {sorted(bad)}')
    market=zb.Market(a.options,a.spot,keep=2);planned=market.meta.get('plan',{})
    missing=sorted(set(a.offsets)-set(planned.get('offsets',zb.OFFSETS)))
    if missing:sys.exit(f'Offsets {missing} were not in the contract extraction (planned {planned.get("offsets")})')
    for key in ('min_short_days','long_target','from_date','to_date'):
        if key in planned and planned[key]!=getattr(a,key):sys.exit(f'--{key.replace("_","-")} differs from the contract extraction ({planned[key]})')
    minutes=zs.load_minutes(a.spot)
    if not minutes:sys.exit(f'No spot minutes in {a.spot}')
    bars,final,_=zs.zones(minutes);sig=zs.signal_grid(bars,final);entries=zb.entry_map(bars,sig,a.from_date,a.to_date)
    sim=PathSim(market,bars,final,config(a),minutes,cache_days=a.cache_days)
    tmp=a.out+'.building';Path(tmp).unlink(missing_ok=True)   # the previous good file stays until this build finishes
    db=sqlite3.connect(tmp);db.executescript(DDL)
    db.executemany('INSERT INTO bars VALUES(?,?,?,?,?,?,?,?)',[(i,b.day,zs.hhmm(b.end),b.open,b.high,b.low,b.close,final[i]) for i,b in enumerate(bars)])
    db.executemany('INSERT INTO signals VALUES(?,?,?)',[(c,side,t) for c,s in sig.items() for side in ('bull','bear') for t in s[side]])
    sink=writer(db);t0=time.time()
    sim.run(entries,structures,a.offsets,sink=lambda rows:(sink(rows),db.commit()))
    meta=dict(release=Path(__file__).with_name('VERSION.txt').read_text().strip(),args=vars(a),counts=dict(sim.counts),grid=zs.GRID,stale=zs.STALE,
              fill_model='sliced minutes: <= max participation of each minute, whole lots, (O+H+L+C)/4, slippage and charges on each leg total',seconds=round(time.time()-t0))
    db.executemany('INSERT INTO meta VALUES(?,?)',[(k,json.dumps(v,default=str)) for k,v in meta.items()]);db.commit()
    n=db.execute('SELECT COUNT(*),SUM(status="no_fill") FROM paths').fetchone();db.close();market.close();os.replace(tmp,a.out)
    print('Counts:',dict(sim.counts));print(f'{n[0]} paths ({n[1]} not filled) -> {a.out}')

if __name__=='__main__':main()
