#!/usr/bin/env python3
"""Exhaustive exit-rule grid over the stored paths (zone_paths.py): every signal configuration x side x structure x
strike offset x profit rule x stop rule, each one position at a time, scored on training windows, then selected and
walk-forwarded by year. Nothing is re-simulated: each rule's exit is read off the stored bar-by-bar path.

Profit rules (first bar close where true; then the exit fills in the next bar's minutes as stored):
  none; tpX   option pair P&L >= X of its credit (calendar: debit), on a bar where every leg printed (not a roll bar)
  targetPxM   index close moved M x ATR(P) in favour of the trade from the signal close (ATR on 45-minute bars, at the signal)
Stop rules:
  none; atrPxM   index close beyond signal close -/+ M x ATR(P) at the signal (the V4.6 stop is atrPx1)
  trailPxM  index close beyond the best close since the ENTRY FILL (index at the fill minute) -/+ M x ATR(P) now
  strailPxM the V4.7.0 variant: best close since the SIGNAL close (kept as a named reference)
  pctX      index close X% beyond the signal close
  lossX     option pair loss >= X of its credit (calendar: debit), on a bar where every leg printed
A rule that never fires leaves the path to its natural end (zone change, expiry, calendar roll chain end).
Futures paths have no premium, so tpX and lossX are not applied to them.

Per configuration and window it stores n, total (points per unit, after costs at the paths' lot size), wins and the
sum of squares, in one .npz per (side, structure, offset), so every combination can be inspected later.
Windows: train_YYYY = [--start, YYYY-01-01); train_full = [--start, --split); test_YYYY = [YYYY, YYYY+1).
An entry inside a window whose exit falls after the window end is valued at the last bar close before it (hypothetical).

Selection, the same as zone_report.py: per (configuration, offset, stop) the profit rule is the highest win rate
among rules with --min-trades and at least --tp-keep of the best total; the family's pick is the largest positive total.
Families: side x structure x stop class (none, atr, trail, pct, loss, any), for all configurations, swing only,
and zone-only (no trade minimum beyond 5). Walk-forward: pick on train_YYYY, score on test_YYYY, pool 2022-2024.
"""
from __future__ import annotations
import argparse,collections,datetime as dt,json,math,os,sqlite3,statistics,sys,time
from pathlib import Path
import numpy as np
import zone_signals as zs
from zone_paths import unpack

PERIODS=(15,30,45)
def profit_rules(futures=False):
    r=['none']+([] if futures else [f'tp{int(x)}' for x in (10,15,20,25,30,35,40,45,50,60,75)])
    return r+[f'target{p}x{m:g}' for p in PERIODS for m in (1,2,3,4)]
def stop_rules(futures=False):
    r=['none']+[f'atr{p}x{m:g}' for p in PERIODS for m in (.5,1,1.5,2,2.5,3)]+[f'{k}{p}x{m:g}' for k in ('trail','strail') for p in PERIODS for m in (1,1.5,2,2.5,3)]
    r+=[f'pct{x:g}' for x in (.5,1,1.5,2,2.5,3)]
    return r+([] if futures else [f'loss{int(x*100)}' for x in (.25,.5,.75,1,1.5,2)])
def stop_class(label):
    for c in ('atr','strail','trail','pct','loss'):
        if label.startswith(c):return c
    return 'none'
def parse(label):
    """('tp',.25) / ('target',30,2.0) / ('atr',30,1.0) / ('trail',30,2.0) / ('pct',1.5) / ('loss',.5) / ('none',)"""
    if label=='none':return ('none',)
    for kind in ('target','atr','strail','trail'):
        if label.startswith(kind):p,m=label[len(kind):].split('x');return (kind,int(p),float(m))
    if label.startswith('tp'):return ('tp',int(label[2:])/100)
    if label.startswith('pct'):return ('pct',float(label[3:]))
    if label.startswith('loss'):return ('loss',int(label[4:])/100)
    raise ValueError(label)

class Bars:
    def __init__(self,db):
        rows=db.execute('SELECT idx,day,high,low,close FROM bars ORDER BY idx').fetchall()
        self.day=[r[1] for r in rows];self.ord=np.array([dt.date.fromisoformat(d).toordinal() for d in self.day])
        self.close=np.array([r[4] for r in rows],dtype=float)
        bars=[zs.Bar(r[1],0,0,r[4],r[2],r[3],r[4]) for r in rows]
        self.atr={p:zs.atr(bars,p) for p in PERIODS}

_RULES={}
def compiled(rules):
    """Rule labels grouped by kind into parameter arrays, cached per rule list."""
    key=tuple(rules)
    if key not in _RULES:
        g=collections.defaultdict(lambda:([],[],[]))
        for i,label in enumerate(rules):
            k=parse(label)
            if k[0]=='none':continue
            idx,p,m=g[k[0]];idx.append(i);p.append(k[1] if len(k)>2 else 0);m.append(k[2] if len(k)>2 else k[1])
        _RULES[key]={kind:(np.array(i),np.array(p),np.array(m,float)) for kind,(i,p,m) in g.items()}
    return _RULES[key]

def _first(mask,L):
    """First True per row of a (R,L) mask, else L-1."""
    hit=mask.any(1);return np.where(hit,mask.argmax(1),L-1)

def first_hits(rules,path,bars,sign):
    """For each rule label, the first row index where it fires, or L-1 (natural end). All rules of a kind at once."""
    t=path['signal_bar'];r=path['rows'];L=len(r['cash_total']);ks=np.arange(t+1,t+1+L)
    c=bars.close[ks];s0=bars.close[t];d=sign*(c-s0);pnl_pair=r['cash_pair']+r['value'];base=r['base']
    with np.errstate(invalid='ignore'):valid=np.isfinite(pnl_pair)&(base>0)
    out=np.full(len(rules),L-1,dtype=np.int64)
    for kind,(idx,per,mult) in compiled(rules).items():
        if kind=='tp':m=(valid&(r['roll']==0))[None,:]&(pnl_pair[None,:]>=mult[:,None]*base[None,:])
        elif kind=='loss':m=valid[None,:]&(pnl_pair[None,:]<=-mult[:,None]*base[None,:])
        elif kind=='pct':m=d[None,:]<-(mult[:,None]/100*s0)
        elif kind in ('target','atr'):
            a=np.array([bars.atr[p][t] for p in per])[:,None]
            with np.errstate(invalid='ignore'):m=(d[None,:]>=mult[:,None]*a) if kind=='target' else (d[None,:]<-mult[:,None]*a)
        else:
            e=path.get('entry_index',math.nan)
            anchor=s0 if kind=='strail' or e is None or not np.isfinite(e) else e   # trail: from the entry fill; strail: from the signal close
            best=np.maximum.accumulate(np.concatenate([[sign*anchor],sign*c]))[1:]
            a=np.stack([bars.atr[p][ks] for p in per])
            with np.errstate(invalid='ignore'):m=np.isfinite(a)&((sign*c)[None,:]<best[None,:]-mult[:,None]*np.nan_to_num(a,nan=np.inf))
        out[idx]=_first(m,L)
    return out

def outcomes(path,bars,profits,stops,his):
    """Per (profit, stop): per-unit P&L, exit bar, exit day, value at each window end in `his`, hypothetical flag."""
    sign=1 if path['side']=='bull' else -1;r=path['rows'];L=len(r['cash_total']);u=path['units']
    J=np.minimum(first_hits(profits,path,bars,sign)[:,None],first_hits(stops,path,bars,sign)[None,:])
    pnl=(r['cash_total']+r['exit_cash'])/u;pnl[L-1]=path['end_pnl']/u if path['end_pnl'] is not None else np.nan
    xb=r['exit_bar'].copy();xd=r['exit_day'].copy();hyp=np.zeros(L,bool)
    if path['status']=='open_at_data_end':xb[L-1]=10**9;xd[L-1]=10**9;hyp[L-1]=True
    ks=np.arange(path['signal_bar']+1,path['signal_bar']+1+L);row_ord=bars.ord[ks];mark=r['mark']/u
    vh=[]
    for h in his:
        jh=int(np.searchsorted(row_ord,h,'left'))-1
        mh=mark[min(max(jh,0),L-1)] if jh>=0 else np.nan
        vh.append(np.where(xd[J]<h,pnl[J],mh))
    return dict(pnl=pnl[J],xb=xb[J].astype(np.int64),xd=xd[J],vh=np.array(vh,dtype=np.float64),hyp=hyp[J],J=J)

def load_paths(db,side,structure,offset):
    out={}
    cols=[r[1] for r in db.execute('PRAGMA table_info(paths)')];ei='entry_index' if 'entry_index' in cols else 'NULL'
    for row in db.execute(f'SELECT signal_bar,status,reason,entry_day,units,first_bar,end_bar,end_pnl,data,pairs,{ei} FROM paths WHERE side=? AND structure=? AND offset=? ORDER BY signal_bar',(side,structure,offset)):
        t,status,reason,ed,units,fb,eb,pnl,blob,pairs,eix=row
        if status=='no_fill':out[t]=None;continue
        out[t]=dict(side=side,signal_bar=t,status=status,reason=reason,entry_day=ed,units=units,end_bar=eb,end_pnl=pnl,pairs=pairs,entry_index=eix if eix is not None else math.nan,rows=unpack(blob,eb-fb+1))
    return out

def windows(start,split):
    y0=int(start[:4])+1;y1=int(split[:4])
    w=[(f'train_{y}',start,f'{y}-01-01') for y in range(y0,y1)]+[('train_full',start,split)]
    return w+[(f'test_{y}',f'{y}-01-01',min(f'{y+1}-01-01',split)) for y in range(y0,y1)]

def sequence(signal_bars,idx,out,wins_def,his_index,shape):
    """One position at a time for every rule at once. Returns n, total, wins, sumsq per window, and skip counts."""
    W=len(wins_def);n=np.zeros((W,)+shape,np.int32);s=np.zeros((W,)+shape,np.float64);w=np.zeros((W,)+shape,np.int32);ss=np.zeros((W,)+shape,np.float64)
    busy=np.full(shape,-1,np.int64);skipped=0
    for t in signal_bars:
        pi=idx.get(t)
        if pi is None:continue
        o=out[pi];take=t>busy;skipped+=int((~take).sum())
        busy=np.where(take,o['xb'],busy);ed=o['entry_day']
        for wi,(_,lo,hi) in enumerate(wins_def):
            if not lo<=ed<hi:continue
            v=o['vh'][his_index[hi]];ok=take&np.isfinite(v);vz=np.where(ok,v,0.)
            n[wi]+=ok;s[wi]+=vz;ss[wi]+=vz*vz;w[wi]+=ok&(v>0)
    return n,s,w,ss,skipped

def sequence_all(by_bar,idx,out,wins_def,his_index,C,shape):
    """sequence() for every configuration at once: walk the signal bars in time order and update, as one block, the
    configurations that signalled there. Same result as calling sequence() per configuration."""
    W=len(wins_def);n=np.zeros((W,C)+shape,np.int32);s=np.zeros((W,C)+shape,np.float64);w=np.zeros((W,C)+shape,np.int32);ss=np.zeros((W,C)+shape,np.float64)
    busy=np.full((C,)+shape,-1,np.int64);skipped=0
    for t in sorted(by_bar):
        pi=idx.get(t)
        if pi is None:continue
        cs=by_bar[t];o=out[pi];b=busy[cs];take=t>b;skipped+=int((~take).sum())
        busy[cs]=np.where(take,o['xb'],b);ed=o['entry_day']
        for wi,(_,lo,hi) in enumerate(wins_def):
            if not lo<=ed<hi:continue
            v=o['vh'][his_index[hi]];ok=take&np.isfinite(v);vz=np.where(ok,v,0.)
            n[wi,cs]+=ok;s[wi,cs]+=vz;ss[wi,cs]+=vz*vz;w[wi,cs]+=ok&(v>0)
    return n,s,w,ss,skipped

def read_json(path):
    with open(path) as f:return json.load(f)
def write_json(obj,path,**kw):
    """Written to a temporary file, then renamed: a reader never sees half a file."""
    tmp=Path(str(path)+'.tmp')
    with open(tmp,'w') as f:json.dump(obj,f,**kw)
    os.replace(tmp,path)

def digest(path):
    import hashlib;h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<22),b''):h.update(chunk)
    return h.hexdigest()

def run_grid(paths_db,out_dir,start,split,structures=None,progress=True,resume=False):
    db=sqlite3.connect(f'file:{paths_db}?mode=ro',uri=True);bars=Bars(db);out_dir=Path(out_dir);out_dir.mkdir(exist_ok=True,parents=True)
    signals=collections.defaultdict(list)
    for c,side,t in db.execute('SELECT config,side,bar FROM signals ORDER BY bar'):signals[c,side].append(t)
    configs=sorted({c for c,_ in signals});wins_def=windows(start,split)
    his=sorted({hi for _,_,hi in wins_def});his_ord=[dt.date.fromisoformat(h).toordinal() for h in his];his_index={h:i for i,h in enumerate(his)}
    groups=db.execute('SELECT DISTINCT side,structure,offset FROM paths ORDER BY 1,2,3').fetchall()
    if structures:groups=[g for g in groups if g[1] in structures]
    t0=time.time();index=[];sha=digest(paths_db);code=digest(__file__)
    for side,structure,offset in groups:
        fut=structure.startswith('futures');P=profit_rules(fut);S=stop_rules(fut)
        name=f'grid_{side}_{structure}_{int(offset):+d}.npz';side_file=out_dir/(name+'.json')
        if resume and (out_dir/name).exists() and side_file.exists():
            e=read_json(side_file)
            if e.get('paths_sha256')==sha and e.get('code_sha256')==code and e.get('start')==start and e.get('split')==split:
                index.append(e);print(f'{side} {structure} {offset:+.0f}: done earlier, kept',flush=True);continue
        paths=load_paths(db,side,structure,offset);out=[];idx={}
        for t,p in paths.items():
            if p is None:continue
            o=outcomes(p,bars,P,S,his_ord);o['entry_day']=p['entry_day'];idx[t]=len(out);out.append(o)
        by_bar=collections.defaultdict(list)
        for ci,c in enumerate(configs):
            for t in signals.get((c,side),()):by_bar[t].append(ci)
        by_bar={t:np.array(v) for t,v in by_bar.items()}
        n,s_,w,ss,skipped=sequence_all(by_bar,idx,out,wins_def,his_index,len(configs),(len(P),len(S)))
        if n.max(initial=0)>np.iinfo(np.int16).max:raise OverflowError('trade count exceeds int16: widen the stored type')
        N=n.transpose(1,0,2,3).astype(np.int16);T=s_.transpose(1,0,2,3);Wn=w.transpose(1,0,2,3).astype(np.int16);SS=ss.transpose(1,0,2,3)   # sums stay float64
        tmp=out_dir/(name+'.tmp.npz')
        np.savez_compressed(tmp,n=N,total=T,wins=Wn,sumsq=SS,configs=np.array(configs),profits=np.array(P),stops=np.array(S),windows=np.array([w[0] for w in wins_def]))
        os.replace(tmp,out_dir/name)
        filled=sum(p is not None for p in paths.values())
        index.append(dict(file=name,side=side,structure=structure,offset=offset,paths=len(paths),filled=filled,
                          hypothetical_ends=sum(1 for p in paths.values() if p and p['status']=='open_at_data_end'),unresolved=sum(1 for p in paths.values() if p and p['status']=='unresolved'),
                          paths_sha256=sha,code_sha256=code,start=start,split=split,file_sha256=digest(out_dir/name)))
        write_json(index[-1],side_file,indent=1)
        if progress:print(f'{side} {structure} {offset:+.0f}: {filled}/{len(paths)} paths, {len(configs)} configs x {len(P)} x {len(S)} rules ({time.time()-t0:.0f}s)',flush=True)
    write_json(dict(paths_db=str(paths_db),paths_sha256=sha,code_sha256=code,start=start,split=split,windows=wins_def,groups=index),out_dir/'grid_index.json',indent=1)
    db.close()
    return out_dir

# ---------------- selection ----------------
def load_grid(out_dir):
    idx=read_json(Path(out_dir)/'grid_index.json');g={}
    for e in idx['groups']:
        with np.load(Path(out_dir)/e['file']) as z:g[e['side'],e['structure'],e['offset']]={k:z[k] for k in z.files}
    return idx,g

def tstat(n,s,ss):
    n=np.asarray(n,float);mean=np.divide(s,n,out=np.zeros_like(n),where=n>0);var=np.divide(ss-n*mean**2,n-1,out=np.zeros_like(n),where=n>1)
    sd=np.sqrt(np.maximum(var,0));return np.divide(mean*np.sqrt(n),sd,out=np.full_like(n,np.nan),where=sd>0)

_CHOICE={}
def choose(G,wi,mt,keep,cfg_mask,stop_mask):
    """Cached per (group, window, minimum, keep); the masks only filter."""
    key=(id(G),wi,mt,keep);hit=_CHOICE.get(key)
    if hit is None or hit[0] is not G:hit=_CHOICE[key]=(G,_choose(G,wi,mt,keep))   # holding G stops its id being reused
    pick,n,tot,w,ss,fin=hit[1]
    return pick,n,tot,w,ss,fin&cfg_mask[:,None]&stop_mask[None,:]

def _choose(G,wi,mt,keep):
    """Per (config, stop): profit rule by the TP rule. Returns arrays (C,S) of chosen profit index, n, total, wins, sumsq, eligible."""
    n=G['n'][:,wi].astype(float);tot=G['total'][:,wi].astype(float);w=G['wins'][:,wi].astype(float);ss=G['sumsq'][:,wi].astype(float)   # (C,P,S)
    valid=n>=mt;neg=np.full_like(tot,-np.inf)
    best=np.where(valid,tot,neg).max(1)                     # (C,S)
    win=np.divide(w,n,out=np.zeros_like(n),where=n>0)
    ok=valid&(tot>=keep*best[:,None,:])
    maxwin=np.where(ok,win,-1).max(1)
    ok2=ok&(win>=maxwin[:,None,:]-1e-12)
    pick_pos=np.where(ok2,tot,neg).argmax(1);pick_neg=np.where(valid,tot,neg).argmax(1)
    pick=np.where(best>0,pick_pos,pick_neg)
    take=lambda a:np.take_along_axis(a,pick[:,None,:],1)[:,0,:]
    return pick,take(n),take(tot),take(w),take(ss),np.isfinite(best)

_MASKS={}
def select(grid,side,structure,wi,mt,keep,cfg_filter,stop_filter):
    """Largest positive total in the family on window wi. Returns dict or None."""
    best=None
    for (sd,st,off),G in grid.items():
        if sd!=side or st!=structure:continue
        cfgs=G['configs'];stops=G['stops'];mk=(id(G),cfg_filter,stop_filter)
        hit=_MASKS.get(mk)
        if hit is None or hit[0] is not G:hit=_MASKS[mk]=(G,np.array([cfg_filter(c) for c in cfgs]),np.array([stop_filter(s) for s in stops]))
        _,cm,sm=hit
        pick,n,tot,w,ss,elig=choose(G,wi,mt,keep,cm,sm)
        cand=elig&(n>=mt)&(tot>0)
        if not cand.any():continue
        score=np.where(cand,tot,-np.inf);ci,si=np.unravel_index(int(score.argmax()),score.shape)
        if best is None or tot[ci,si]>best['total']:
            best=dict(side=side,structure=structure,offset=off,config=str(cfgs[ci]),profit=str(G['profits'][pick[ci,si]]),stop=str(stops[si]),
                      n=int(n[ci,si]),total=round(float(tot[ci,si]),1),win=round(float(w[ci,si]/n[ci,si]),3),t=round(float(tstat(n[ci,si],tot[ci,si],ss[ci,si])),2),
                      ci=int(ci),pi=int(pick[ci,si]),si=int(si))
    return best

def cell(grid,sel,wi):
    G=grid[sel['side'],sel['structure'],sel['offset']];c=(sel['ci'],wi,sel['pi'],sel['si'])
    return dict(n=int(G['n'][c]),total=float(G['total'][c]),wins=int(G['wins'][c]),sumsq=float(G['sumsq'][c]))

def pooled(cells):
    n=sum(c['n'] for c in cells);s=sum(c['total'] for c in cells);w=sum(c['wins'] for c in cells);ss=sum(c['sumsq'] for c in cells)
    return dict(n=n,total=round(s,1),mean=round(s/n,1) if n else None,win=round(w/n,3) if n else None,t=round(float(tstat(n,s,ss)),2) if n>1 else None)

# ---------------- exact detail for selected rules ----------------
class Detail:
    """Re-reads the paths for one selected rule and lists its trades, for statistics the grid does not keep."""
    def __init__(self,paths_db):
        self.db=sqlite3.connect(f'file:{paths_db}?mode=ro',uri=True);self.bars=Bars(self.db);self.cache={}
        self.signals=collections.defaultdict(list)
        for c,side,t in self.db.execute('SELECT config,side,bar FROM signals ORDER BY bar'):self.signals[c,side].append(t)
    def close(self):self.db.close()
    def __enter__(self):return self
    def __exit__(self,*exc):self.close()
    def group(self,side,st,off):
        k=(side,st,off)
        if k not in self.cache:self.cache={k:load_paths(self.db,side,st,off)}
        return self.cache[k]
    def trades(self,sel,lo,hi):
        paths=self.group(sel['side'],sel['structure'],sel['offset']);h=dt.date.fromisoformat(hi).toordinal();out=[];busy=-1
        for t in self.signals[sel['config'],sel['side']]:
            p=paths.get(t)
            if p is None or t<=busy:continue
            sign=1 if p['side']=='bull' else -1;L=len(p['rows']['cash_total'])
            jp=int(first_hits([sel['profit']],p,self.bars,sign)[0]);js=int(first_hits([sel['stop']],p,self.bars,sign)[0])
            o=outcomes(p,self.bars,[sel['profit']],[sel['stop']],[h]);busy=int(o['xb'][0,0])
            if not lo<=p['entry_day']<hi:continue
            v=float(o['vh'][0,0,0]);j=int(o['J'][0,0])
            reason=('both_rules_same_bar' if jp==js else 'profit_rule' if j==jp else 'stop_rule') if j<L-1 and j in (jp,js) else p['reason']
            ks=np.arange(t+1,t+1+j+1);inside=self.bars.ord[ks]<h;marks=(p['rows']['mark'][:j+1]/p['units'])[inside]
            xd=int(o['xd'][0,0]);realised=xd<h
            out.append(dict(signal_bar=t,entry_day=p['entry_day'],exit_day=dt.date.fromordinal(min(xd,h)).isoformat() if xd<10**8 else hi,unit=v,
                            hypothetical=not realised or bool(o['hyp'][0,0]),forced=bool(p['rows']['exit_forced'][j] or p['rows']['forced_before'][j]),reason=reason,pairs=p['pairs'],marks=marks))
        return out
def detail_stats(tr,lo,hi):
    if not tr:return dict(n=0)
    u=[x['unit'] for x in tr if math.isfinite(x['unit'])];weeks=collections.defaultdict(float)
    for x in tr:
        if math.isfinite(x['unit']):weeks[dt.date.fromisoformat(x['entry_day']).isocalendar()[:2]]+=x['unit']
    w=list(weeks.values());sd=statistics.stdev(w) if len(w)>2 else 0;eq=pk=dd=0.
    for x in u:eq+=x;pk=max(pk,eq);dd=max(dd,pk-eq)
    closed=mpk=mdd=0.;mae=[];mfe=[]                      # bar-close equity: closed trades plus the open trade's mark
    for x in tr:
        m=x['marks'][np.isfinite(x['marks'])]
        if len(m):mae.append(float(min(m.min(),0)));mfe.append(float(max(m.max(),0)))
        for v in np.append(m,x['unit'] if math.isfinite(x['unit']) else []):e=closed+v;mpk=max(mpk,e);mdd=max(mdd,mpk-e)
        if math.isfinite(x['unit']):closed+=x['unit']
    held=[(dt.date.fromisoformat(x['exit_day'])-dt.date.fromisoformat(x['entry_day'])).days for x in tr]
    span=(dt.date.fromisoformat(hi)-dt.date.fromisoformat(lo)).days
    gains=sum(x for x in u if x>0);losses=-sum(x for x in u if x<0)
    return dict(n=len(u),total=round(sum(u),1),mean=round(statistics.mean(u),1),win=round(sum(x>0 for x in u)/len(u),3),t_weekly=round(statistics.mean(w)/(sd/math.sqrt(len(w))),2) if sd else None,
                profit_factor=round(gains/losses,2) if losses else None,worst=round(min(u),1),best=round(max(u),1),max_drawdown=round(dd,1),max_drawdown_mtm=round(mdd,1),
                worst_open_loss=round(min(mae),1) if mae else None,median_mae=round(statistics.median(mae),1) if mae else None,median_mfe=round(statistics.median(mfe),1) if mfe else None,
                median_days_held=statistics.median(held),days_in_market=sum(held),share_of_calendar_days=round(sum(held)/span,3) if span>0 else None,
                hypothetical=sum(x['hypothetical'] for x in tr),forced=sum(x['forced'] for x in tr),exits=dict(collections.Counter(x['reason'] for x in tr)),
                by_year={y:dict(n=len(v),total=round(sum(v),1),win=round(sum(x>0 for x in v)/len(v),3)) for y,v in sorted(_years(tr).items())})
def _years(tr):
    out=collections.defaultdict(list)
    for x in tr:
        if math.isfinite(x['unit']):out[x['entry_day'][:4]].append(x['unit'])
    return out

def buy_and_hold(bars,lo,hi,carry=.0,roll_points=0.):
    """Long one unit of index from the first bar close on/after lo to the last before hi. Spot prices: no basis.
    carry: yearly cost of holding a future as a share of the index (an assumption, not data); roll_points per monthly roll."""
    k=[i for i,d in enumerate(bars.day) if lo<=d<hi]
    if not k:return None
    c=bars.close[k];pk=np.maximum.accumulate(c);days=(dt.date.fromisoformat(bars.day[k[-1]])-dt.date.fromisoformat(bars.day[k[0]])).days
    months=len({bars.day[i][:7] for i in k})-1
    return dict(start=bars.day[k[0]],end=bars.day[k[-1]],index_start=round(float(c[0]),1),index_end=round(float(c[-1]),1),points=round(float(c[-1]-c[0]),1),
                max_drawdown=round(float((pk-c).max()),1),rolls=months,roll_cost=round(months*roll_points,1),carry_cost=round(float(c.mean())*carry*days/365,1),calendar_days=days)

FILTERS={'all':lambda c:True,'swing':lambda c:not c.startswith('zone_only'),'zone_only':lambda c:c.startswith('zone_only')}
STOP_CLASSES=('any','none','atr','trail','strail','pct','loss')
_SF={}
def stop_filter(cls):return _SF.setdefault(cls,(lambda s:True) if cls=='any' else (lambda s:stop_class(s)==cls))

def report(out_dir,min_trades=30,keep=.75,paths_db=None,carry=.055,roll_points=0.):
    idx,grid=load_grid(out_dir);wn=[w[0] for w in idx['windows']];full=wn.index('train_full')
    years=[w[5:] for w in wn if w.startswith('test_')]
    res=dict(min_trades=min_trades,tp_keep=keep,windows=idx['windows'],families=[])
    structures=sorted({k[1] for k in grid});cnt=0
    for side in ('bull','bear'):
        for st in structures:
            if not any(k[0]==side and k[1]==st for k in grid):continue
            for sc in STOP_CLASSES:
                if st.startswith('futures') and sc=='loss':continue
                for subset,f in FILTERS.items():
                    mt_full=min_trades if subset!='zone_only' else 5;mt_wf=max(10,min_trades//2) if subset!='zone_only' else 5
                    fam=dict(side=side,structure=st,stops=sc,configs=subset)
                    fam['train_best']=select(grid,side,st,full,mt_full,keep,f,stop_filter(sc))
                    folds=[];cells=[]
                    for y in years:
                        sel=select(grid,side,st,wn.index(f'train_{y}'),mt_wf,keep,f,stop_filter(sc))
                        if not sel:continue
                        c=cell(grid,sel,wn.index(f'test_{y}'));cells.append(c)
                        folds.append(dict(year=y,**{k:sel[k] for k in ('config','offset','profit','stop','n','total','win')},test=pooled([c])))
                    fam['walk_forward']=folds;fam['walk_forward_pooled']=pooled(cells) if cells else None
                    res['families'].append(fam);cnt+=1
    # breadth: how many combinations are positive in training, per side x structure x stop class
    breadth=[]
    for (side,st,off),G in sorted(grid.items()):
        n=G['n'][:,full];tot=G['total'][:,full]
        for sc in STOP_CLASSES[1:]:
            sm=np.array([stop_class(s)==sc for s in G['stops']])
            if not sm.any():continue
            m=(n[:,:,sm]>=min_trades);t=tot[:,:,sm][m]
            breadth.append(dict(side=side,structure=st,offset=off,stops=sc,scored=int(m.sum()),positive_share=round(float((t>0).mean()),3) if t.size else None,median=round(float(np.median(t)),1) if t.size else None))
    res['breadth']=breadth
    if paths_db:
        test_lo=f'{years[0]}-01-01' if years else None;split=idx['split'];start=idx['start']
        with Detail(paths_db) as D:
            for f in res['families']:
                if f['train_best']:f['train_best_detail']=detail_stats(D.trades(f['train_best'],start,split),start,split)
                oos=[]
                for fold in f['walk_forward']:
                    sel=dict(fold,side=f['side'],structure=f['structure']);oos+=D.trades(sel,f"{fold['year']}-01-01",min(f"{int(fold['year'])+1}-01-01",split))
                if oos and test_lo:f['walk_forward_detail']=detail_stats(oos,test_lo,split)
            res['buy_and_hold']={name:buy_and_hold(D.bars,lo,hi,carry,roll_points) for name,lo,hi in [('train_full',start,split)]+[(f'test_{y}',f'{y}-01-01',min(f'{int(y)+1}-01-01',split)) for y in years]+([('walk_forward_years',test_lo,split)] if test_lo else [])}
        res['buy_and_hold_assumptions']=dict(carry_per_year=carry,roll_points=roll_points,note='spot closes; futures basis/carry not in the data: carry is an assumed rate. Futures paths pay carry only while held (share_of_calendar_days).')
    write_json(res,Path(out_dir)/'grid_report.json',indent=1,default=str)
    with open(Path(out_dir)/'grid_walk_forward.csv','w') as fh:
        fh.write('side,structure,stops,configs,wf_n,wf_total,wf_mean,wf_win,wf_t,train_config,train_offset,train_profit,train_stop,train_n,train_total,train_win,train_t\n')
        for f in res['families']:
            p=f['walk_forward_pooled'] or {};b=f['train_best'] or {}
            fh.write(','.join(str(x) for x in (f['side'],f['structure'],f['stops'],f['configs'],p.get('n'),p.get('total'),p.get('mean'),p.get('win'),p.get('t'),
                     b.get('config'),b.get('offset'),b.get('profit'),b.get('stop'),b.get('n'),b.get('total'),b.get('win'),b.get('t')))+'\n')
    return res

def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--paths',required=True,help='zone_paths.sqlite');ap.add_argument('--out',default='zone_grid')
    ap.add_argument('--start',default='2021-09-01');ap.add_argument('--split',default='2025-01-01')
    ap.add_argument('--min-trades',type=int,default=30);ap.add_argument('--tp-keep',type=float,default=.75)
    ap.add_argument('--structures',help='Limit to these structures (comma separated)');ap.add_argument('--report-only',action='store_true');ap.add_argument('--resume',action='store_true',help='Keep groups already written for the same paths file, code and windows')
    ap.add_argument('--carry',type=float,default=.055,help='Assumed yearly futures carry for the buy-and-hold benchmark (not in the data)')
    ap.add_argument('--roll-points',type=float,default=0.,help='Assumed points per unit lost on each monthly futures roll')
    ap.add_argument('--explain',help='side,structure,offset,config,profit,stop: write that combination\'s trades to CSV (training window) and exit')
    a=ap.parse_args()
    if a.explain:
        side,st,off,cfg,prof,stop=a.explain.split(',');sel=dict(side=side,structure=st,offset=float(off),config=cfg,profit=prof,stop=stop)
        with Detail(a.paths) as D:tr=D.trades(sel,a.start,a.split)
        f=Path(a.out);f.mkdir(exist_ok=True,parents=True);name=f/('trades_'+'_'.join(x.replace('.','p') for x in (side,st,off,cfg,prof,stop))+'.csv')
        with open(name,'w') as fh:
            fh.write('signal_bar,entry_day,exit_day,unit_pnl,reason,hypothetical,forced,pairs,worst_open,best_open\n')
            for x in tr:
                m=x['marks'][np.isfinite(x['marks'])]
                fh.write(f"{x['signal_bar']},{x['entry_day']},{x['exit_day']},{x['unit']:.2f},{x['reason']},{int(x['hypothetical'])},{int(x['forced'])},{x['pairs']},{m.min() if len(m) else ''},{m.max() if len(m) else ''}\n")
        print(json.dumps(detail_stats(tr,a.start,a.split),default=str));print('->',name);return
    if a.split>'2025-01-01':sys.exit('--split later than 2025-01-01 would score holdout outcomes in training')
    if not a.report_only:run_grid(a.paths,a.out,a.start,a.split,a.structures.split(',') if a.structures else None,resume=a.resume)
    res=report(a.out,a.min_trades,a.tp_keep,a.paths,a.carry,a.roll_points)
    print('\nWalk-forward, out-of-sample 2022-2024 (points per unit), pick re-made each year on earlier data only:')
    for f in res['families']:
        p=f['walk_forward_pooled'];b=f['train_best']
        print(f"{f['side']:4} {f['structure']:14} stops={f['stops']:5} {f['configs']:9} WF {p and (p['n'],p['total'],p['win'],p['t'])}  "
              f"train best {b and (b['config'],b['offset'],b['profit'],b['stop'],b['n'],b['total'],b['win'])}")
    print('\nBuy and hold (per unit, spot):',json.dumps(res.get('buy_and_hold'),indent=None))
    print(f'-> {a.out}/grid_report.json, grid_walk_forward.csv, grid_*.npz')

if __name__=='__main__':main()
