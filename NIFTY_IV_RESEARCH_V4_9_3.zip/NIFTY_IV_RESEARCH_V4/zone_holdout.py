#!/usr/bin/env python3
"""Final holdout: replay a frozen portfolio selection ONCE on 2025-01-01 .. --to (V4.9.3).

Reads portfolio_freeze.json (written by zone_portfolio.py: the in-sample choice fitted to every training year, its sizes and all
assumptions) and replays it through the same executable account as the walk-forward (orders admitted at the signal close against
funds, margin and the open-lot cap), adopted flat on 1 January 2025. Nothing is re-selected, re-ranked or re-calibrated.

Refuses to run if the paths file, or the code that turns a selection into an account result, differs from what was frozen.
Every run is recorded in holdout_ledger.json next to the freeze file; a second run of the same freeze is refused unless
--acknowledge-repeat, and is then labelled a repeat (it is no longer a first look at unseen data).

Outputs (in --out): holdout_report.json, holdout_account_daily.csv, holdout_orders.csv."""
import argparse,datetime as dt,hashlib,json,sys
from pathlib import Path
import numpy as np
import zone_grid as zg
import zone_rules as zr
import zone_portfolio as zp

def run(freeze_path,paths_db,out,to='2026-07-01',holidays=(),acknowledge_repeat=False,progress=True):
    freeze_path=Path(freeze_path);F=json.loads(freeze_path.read_text());fsha=hashlib.sha256(freeze_path.read_bytes()).hexdigest()
    if zg.digest(paths_db)!=F['paths_sha256']:raise SystemExit(f'{paths_db} is not the paths file the selection was frozen on')
    if zp.code_digest()!=F['code_sha256']:raise SystemExit('the portfolio / grid / rule / path code changed since the freeze: the result would not be the frozen procedure')
    P=F['params']
    if sorted(holidays)!=sorted(P.get('holidays',[])):raise SystemExit('--holidays must be the list used for the freeze')
    ledger_path=freeze_path.with_name('holdout_ledger.json');ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    earlier=[r for r in ledger if r['freeze_sha256']==fsha]
    if earlier and not acknowledge_repeat:raise SystemExit(f'this freeze was already evaluated on the holdout ({earlier[0]["run_at"]}); a repeat is not a first look (use --acknowledge-repeat to run and label it)')
    lo=zg.HOLDOUT_START;out=Path(out);out.mkdir(parents=True,exist_ok=True)
    D=zg.Detail(paths_db,holidays,P.get('gap_policy','free'));K=D.target_lots or 10
    days=sorted({d for d in D.bars.day if lo<=d<to})
    if not days:raise SystemExit(f'no sessions in {lo} .. {to} in {paths_db}')
    ordv=np.array([dt.date.fromisoformat(d).toordinal() for d in days]);last={};[last.__setitem__(d,c) for d,c in zip(D.bars.day,D.bars.close)];close=np.array([last[d] for d in days])
    sz=zp.Sizing(P['sizing'],P['ref_units'],K,D.target_units);margin=dict(zp.MARGIN,**(P.get('margin') or {}))
    sel_of=lambda k:dict(side=k[0],structure=k[1],offset=k[2],config=k[3],profit=k[4],stop=k[5])
    acc=zp.Account(D,days,ordv,close,to,P['capital'],P['buffer'],P['min_days'],margin,sz,sel_of,P.get('max_lots'))
    legs=[('holdout','green' if s['side']=='bull' else 'red',(s['side'],s['structure'],float(s['offset']),s['config'],s['profit'],s['stop']),s['lots'],lo,to) for s in F['selection']]
    A,M,opn,orders,Lo=acc.run(legs,P['carry'])
    years=sorted({int(d[:4]) for d in days});s,daily,G,R,short,breach=zp.account_summary(acc,A,M,Lo,opn,orders,years,0)
    rows=[]
    for y in years:
        r,dd,ab=acc.year(A,y);a,b=ab;e0=A[a-1] if a>0 else 0.;sy=np.r_[0.,A[a:b+1]-e0]
        rows.append(dict(year=y,return_=None if r is None else round(float(r),6),days=dd,annualised=bool(dd>=P['min_days']),daily_close_drawdown_in_year=round(float((np.maximum.accumulate(sy)-sy).max())),
                         funds_short_sessions=int(short[a:b+1].sum()),buffer_breach_sessions=int(breach[a:b+1].sum())))
    full=[r for r in rows if r['annualised'] and r['return_'] is not None];rets=[r['return_'] for r in full]
    summ=dict(s,years=[r['year'] for r in full],returns=rets,mean=round(float(np.mean(rets)),6) if rets else None,worst=round(float(min(rets)),6) if rets else None,
              every_year_deployable=P['sizing']=='exchange' and not s['funds_short_sessions'])
    v=zp.verdict(summ,rows,P['target'],P['floor'],P['max_dd'],P.get('return_basis','simple'))
    if len(summ['years'])<2 and summ['years']:                                     # the holdout has one full year (2025) and a part year: judge what exists, say so
        why=[];ov=summ['mean'] if P.get('return_basis','simple')=='simple' else s.get('cagr_fixed_size_no_withdrawals')
        if ov is None or ov<P['target']:why.append(f"overall {ov} < {P['target']}")
        if summ['worst']<P['floor']:why.append(f"worst full year {summ['worst']} < {P['floor']}")
        if s['daily_close_drawdown_continuous']>P['max_dd']:why.append(f"continuous drawdown {s['daily_close_drawdown_continuous']} > {P['max_dd']}")
        if s['funds_short_sessions']:why.append('funds short of assumed margin')
        v=dict(oos_verdict='PASS' if not why else 'FAIL',oos_verdict_reasons=why+['judged on one full year and a part year: thin evidence'])
    rep=dict(holdout=dict(start=lo,end=to,sessions=len(days)),freeze=str(freeze_path),freeze_sha256=fsha,selection=F['selection'],params=P,years=rows,summary=summ,**v,
             repeat=bool(earlier),label='REPEAT RUN: not a first look at unseen data' if earlier else 'first holdout run of this freeze')
    zg.write_json(rep,out/'holdout_report.json',indent=1,default=str);zp._csv(out/'holdout_account_daily.csv',daily);zp._csv(out/'holdout_orders.csv',orders)
    ledger.append(dict(freeze_sha256=fsha,run_at=dt.datetime.now().isoformat(timespec='seconds'),out=str(out),verdict=v['oos_verdict'],repeat=bool(earlier)))
    zg.write_json(ledger,ledger_path,indent=1);D.close()
    return rep

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--freeze',required=True,help='portfolio_freeze.json from zone_portfolio.py');ap.add_argument('--paths',required=True,help='the zone_paths.sqlite of the freeze (covering the holdout)')
    ap.add_argument('--out',default='holdout');ap.add_argument('--to',default='2026-07-01',help='end of the holdout (exclusive)');ap.add_argument('--holidays')
    ap.add_argument('--acknowledge-repeat',action='store_true',help='run a freeze that was already evaluated (labelled a repeat)')
    a=ap.parse_args(argv);hol=zr.read_holidays(a.holidays) if a.holidays else []
    rep=run(a.freeze,a.paths,a.out,a.to,hol,a.acknowledge_repeat)
    print(f"Holdout {rep['holdout']['start']} .. {rep['holdout']['end']} ({rep['label']}):")
    for r in rep['years']:print(f"  {r['year']}: {'n/a' if r['return_'] is None else format(r['return_'],'.1%')}{'' if r['annualised'] else ' (part year, not annualised)'}  drawdown in year Rs {r['daily_close_drawdown_in_year']:,}")
    s=rep['summary'];print(f"  continuous daily-close drawdown Rs {s['daily_close_drawdown_continuous']:,}; assumed margin peak Rs {s['assumed_margin_peak']:,}; orders cut {s['orders_cut']}, rejected {s['orders_rejected']}")
    print(f"  VERDICT: {rep['oos_verdict']}"+(f" ({'; '.join(rep['oos_verdict_reasons'])})" if rep['oos_verdict_reasons'] else ''))
    print(f'-> {a.out}/holdout_report.json, holdout_account_daily.csv, holdout_orders.csv')

if __name__=='__main__':main()
