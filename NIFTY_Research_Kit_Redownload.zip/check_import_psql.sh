#!/usr/bin/env bash
set -euo pipefail
psql -h "${PGHOST:-localhost}" -p "${PGPORT:-5432}" -U "${PGUSER:-postgres}" -d "${PGDATABASE:-nifty_data}" -v ON_ERROR_STOP=1 <<'SQL'
SELECT dataset, market_kind, status,
       COUNT(*) AS registered_files,
       SUM(expected_rows) AS expected_rows,
       SUM(loaded_rows) AS loaded_rows,
       ROUND(100.0*SUM(loaded_rows)/NULLIF(SUM(expected_rows),0),2) AS percent_imported
FROM market_data.import_files
WHERE relative_path LIKE 'NIFTY_20%.parquet'
   OR relative_path LIKE 'india-index-options-1m/options/NIFTY/%'
   OR relative_path IN ('NIFTY.parquet','india-index-options-1m/index/NIFTY.parquet')
GROUP BY dataset, market_kind, status
ORDER BY dataset, market_kind, status;
SQL
