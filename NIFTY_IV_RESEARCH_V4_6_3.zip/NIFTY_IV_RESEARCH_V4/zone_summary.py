#!/usr/bin/env python3
"""Top-N zone rules per side, in rupees at --lots, by 12-month period: P&L, win rate, profit factor, Sharpe, Sortino,
Calmar, max drawdown, max loss, max win and how trades ended.

Ranking comes from zone_report.py's train_candidates.csv (training only). Rules that produce identical trades are
merged and listed as aliases. A chain still open at --to is closed hypothetically at the last bar-close prices
before it. --to past the split shows holdout years: say so when you use it.

Ratios use daily P&L booked on exit days (open positions are not marked daily, so volatility is understated).
Calmar is annualised P&L / max drawdown, both in rupees. Fills were checked for volume at the simulated lot count only."""
import argparse,collections as C,csv,json,math,sqlite3,statistics as S,sys
from pathlib import Path
import zone_report as zr

def periods(lo,hi,months=12):
    out=[];y,m=int(lo[:4]),int(lo[5:7]);d=lo[8:]
    while True:
        m2=m+months;y2=y+(m2-1)//12;m2=(m2-1)%12+1;start=f'{y}-{m:02d}-{d}';end=f'{y2}-{m2:02d}-{d}'
        if start>=hi:break
        out.append((start,min(end,hi)));y,m=y2,m2
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--trades',required=True);ap.add_argument('--report',required=True,help='zone_report output folder (train_candidates.csv)')
    ap.add_argument('--lots',type=int,default=10);ap.add_argument('--top',type=int,default=3);ap.add_argument('--from-date',default='2021-06-01');ap.add_argument('--to-date',default='2025-01-01')
    ap.add_argument('--structure',default='all',help='naked, naked|atr30, futures_zone, ... or all (top N for each)');ap.add_argument('--out',default=None,help='CSV of every row printed')
    a=ap.parse_args()
    split=json.load(open(Path(a.report)/'train_report.json'))['split']
    if a.to_date>split:print(f'NOTE: --to-date {a.to_date} is past the split {split}: these figures include holdout data',file=sys.stderr)
    bars,signals,chains,first=zr.load(a.trades)
    db=sqlite3.connect(f'file:{a.trades}?mode=ro',uri=True);pairs=C.defaultdict(list)
    for cid,ed,xd,st,pnl,lot,marks,reason in db.execute('SELECT chain,entry_day,exit_day,status,pnl_inr,lot,marks_at,reason FROM trades WHERE status!="no_fill" ORDER BY roll'):
        pairs[cid].append(dict(ed=ed,xd=xd,st=st,pnl=pnl,lot=lot,marks=json.loads(marks or '{}'),reason=reason))
    sessions=sorted(set(bars.values()))
    def chain_list(sb,side,fam,off,tp):
        out=[];busy=-1;miss=C.Counter()
        for t in sb:
            if t<=busy:continue
            cid=first.get((side,fam,off,tp,t))
            if cid is None:miss['no_fill']+=1;continue
            c=chains[cid];busy=c['end_bar']
            if not a.from_date<=c['entry_day']<a.to_date:continue
            inr=0.;end=None;why=None;ok=True
            for p in pairs[cid]:
                if p['ed']>=a.to_date:continue
                if p['st']=='closed' and p['xd']<a.to_date:inr+=p['pnl'];end=p['xd'];why=p['reason'];continue
                v=p['marks'].get(a.to_date)
                if v is None:ok=False;break
                inr+=v*p['lot'];end=max(d for d in sessions if d<a.to_date);why='hypothetical_close'
            if not ok:miss['no_value']+=1;continue
            out.append(dict(entry=c['entry_day'],exit=end,inr=inr*a.lots,why=why))
        return out,miss
    def metrics(tr,lo,hi):
        if not tr:return dict(n=0)
        days=[d for d in sessions if lo<=d<hi];daily=C.defaultdict(float)
        for x in tr:daily[x['exit']]+=x['inr']
        r=[daily.get(d,0.) for d in days];mu=S.mean(r);sd=S.pstdev(r);dn=math.sqrt(S.mean([min(0,v)**2 for v in r]))
        eq=pk=dd=0.
        for v in r:eq+=v;pk=max(pk,eq);dd=max(dd,pk-eq)
        w=[x['inr'] for x in tr];gw=sum(v for v in w if v>0);gl=-sum(v for v in w if v<0);yrs=len(days)/252
        f=lambda v:round(v/1e5,2)
        return dict(n=len(w),pnl_lakh=f(sum(w)),win=round(sum(v>0 for v in w)/len(w),2),pf=round(gw/gl,2) if gl else None,sharpe=round(mu/sd*math.sqrt(252),2) if sd else None,
                    sortino=round(mu/dn*math.sqrt(252),2) if dn else None,calmar=round(sum(w)/yrs/dd,2) if dd and yrs else None,max_dd_lakh=f(dd),max_loss_lakh=f(min(w)),max_win_lakh=f(max(w)))
    rows=list(csv.DictReader(open(Path(a.report)/'train_candidates.csv')));printed=[]
    fams=sorted({r['structure'] for r in rows}) if a.structure=='all' else [a.structure]
    for side,fam in [(s_,f_) for s_ in ('bull','bear') for f_ in fams]:
        seen={};picked=[]
        for r in rows:
            if r['side']!=side or r['structure']!=fam:continue
            off=float(r['offset']);tp=None if r['tp']=='None' else float(r['tp'])
            tr,miss=chain_list(signals[r['config'],side],side,fam,off,tp)
            key=(off,tp,tuple((x['entry'],round(x['inr'],2)) for x in tr))
            if key in seen:seen[key]['aliases'].append(r['config']);continue
            item=dict(r,off=off,tp=tp,tr=tr,miss=miss,aliases=[]);seen[key]=item
            if len(picked)<a.top:picked.append(item)
            elif len(seen)>50*a.top:break
        for rank,p in enumerate(picked,1):
            exits=dict(C.Counter(x['why'] for x in p['tr']))
            print(f"\n{side} {fam} #{rank}: {p['config']} strike offset {p['off']:+.0f} take-profit {p['tp']} | same trades: {p['aliases'] or '-'} | exits {exits} | skipped {dict(p['miss'])}")
            print('period | ' + ' | '.join(('trades','P&L lakh','win','PF','Sharpe','Sortino','Calmar','max DD','max loss','max win')))
            for lo,hi in periods(a.from_date,a.to_date)+[(a.from_date,a.to_date)]:
                m=metrics([x for x in p['tr'] if lo<=x['entry']<hi],lo,hi);label='ALL' if (lo,hi)==(a.from_date,a.to_date) else f'{lo}..{hi}'
                print(label,'|',' | '.join(str(m.get(k,'')) for k in ('n','pnl_lakh','win','pf','sharpe','sortino','calmar','max_dd_lakh','max_loss_lakh','max_win_lakh')))
                printed.append(dict(side=side,structure=fam,rank=rank,config=p['config'],offset=p['off'],tp=p['tp'],period=label,**m))
    if a.out:
        keys=sorted({k for r in printed for k in r},key=lambda k:list(printed[0]).index(k) if k in printed[0] else 99)
        with open(a.out,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(printed)

if __name__=='__main__':main()
