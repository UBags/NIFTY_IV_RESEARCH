#!/usr/bin/env python3
"""Green + red portfolio selection on rupee returns, yearly floors and combined drawdown (V4.9).

A portfolio is one green (bull) strategy and one red (bear) strategy run together on one account. Each strategy is a
grid combination (structure, strike offset, signal configuration, profit rule, stop rule); the two may differ completely.
The account is judged as a whole, the way the trader experiences it:

  capital           --capital (default 25,00,000: 10 lots x 2.5 lakh margin each); P&L in rupees = P&L per unit x the
                    units each trade actually held (paths built with --lots 10; a smaller matched entry holds fewer units)
  return per year   that calendar year's rupee P&L (mark-to-market at the year's last close) / capital, annualised for a
                    part year (the first year starts at --start). Capital is not compounded: 10 lots throughout.
  overall return    total rupee P&L / capital / years covered (same basis as the yearly figures)
  drawdown          largest fall of the combined daily equity (green + red, closed trades plus open trades at each
                    session's last close) from its running peak, in rupees
  gates             overall >= --target (22%), every year >= --floor (17%), drawdown <= --max-dd (2,50,000)
  ranking           among pairs passing every gate: --rank dd (smallest drawdown, default), worst_year, or calmar
                    (overall return / drawdown); ties by higher overall return

Selection is walk-forward: for each test year the pair is chosen on the years before it only (candidate pools, gates
and ranking all on training data), then its result in the test year is reported. The full-period list (train_full) is
in-sample and labelled so: it says which pairs fit the past, not which will work.

Candidates: the grid holds ~1.2 billion combinations, too many to pair. For each side and training window the pool is
the union of the top --pool combinations by (a) training total, (b) worst training year (annualised), and (c) the grid's
stability score (conservative lower quartile over one-step neighbours), each with >= --min-trades trades. Pool members
are replayed once as daily rupee equity curves; every green x red pair of a window's pools is evaluated.

Robustness: for the chosen pairs, each leg is swapped for its one-step neighbours (configuration, profit rule, stop rule)
with the other leg fixed; the share of those neighbour pairs that also pass every gate is reported.

Futures are spot-proxy: an assumed carry (--carry, default 5.5%/yr) is charged pro rata on futures legs (long pays,
short receives). Options P&L is net of the modelled charges and slippage. Margin is the assumption above; when green
and red positions are open in the same session the account needs margin for both (reported as overlap sessions).

Outputs (in --out): portfolio_walk_forward.csv, portfolio_pairs_in_sample.csv, portfolio_gate_counts.csv,
portfolio_report.json."""
import argparse,collections,csv,datetime as dt,json,math,sys,time
from pathlib import Path
import numpy as np
import zone_grid as zg
import zone_rules as zr

CAPITAL=2_500_000.

# ---------------- candidate pools from the grid files ----------------
_P={}
def _year_factor(start,split):
    """Calendar years covered inside [start, split) and the annualisation factor of each (365 / days covered)."""
    a=dt.date.fromisoformat(start);b=dt.date.fromisoformat(split);out={}
    for y in range(a.year,b.year+1):
        lo=max(a,dt.date(y,1,1));hi=min(b,dt.date(y+1,1,1));d=(hi-lo).days
        if d>0:out[y]=365./d
    return out

def _pool_file(e):
    """Top candidates of one grid file for every (training window, criterion)."""
    c=_P;K=c['pool'];mt=c['min_trades'];out=[]
    with np.load(c['grid']/e['file']) as z:Z={k:z[k] for k in ('n','total','configs','profits','stops','windows')}
    configs=list(Z['configs']);P=list(Z['profits']);S=list(Z['stops']);wn=list(Z['windows'])
    CN=zr.config_neighbours(configs);PN=zr.neighbours(P);SN=zr.compound_neighbours(S) if e['kind'].startswith('compound') else zr.neighbours(S)
    for fold,(wname,years) in c['folds'].items():
        if wname not in wn:continue
        wi=wn.index(wname);N=Z['n'][:,wi].astype(np.int64);T=Z['total'][:,wi]
        ok=N>=mt
        if not ok.any():continue
        yw=lambda y:f'test_{y}' if f'test_{y}' in wn else f'train_{y+1}'          # the first (part) year has no test window: train_<next year> is that year alone
        yr=[Z['total'][:,wn.index(yw(y))]*c['factor'][y] for y in years if yw(y) in wn]
        worst=np.min(np.stack(yr),0) if yr else T
        stab,_=zg.stability(N,T,mt,CN,PN,SN)
        for crit,score in (('total',T),('worst_year',worst),('stable',stab)):
            sc=np.where(ok&np.isfinite(score),score,-np.inf).ravel();k=min(K,int(np.isfinite(sc).sum()))
            if not k:continue
            for f in np.argpartition(-sc,k-1)[:k]:
                ci,pi,si=np.unravel_index(int(f),N.shape)
                out.append((fold,crit,float(sc[f]),(e['side'],e['structure'],float(e['offset']),configs[ci],P[pi],S[si]),e['file']))
    return out

def pools(grid,folds,factor,pool,min_trades,workers=1):
    """{(fold, side): {candidate key: file}} with the top `pool` per criterion across all files."""
    idx=zg.read_json(grid/'grid_index.json');_P.clear();_P.update(grid=grid,folds=folds,factor=factor,pool=pool,min_trades=min_trades)
    best=collections.defaultdict(list)
    for part in zg.pool_map(_pool_file,idx['groups'],workers):
        for fold,crit,score,key,f in part:best[fold,key[0],crit].append((score,key,f))
    out=collections.defaultdict(dict)
    for (fold,side,crit),lst in best.items():
        lst.sort(key=lambda x:-x[0])
        for _,key,f in lst[:pool]:out[fold,side][key]=f
    return out,idx

# ---------------- daily rupee equity of one strategy ----------------
def equity(trades,sess_ord,structure='naked',carry=0.):
    """Daily rupee equity over sessions sess_ord (ordinals): closed trades plus the open trade valued at each session's last
    close (its last finite mark carried forward). A trade is open from its entry session up to the session of its last exit
    fill, where its P&L is realised; one still open at the end is valued as the grid values it at the window end.
    Returns (equity, open mask, trades without a value). One position at a time (the grid's sequencing)."""
    T=len(sess_ord);O=np.zeros(T);open_=np.zeros(T,bool);realised=np.zeros(T);bad=0
    for x in trades:
        if not math.isfinite(x['unit']):bad+=1;continue
        u=x['units'];e0=dt.date.fromisoformat(x['entry_day']).toordinal();e1=dt.date.fromisoformat(x['exit_day']).toordinal()
        c=x.get('sign',1.)*x.get('index',0.)*carry/365. if structure=='futures' and carry else 0.   # assumed carry, points per unit per day
        i0=int(np.searchsorted(sess_ord,e0));i1=int(np.searchsorted(sess_ord,e1))
        mo=np.asarray(x['mark_ord'],np.int64);mv=np.asarray(x['marks'],float);fin=np.isfinite(mv)
        si=np.searchsorted(sess_ord,mo[fin]);mv=mv[fin]-c*(mo[fin]-e0)
        seg=np.full(max(min(i1,T)-i0,0),np.nan)
        for j,v in zip(si,mv):
            if i0<=j<min(i1,T):seg[j-i0]=v                                         # later marks of the same session overwrite: last close
        if len(seg):
            ok=np.isfinite(seg);fill=np.where(ok,np.arange(len(seg)),-1);np.maximum.accumulate(fill,out=fill)
            seg=np.where(fill>=0,seg[np.maximum(fill,0)],0.)
            O[i0:i0+len(seg)]=seg*u;open_[i0:i0+len(seg)]=True
        final=(x['unit']-c*(e1-e0))*u
        if i1<T:realised[i1]+=final
        elif T:O[T-1]=final;open_[T-1]=True                                          # open at the window end: the grid's window-end value
    return np.cumsum(realised)+O,open_,bad

# ---------------- pair evaluation ----------------
def year_slices(sess_days,lo,hi,factor=None):
    """[(year, i_start, i_end, annualisation, calendar days covered)]: sessions of each calendar year inside [lo, hi). A part
    year (the window starts or ends inside it, or the data does) is annualised over the calendar days it covers: 365 / days."""
    out=[];inside=[i for i,d in enumerate(sess_days) if lo<=d<hi]
    if not inside:return out
    end=min(dt.date.fromisoformat(hi),dt.date.fromisoformat(sess_days[-1])+dt.timedelta(1));lo_d=dt.date.fromisoformat(lo)   # clipped where the data ends, not the window's last session
    for y in sorted({sess_days[i][:4] for i in inside}):
        idx=[i for i in inside if sess_days[i][:4]==y];y=int(y)
        days=(min(end,dt.date(y+1,1,1))-max(lo_d,dt.date(y,1,1))).days
        out.append((y,idx[0],idx[-1],365./max(days,1),days))
    return out

def pair_metrics(G,R,i0,i1,ys,capital,span_years,chunk=64,min_days=90):
    """All green x red pairs over sessions [i0, i1]: yearly returns (nG, nR, Y), overall return, worst year, max drawdown.
    A year covering fewer than min_days calendar days is not annualised and is left out of the worst year (too short to judge).
    Equity at a session = G + R; P&L of a year = equity at its last session - equity at the session before it (0 before i0)."""
    base=lambda A,i:A[:,i-1] if i>i0 else np.zeros(len(A))
    fy=[f if d>=min_days else 1. for *_,f,d in ys];yG=np.stack([(G[:,b]-base(G,a))*f for (_,a,b,*_),f in zip(ys,fy)],1);yR=np.stack([(R[:,b]-base(R,a))*f for (_,a,b,*_),f in zip(ys,fy)],1)
    Y=(yG[:,None,:]+yR[None,:,:])/capital
    tot=((G[:,i1]-base(G,i0))[:,None]+(R[:,i1]-base(R,i0))[None,:])/capital/span_years
    dd=np.empty((len(G),len(R)))
    g0=base(G,i0);r0=base(R,i0)
    for a in range(0,len(G),chunk):
        S=(G[a:a+chunk,None,i0:i1+1]-g0[a:a+chunk,None,None])+(R[None,:,i0:i1+1]-r0[None,:,None])
        S=np.concatenate([np.zeros(S.shape[:2]+(1,)),S],2)                       # equity starts at 0 (capital) at the window start
        dd[a:a+chunk]=(np.maximum.accumulate(S,2)-S).max(2)
    judged=[j for j,y in enumerate(ys) if y[4]>=min_days] or list(range(len(ys)))
    return Y,tot,Y[:,:,judged].min(2),dd

def rank_key(rank,tot,worst,dd):
    if rank=='worst_year':return -worst,-tot
    if rank=='calmar':return -(tot/np.maximum(dd,1.)),-tot
    return dd,-tot

# ---------------- main flow ----------------
def run(grid,paths_db,out,capital=CAPITAL,target=.22,floor=.17,max_dd=250_000.,rank='dd',pool=150,min_trades=15,carry=.055,top=50,
        holidays=(),workers=1,progress=True,min_days=90):
    grid=Path(grid);out=Path(out);out.mkdir(parents=True,exist_ok=True);t0=time.time()
    gi=zg.read_json(grid/'grid_index.json');start,split=gi['start'],gi['split'];factor=_year_factor(start,split)
    wins=[w[0] for w in gi['windows']];test_years=sorted(int(w[5:]) for w in wins if w.startswith('test_'))
    folds={f'test_{y}':(f'train_{y}',[t for t in test_years+[int(start[:4])] if t<y]) for y in test_years if f'train_{y}' in wins}
    folds={k:(w,sorted(set(v))) for k,(w,v) in folds.items()};folds['in_sample']=('train_full',sorted(set(test_years+[int(start[:4])])))
    P,_=pools(grid,folds,factor,pool,min_trades,workers)
    if progress:print(f'pools: '+', '.join(f'{f} {s} {len(v)}' for (f,s),v in sorted(P.items()))+f' ({time.time()-t0:.0f}s)',flush=True)
    D=zg.Detail(paths_db,holidays);sess_days=sorted({d for d in D.bars.day if start<=d<split});sess_ord=np.array([dt.date.fromisoformat(d).toordinal() for d in sess_days])
    curves={};files={}
    def curve(key):
        if key not in curves:
            side,st,off,cfg,prof,stop=key;tr=D.trades(dict(side=side,structure=st,offset=off,config=cfg,profit=prof,stop=stop),start,split)
            curves[key]=equity(tr,sess_ord,st,carry)+(len(tr),)
        return curves[key]
    allkeys=sorted({k for v in P.values() for k in v},key=lambda k:(k[1],k[2],k[0]))   # group order: one Batch build per group
    for (f,s),v in P.items():files.update(v)
    for i,k in enumerate(allkeys):
        curve(k)
        if progress and (i+1)%500==0:print(f'  replayed {i+1}/{len(allkeys)} ({time.time()-t0:.0f}s)',flush=True)
    if progress:print(f'replayed {len(allkeys)} strategies ({time.time()-t0:.0f}s)',flush=True)
    gates=[];wf=[];ins=[];report=dict(start=start,split=split,min_year_days=min_days,capital=capital,target=target,floor=floor,max_drawdown=max_dd,rank=rank,pool=pool,min_trades=min_trades,carry=carry,
                                       note='Returns: rupee P&L / capital per calendar year (part years annualised), no compounding. in_sample rows are fitted to the past.',folds={})
    for fold,(wname,years) in folds.items():
        g=[k for k in P.get((fold,'bull'),{}) if curves[k][2]==0];r=[k for k in P.get((fold,'bear'),{}) if curves[k][2]==0]
        lo=start;hi=f'{fold[5:]}-01-01' if fold.startswith('test_') else split
        ys=year_slices(sess_days,lo,hi)
        if not g or not r or not ys:report['folds'][fold]=dict(note='no candidates');continue
        i0=ys[0][1];i1=ys[-1][2];span=sum(d for *_,d in ys)/365.
        G=np.stack([curves[k][0] for k in g]);R=np.stack([curves[k][0] for k in r])
        Y,tot,worst,dd=pair_metrics(G,R,i0,i1,ys,capital,span,min_days=min_days)
        p1=tot>=target;p2=worst>=floor;p3=dd<=max_dd;ok=p1&p2&p3
        gates.append(dict(fold=fold,pairs=int(ok.size),pass_target=int(p1.sum()),pass_floor=int(p2.sum()),pass_drawdown=int(p3.sum()),pass_target_and_floor=int((p1&p2).sum()),pass_all=int(ok.sum())))
        k1,k2=rank_key(rank,tot,worst,dd);order=np.lexsort((k2.ravel(),k1.ravel()));order=order[ok.ravel()[order]]
        if not len(order):                                                          # nothing passes: the closest pairs by total shortfall
            short=np.maximum(target-tot,0)/target+np.maximum(floor-worst,0)/max(floor,1e-9)+np.maximum(dd-max_dd,0)/max_dd
            order=np.argsort(short.ravel(),kind='stable')[:top];passed=False
        else:passed=True
        rows=[]
        for f_ in order[:top]:
            a,b=np.unravel_index(int(f_),ok.shape)
            rows.append(dict(fold=fold,passed=bool(ok[a,b]),overall=round(float(tot[a,b]),4),worst_year=round(float(worst[a,b]),4),max_drawdown=round(float(dd[a,b])),
                             **{f'year_{y}'+('' if ys[j][4]>=min_days else f'_part_{ys[j][4]}d_not_annualised'):round(float(Y[a,b,j]),4) for j,(y,*_) in enumerate(ys)},
                             overlap_sessions=int((curves[g[a]][1][i0:i1+1]&curves[r[b]][1][i0:i1+1]).sum()),
                             **_leg('green',g[a],curves),**_leg('red',r[b],curves)))
        if rows:
            rows[0].update(_robust(rows[0],g,r,curves,curve,files,D,ys,i0,i1,capital,span,target,floor,max_dd,grid,min_days))
        if fold=='in_sample':ins=rows
        else:
            y=int(fold[5:]);best=rows[0];oos=_oos(best,curves,sess_days,y,capital,split,min_days)
            wf.append(dict(test_year=y,chosen_on=f'{start}..{y-1}',passed_in_training=passed,**{k:v for k,v in best.items() if k!='fold'},**oos))
        report['folds'][fold]=dict(pairs=int(ok.size),pass_all=int(ok.sum()),best=rows[0] if rows else None)
    D.close()
    full=[w for w in wf if w['test_return'] is not None and w.get('test_annualised')]
    if full:
        wf_=wf;wf=full;oo=[w['test_return'] for w in wf];report['walk_forward']=dict(years=[w['test_year'] for w in wf],returns=oo,mean=round(float(np.mean(oo)),4),worst=round(float(min(oo)),4),
            max_drawdown_within_a_year=max(w['test_max_drawdown'] for w in wf),meets_target=bool(np.mean(oo)>=target),meets_floor_every_year=bool(min(oo)>=floor),
            within_drawdown_limit=bool(max(w['test_max_drawdown'] for w in wf)<=max_dd),note='full test years only (part years under --min-year-days excluded)')
        wf=wf_
    _csv(out/'portfolio_walk_forward.csv',wf);_csv(out/'portfolio_pairs_in_sample.csv',ins);_csv(out/'portfolio_gate_counts.csv',gates)
    report['gate_counts']=gates;zg.write_json(report,out/'portfolio_report.json',indent=1,default=str)
    return report,wf,ins,gates

def _leg(name,key,curves):
    side,st,off,cfg,prof,stop=key
    return {f'{name}_structure':st,f'{name}_offset':off,f'{name}_config':cfg,f'{name}_profit':prof,f'{name}_stop':stop,f'{name}_trades':curves[key][3]}

def _oos(best,curves,sess_days,y,capital,split,min_days=90):
    """The chosen pair in its test year: return (annualised if a part year), drawdown inside the year."""
    g=tuple(best[f'green_{k}'] for k in ('structure','offset','config','profit','stop'));r=tuple(best[f'red_{k}'] for k in ('structure','offset','config','profit','stop'))
    E=curves[('bull',)+g][0]+curves[('bear',)+r][0];ys=year_slices(sess_days,f'{y}-01-01',min(f'{y+1}-01-01',split))
    if not ys:return dict(test_return=None,test_max_drawdown=None)
    _,a,b,f,days=ys[0];f=f if days>=min_days else 1.;e0=E[a-1] if a>0 else 0.;S=np.concatenate([[0.],E[a:b+1]-e0])
    return dict(test_return=round(float((E[b]-e0)/capital*f),4),test_days=days,test_annualised=days>=min_days,test_pnl=round(float(E[b]-e0)),test_max_drawdown=round(float((np.maximum.accumulate(S)-S).max())),
                test_overlap_sessions=int((curves[('bull',)+g][1][a:b+1]&curves[('bear',)+r][1][a:b+1]).sum()))

def _neighbour_keys(key,grid,file):
    """One-step neighbours of a strategy inside its grid file (configuration, profit rule, stop rule)."""
    with np.load(grid/file) as z:configs=list(z['configs']);P=list(z['profits']);S=list(z['stops'])
    side,st,off,cfg,prof,stop=key;ci,pi,si=configs.index(cfg),P.index(prof),S.index(stop)
    CN=zr.config_neighbours(configs);PN=zr.neighbours(P);SN=zr.compound_neighbours(S) if stop.startswith('c:') else zr.neighbours(S)
    out=[(side,st,off,configs[j],prof,stop) for j in CN[ci] if j>=0]+[(side,st,off,cfg,P[j],stop) for j in PN[pi] if j>=0]+[(side,st,off,cfg,prof,S[j]) for j in SN[si] if j>=0]
    return out

def _robust(row,g,r,curves,curve,files,D,ys,i0,i1,capital,span,target,floor,max_dd,grid,min_days):
    """Swap each leg for its one-step neighbours (other leg fixed): share of neighbour pairs passing every gate."""
    gk=('bull',row['green_structure'],row['green_offset'],row['green_config'],row['green_profit'],row['green_stop'])
    rk=('bear',row['red_structure'],row['red_offset'],row['red_config'],row['red_profit'],row['red_stop'])
    res=[]
    for mine,other,is_green in ((gk,rk,True),(rk,gk,False)):
        f=files.get(mine)
        if f is None:continue
        for nk in _neighbour_keys(mine,grid,f):
            c=curve(nk)
            if c[2]:res.append(False);continue
            G=np.stack([c[0] if is_green else curves[other][0]]);R=np.stack([curves[other][0] if is_green else c[0]])
            Y,tot,worst,dd=pair_metrics(G,R,i0,i1,ys,capital,span,min_days=min_days)
            res.append(bool(tot[0,0]>=target and worst[0,0]>=floor and dd[0,0]<=max_dd))
    return dict(neighbour_pairs=len(res),neighbour_pass_share=round(sum(res)/len(res),3) if res else None)

def _csv(path,rows):
    keys=[];[keys.append(k) for r in rows for k in r if k not in keys]
    with open(path,'w',newline='') as f:w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--grid',required=True,help='zone_grid.py output directory');ap.add_argument('--paths',required=True,help='the zone_paths.sqlite the grid was built from')
    ap.add_argument('--out',default='portfolio');ap.add_argument('--capital',type=float,default=CAPITAL)
    ap.add_argument('--target',type=float,default=.22,help='overall yearly return on capital (pre-tax)');ap.add_argument('--floor',type=float,default=.17,help='minimum return in every calendar year')
    ap.add_argument('--max-dd',type=float,default=250_000.,help='largest allowed fall of combined daily equity from its peak, rupees')
    ap.add_argument('--rank',choices=('dd','worst_year','calmar'),default='dd');ap.add_argument('--pool',type=int,default=150,help='candidates per side, window and criterion')
    ap.add_argument('--min-trades',type=int,default=15);ap.add_argument('--carry',type=float,default=.055);ap.add_argument('--top',type=int,default=50)
    ap.add_argument('--min-year-days',type=int,default=90,help='a part year shorter than this is not annualised and not held to --floor')
    ap.add_argument('--holidays');ap.add_argument('--workers',type=int,default=1)
    a=ap.parse_args(argv)
    gi=zg.read_json(Path(a.grid)/'grid_index.json');hol=zr.read_holidays(a.holidays) if a.holidays else []
    if sorted(hol)!=sorted(gi.get('holidays',[])):sys.exit('--holidays must be the list the grid was built with')
    if zg.digest(a.paths)!=gi['paths_sha256']:sys.exit(f'{a.paths} is not the paths file the grid was built from')
    rep,wf,ins,gates=run(a.grid,a.paths,a.out,a.capital,a.target,a.floor,a.max_dd,a.rank,a.pool,a.min_trades,a.carry,a.top,hol,a.workers,min_days=a.min_year_days)
    print('\nPairs passing each gate (training data of each window):')
    for g in gates:print(f"  {g['fold']:10} pairs {g['pairs']:>9}  target {g['pass_target']:>8}  floor {g['pass_floor']:>8}  drawdown {g['pass_drawdown']:>8}  all {g['pass_all']:>7}")
    print('\nWalk-forward (pair chosen on earlier years only; return = rupee P&L / capital):')
    for w in wf:
        r=w['test_return'];print(f"  {w['test_year']}: {'n/a' if r is None else f'{r:.1%}'}{'' if w.get('test_annualised',True) else ' (part year, '+str(w['test_days'])+' days, not annualised)'}  drawdown Rs {w['test_max_drawdown']:,}  "
              f"chosen {'passing' if w['passed_in_training'] else 'CLOSEST (none passed)'}: green {w['green_structure']} {w['green_offset']:+.0f} {w['green_config']} {w['green_profit']} {w['green_stop']} | "
              f"red {w['red_structure']} {w['red_offset']:+.0f} {w['red_config']} {w['red_profit']} {w['red_stop']}")
    if 'walk_forward' in rep:
        s=rep['walk_forward'];print(f"  mean {s['mean']:.1%}, worst year {s['worst']:.1%}, largest in-year drawdown Rs {s['max_drawdown_within_a_year']:,}; "
                                    f"target {'met' if s['meets_target'] else 'NOT met'}, floor {'met' if s['meets_floor_every_year'] else 'NOT met'}, drawdown {'within' if s['within_drawdown_limit'] else 'OVER'} limit")
    if ins:
        b=ins[0];print(f"\nIn-sample best ({'passes' if b['passed'] else 'closest; none pass'}), fitted to {rep['start']}..{rep['split']}: overall {b['overall']:.1%}, worst year {b['worst_year']:.1%}, "
                       f"drawdown Rs {b['max_drawdown']:,}, neighbour pass share {b.get('neighbour_pass_share')}")
    print(f'-> {a.out}/portfolio_walk_forward.csv, portfolio_pairs_in_sample.csv, portfolio_gate_counts.csv, portfolio_report.json')

if __name__=='__main__':main()
