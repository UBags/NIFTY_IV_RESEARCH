#!/usr/bin/env python3
"""Option outcomes for the INDEX v15 zone + swing signals. Writes every trade; does not rank.

For each signal bar and side, every structure x strike offset x take-profit is simulated once and shared by
all signal configurations that fire on that bar (zone_report.py joins them).

  bull: rising valley in a green zone -> sell puts;  bear: falling peak in a red zone -> sell calls.
  naked:    sell the nearest expiry with at least --min-short-days calendar days left.
  calendar: same short, buy the same strike in the expiry nearest --long-target days (more than 30 left).
            On the short's expiry day the pair is closed at the 15:15 bar and, if the zone still holds,
            a new pair is opened on the current index level. The long is also closed at 30 days left.
  Exit at once, at the next bar's open, when the zone leaves its colour. Optional take-profit: naked at
  a share of the credit, calendar at a share of the debit, checked on bar-close option prices.
  A short reaching its expiry is cash-settled on the 15:00-15:29 spot TWAP proxy (else the 15:29 close).

Fills: next bar's open, first of three minutes where every leg has a bar with volume >= lots / --max-participation.
Either vendor's bar is used for a contract (the one with volume, rissin_upstox first); the vendor is recorded.
OHLC minute bars are not bid/ask quotes. Charges and slippage use calendar_research's dated schedule.
"""
from __future__ import annotations
import argparse,collections,datetime as dt,json,math,sqlite3,sys
from pathlib import Path
from types import SimpleNamespace
from calendar_research import fill_detail
from contract_specs_v2 import LotMaster
from prepare_research_cache import TIMES
import zone_signals as zs

PROVIDERS=('rissin_upstox','thetrademarkk')
_bar_ends=list(range(zs.OPEN,zs.CLOSE,45))
ZONE_TIMES=sorted(set(TIMES)|{zs.hhmm(e-1) for e in _bar_ends[1:]}|{'15:29'}|{zs.hhmm(e+i) for e in _bar_ends for i in range(3)})
STRUCTURES=('naked','calendar');OFFSETS=(-200,-100,0,100,200);TPS=(None,.25,.4,.5,.6,.75)
ROLL_BAR_END=15*60+15

def days_between(a,b):return (dt.date.fromisoformat(b)-dt.date.fromisoformat(a)).days

class Market:
    """Option bars by (day, minute), both vendors merged per contract; spot settlement references."""
    def __init__(self,path,keep=4):
        self.db=sqlite3.connect(f'file:{path}?mode=ro',uri=True);self.keep=keep;self.cache=collections.OrderedDict()
        self.daily={r[0]:dict(close=r[1]) for r in self.db.execute('SELECT day,close FROM spot_daily')}
        if self.db.execute("SELECT 1 FROM sqlite_master WHERE name='spot_daily_ext'").fetchone():
            for d,tw,n in self.db.execute('SELECT day,twap_1500_1529,twap_minutes FROM spot_daily_ext'):
                if d in self.daily:self.daily[d].update(twap=tw,twap_minutes=n)
        recent=[r[0] for r in self.db.execute('SELECT day FROM spot_daily ORDER BY day DESC LIMIT 20')]
        have={r[0] for p in PROVIDERS for r in self.db.execute(f"SELECT DISTINCT substr(ts,12,5) FROM opt WHERE provider=? AND day IN ({','.join('?'*len(recent))})",(p,*recent))}
        self.missing_minutes=sorted(set(ZONE_TIMES)-have)
    def day(self,day):
        if day in self.cache:self.cache.move_to_end(day);return self.cache[day]
        out=collections.defaultdict(dict)
        for p in PROVIDERS:
            for m,e,k,cp,o,h,l,c,v in self.db.execute('SELECT substr(ts,12,5),expiry,strike,cp,open,high,low,close,volume FROM opt WHERE provider=? AND day=?',(p,day)):
                key=(e,float(k),cp);old=out[m].get(key)
                if old is None or (not old[4] and v):out[m][key]=(o,h,l,c,v or 0,p)
        self.cache[day]=out
        while len(self.cache)>self.keep:self.cache.popitem(last=False)
        return out
    def quote(self,day,minute,expiry,strike,cp):return self.day(day).get(minute,{}).get((expiry,float(strike),cp))
    def expiries(self,day,minute):return sorted({k[0] for k in self.day(day).get(minute,{})})
    def settlement(self,expiry):
        row=self.daily.get(expiry) or {}
        if row.get('twap') and (row.get('twap_minutes') or 0)>=25:return row['twap'],'twap_1500_1529_proxy'
        q=self.quote_spot(expiry)
        if q:return q,'spot_1529_proxy'
        return (row['close'],'daily_close_proxy') if row.get('close') else None
    def quote_spot(self,day):
        r=self.db.execute("SELECT close FROM spot WHERE ts=?",(f'{day} 15:29:00',)).fetchone()
        return r[0] if r and r[0] else None

class Sim:
    def __init__(self,market,bars,final,cfg):
        self.m=market;self.bars=bars;self.final=final;self.cfg=cfg;self.lots=LotMaster(cfg.contract_master);self.trades=[];self.counts=collections.Counter()
    def window(self,t):
        b=self.bars[t]
        if b.end<zs.CLOSE:return b.day,[zs.hhmm(b.end+i) for i in range(3)]
        return (self.bars[t+1].day,['09:15','09:16','09:17']) if t+1<len(self.bars) else None
    def liquid(self,q,lot):return q is not None and q[0] and q[0]>0 and q[4]>=lot*self.cfg.lots/self.cfg.max_participation
    def fill(self,pos,leg,q,day,minute,label):
        units=-leg['units'] if label!='open' else leg['units']
        cash,executed,slip,charges=fill_detail(q[0],units,day,self.cfg,leg['expiry'],q[4]/pos['lot'],None,None,pos['lot'])
        pos['cash']+=cash;pos['fills'].append(dict(event=label,day=day,minute=minute,expiry=leg['expiry'],strike=leg['strike'],cp=leg['cp'],units=units,ref=q[0],price=executed,slip=slip,charges=charges['total'],cash=cash,volume=q[4],vendor=q[5]))
    def open(self,t,side,structure,offset,tp,chain=None,roll=0):
        b=self.bars[t];cp='PE' if side=='bull' else 'CE';strike=float(round(b.close/100)*100+offset)
        spec=dict(side=side,structure=structure,offset=offset,tp=tp,signal_bar=t if chain is None else chain['signal_bar'],roll=roll)
        exps=self.m.expiries(b.day,b.mark_minute)
        short=next((e for e in exps if days_between(b.day,e)>=self.cfg.min_short_days),None)
        if short is None:return self.reject(spec,b,'no_short_expiry')
        lot=self.lots.get(b.day,short).qty
        if not lot:return self.reject(spec,b,'lot_unknown')
        legs=[dict(expiry=short,strike=strike,cp=cp,units=-lot*self.cfg.lots)];long=None
        if structure=='calendar':
            far=[e for e in exps if e>short and days_between(b.day,e)>30]
            if not far:return self.reject(spec,b,'no_long_expiry')
            long=min(far,key=lambda e:(abs(days_between(b.day,e)-self.cfg.long_target),e))
            if self.lots.get(b.day,long).qty!=lot:return self.reject(spec,b,'lot_mismatch')
            legs.append(dict(expiry=long,strike=strike,cp=cp,units=lot*self.cfg.lots))
        w=self.window(t)
        if w is None:return self.reject(spec,b,'no_next_bar')
        day,mins=w
        for minute in mins:
            qs=[self.m.quote(day,minute,l['expiry'],l['strike'],l['cp']) for l in legs]
            if all(self.liquid(q,lot) for q in qs):break
        else:return self.reject(spec,b,'no_liquid_entry')
        pos=dict(spec,id=None,lot=lot,legs=legs,open={i:l for i,l in enumerate(legs)},cash=0.,fills=[],entry_day=day,entry_minute=minute,signal_day=b.day,
                 short_expiry=short,long_expiry=long,long_days=days_between(b.day,long) if long else None,strike=strike,atm=strike-offset,pending=None,status='open')
        for l,q in zip(legs,qs):self.fill(pos,l,q,day,minute,'open')
        pos['base']=pos['cash'] if structure=='naked' else -pos['cash']
        pos['id']=f"{side}|{structure}|{offset}|{tp}|{spec['signal_bar']}|{roll}";pos['chain']=chain['id'] if chain else pos['id']
        self.counts['opened']+=1;return pos
    def reject(self,spec,b,why):
        self.counts['reject_'+why]+=1
        if spec['roll']:self.counts['roll_reopen_failed']+=1
        else:self.trades.append(dict(spec,id=f"{spec['side']}|{spec['structure']}|{spec['offset']}|{spec['tp']}|{spec['signal_bar']}|0",chain=None,status='no_fill',reason=why,signal_day=b.day))
        return None
    def settle(self,pos,i,leg):
        ref=self.m.settlement(leg['expiry'])
        if ref is None:pos['status']='unresolved';self.counts['settlement_missing']+=1;return False
        s,src=ref;intrinsic=max(0.,s-leg['strike']) if leg['cp']=='CE' else max(0.,leg['strike']-s)
        cash=leg['units']*intrinsic;pos['cash']+=cash
        pos['fills'].append(dict(event='settle',day=leg['expiry'],minute='15:30',expiry=leg['expiry'],strike=leg['strike'],cp=leg['cp'],units=-leg['units'],ref=s,price=intrinsic,source=src,cash=cash))
        del pos['open'][i];return True
    def close(self,pos,t,reason):
        """Try to flatten at bar t's exit window. A long is not sold while its short is open."""
        b=self.bars[t];pos['pending']=pos['pending'] or reason
        for i,leg in list(pos['open'].items()):
            if leg['expiry']<b.day or (leg['expiry']==b.day and b.end==zs.CLOSE):self.settle(pos,i,leg)
        if pos['status']=='unresolved':return True
        w=self.window(t)
        if pos['open'] and w:
            day,mins=w
            for minute in mins:
                live={i:l for i,l in pos['open'].items() if l['expiry']>=day}
                qs={i:self.m.quote(day,minute,l['expiry'],l['strike'],l['cp']) for i,l in live.items()}
                if live and all(self.liquid(q,pos['lot']) for q in qs.values()):
                    for i,l in live.items():self.fill(pos,l,qs[i],day,minute,'close');del pos['open'][i]
                    break
                for i,l in sorted(live.items(),key=lambda x:x[1]['units']):
                    if l['units']>0 and any(x['units']<0 for x in pos['open'].values()):continue
                    if self.liquid(qs[i],pos['lot']):self.fill(pos,l,qs[i],day,minute,'close');del pos['open'][i]
                if not pos['open']:break
        if pos['open']:
            pos['pending_bars']=pos.get('pending_bars',0)+1
            if 0<=self.cfg.max_exit_lag_bars<pos['pending_bars'] and not any(l['units']<0 for l in pos['open'].values()):
                for i,l in list(pos['open'].items()):
                    last=pos.get('last_close',{}).get(i)
                    if last is None:continue
                    px=last*(1-self.cfg.forced_exit_haircut);cash=-l['units']*px
                    pos['cash']+=cash;pos['fills'].append(dict(event='forced_exit_lag_cap',day=b.day,minute=b.mark_minute,expiry=l['expiry'],strike=l['strike'],cp=l['cp'],units=-l['units'],ref=last,price=px,cash=cash,executable_claim=False))
                    del pos['open'][i];self.counts['forced_exit_lag_cap']+=1
            if pos['open']:self.counts['exit_pending_bar']+=1;return False
        pos['status']='closed';pos['reason']=pos['pending'];pos['exit_day'],pos['exit_minute']=(pos['fills'][-1]['day'],pos['fills'][-1]['minute']);pos['exit_bar']=t
        return True
    def marks(self,pos,b):
        value=0.;fresh=True
        for i,l in pos['open'].items():
            q=self.m.quote(b.day,b.mark_minute,l['expiry'],l['strike'],l['cp'])
            if q and q[3]:pos.setdefault('last_close',{})[i]=q[3]
            if not q or not q[3] or not q[4]:fresh=False;continue
            value+=l['units']*q[3]
        return value if fresh else None
    def step(self,pos,t):
        """Bar-close decision for one position. Returns a new rolled position or None."""
        b=self.bars[t];colour='G' if pos['side']=='bull' else 'R';v=self.marks(pos,b)
        if pos['pending']:done=self.close(pos,t,pos['pending']);return self.after(pos,t) if done else None
        reason=None
        if self.final[t]!=colour:reason='zone_flip'
        elif pos['structure']=='calendar' and b.day>=pos['short_expiry'] and (b.end>=ROLL_BAR_END or b.day>pos['short_expiry']):reason='short_expiry_roll'
        elif pos['structure']=='calendar' and days_between(b.day,pos['long_expiry'])<=30:reason='long_30dte'
        elif pos['tp'] and pos['base']>0:
            if v is not None and pos['cash']+v>=pos['tp']*pos['base']:reason='take_profit'
        if reason is None and pos['structure']=='naked' and (b.day>pos['short_expiry'] or (b.day==pos['short_expiry'] and b.end==zs.CLOSE)):reason='expiry'
        if reason is None:return None
        return self.after(pos,t) if self.close(pos,t,reason) else None
    def after(self,pos,t):
        self.record(pos)
        colour='G' if pos['side']=='bull' else 'R'
        if pos['status']=='closed' and pos['reason'] in ('short_expiry_roll','long_30dte') and self.final[t]==colour:
            return self.open(t,pos['side'],pos['structure'],pos['offset'],pos['tp'],chain=dict(id=pos['chain'],signal_bar=pos['signal_bar']),roll=pos['roll']+1)
        return None
    def record(self,pos):
        pnl=pos['cash'] if pos['status']=='closed' else None
        self.trades.append(dict({k:pos[k] for k in ('id','chain','side','structure','offset','tp','signal_bar','roll','signal_day','entry_day','entry_minute','short_expiry','long_expiry','long_days','strike','atm','lot','base','status')},
            reason=pos.get('reason') or pos['pending'],exit_day=pos.get('exit_day'),exit_minute=pos.get('exit_minute'),exit_bar=pos.get('exit_bar'),pnl_inr=pnl,
            unit_pnl=pnl/(pos['lot']*self.cfg.lots) if pnl is not None else None,fills=pos['fills']))
    def run(self,entries,structures=STRUCTURES,offsets=OFFSETS,tps=TPS,progress=True):
        live=[];last_day=None
        for t,b in enumerate(self.bars):
            nxt=[]
            for pos in live:
                new=self.step(pos,t)
                if pos['status']=='open':nxt.append(pos)
                if new:nxt.append(new)
            for side in entries.get(t,()):
                for s in structures:
                    for o in offsets:
                        for tp in tps:
                            p=self.open(t,side,s,o,tp)
                            if p:nxt.append(p)
            live=nxt
            if progress and b.day[:7]!=last_day:
                last_day=b.day[:7];print(f'{last_day} open positions {len(live)} trades {len(self.trades)}',flush=True)
        for pos in live:pos['status']='open_at_data_end';self.record(pos)
        return self.trades

DDL='''CREATE TABLE meta(name TEXT PRIMARY KEY,value TEXT);
CREATE TABLE bars(idx INTEGER PRIMARY KEY,day TEXT,end_minute TEXT,close REAL,zone TEXT);
CREATE TABLE signals(config TEXT,side TEXT,bar INTEGER);
CREATE TABLE trades(id TEXT PRIMARY KEY,chain TEXT,side TEXT,structure TEXT,offset REAL,tp REAL,signal_bar INTEGER,roll INTEGER,signal_day TEXT,entry_day TEXT,entry_minute TEXT,
 exit_day TEXT,exit_minute TEXT,exit_bar INTEGER,short_expiry TEXT,long_expiry TEXT,long_days INTEGER,strike REAL,atm REAL,lot INTEGER,base REAL,status TEXT,reason TEXT,pnl_inr REAL,unit_pnl REAL,fills TEXT);
CREATE INDEX trades_chain ON trades(chain);CREATE INDEX signals_cfg ON signals(config,side);'''

def config(a):
    return SimpleNamespace(slippage=a.slippage,slippage_mode='tenor_volume',fill_model='next_bar_open',brokerage=a.brokerage,gst=.18,exchange_bps=None,sebi_bps=.01,stt=None,stamp=.00003,
        brokerage_order_mode='per_lot_orders',lots=a.lots,max_exit_lag_bars=a.max_exit_lag_bars,forced_exit_haircut=a.forced_exit_haircut,max_participation=a.max_participation,min_short_days=a.min_short_days,long_target=a.long_target,contract_master=a.contract_master)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--spot',help='zone_spot.sqlite');ap.add_argument('--cache',help='Cache built with --times from --print-times')
    ap.add_argument('--out',default='zone_trades.sqlite');ap.add_argument('--from-date',default='2021-06-01');ap.add_argument('--to-date',default='2026-07-01')
    ap.add_argument('--slippage',type=float,default=.5);ap.add_argument('--brokerage',type=float,default=20.);ap.add_argument('--lots',type=int,default=1)
    ap.add_argument('--max-participation',type=float,default=.10);ap.add_argument('--min-short-days',type=int,default=4);ap.add_argument('--long-target',type=int,default=60)
    ap.add_argument('--max-exit-lag-bars',type=int,default=9,help='45-minute bars a long may wait for a liquid exit once its short is gone, then it is booked at its last bar-close price less the haircut (not a fill). -1 waits')
    ap.add_argument('--forced-exit-haircut',type=float,default=.02)
    ap.add_argument('--contract-master');ap.add_argument('--structures',default=','.join(STRUCTURES));ap.add_argument('--print-times',action='store_true',help='Print the cache minute list and stop')
    a=ap.parse_args()
    if a.print_times:print(','.join(ZONE_TIMES));return
    if not (a.spot and a.cache):ap.error('--spot and --cache are required')
    bars,final,_=zs.zones(zs.load_minutes(a.spot))
    sig=zs.signal_grid(bars,final)
    market=Market(a.cache)
    if market.missing_minutes:sys.exit(f'Cache lacks minutes {market.missing_minutes}: rebuild it with --times "$(python zone_backtest.py --print-times)"')
    entries=collections.defaultdict(set)
    for cfg_id,s in sig.items():
        for side in ('bull','bear'):
            for t in s[side]:
                if a.from_date<=bars[t].day<=a.to_date:entries[t].add(side)
    entries={t:sorted(v) for t,v in entries.items()}
    sim=Sim(market,bars,final,config(a));trades=sim.run(entries,structures=tuple(a.structures.split(',')))
    if Path(a.out).exists():Path(a.out).unlink()
    db=sqlite3.connect(a.out);db.executescript(DDL)
    db.executemany('INSERT INTO bars VALUES(?,?,?,?,?)',[(i,b.day,zs.hhmm(b.end),b.close,final[i]) for i,b in enumerate(bars)])
    db.executemany('INSERT INTO signals VALUES(?,?,?)',[(c,side,t) for c,s in sig.items() for side in ('bull','bear') for t in s[side]])
    cols=['id','chain','side','structure','offset','tp','signal_bar','roll','signal_day','entry_day','entry_minute','exit_day','exit_minute','exit_bar','short_expiry','long_expiry','long_days','strike','atm','lot','base','status','reason','pnl_inr','unit_pnl','fills']
    db.executemany(f'INSERT INTO trades VALUES({",".join("?"*len(cols))})',[tuple(json.dumps(t.get(c)) if c=='fills' else t.get(c) for c in cols) for t in trades])
    meta=dict(release=open(Path(__file__).with_name('VERSION.txt')).read().strip(),args=vars(a),counts=dict(sim.counts),zone_times=ZONE_TIMES,grid=zs.GRID,stale=zs.STALE)
    db.executemany('INSERT INTO meta VALUES(?,?)',[(k,json.dumps(v)) for k,v in meta.items()]);db.commit();db.close()
    print('Counts:',dict(sim.counts));print(f'{len(trades)} trade rows -> {a.out}')

if __name__=='__main__':main()
