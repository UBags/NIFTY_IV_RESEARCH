"""Zone + swing signal and option-backtest tests. Synthetic only; none of this is evidence of profitability."""
import sys,unittest,tempfile,sqlite3,math,json,datetime as dt,random,os
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ.setdefault('NIFTY_HOLDOUT_LOG',str(Path(tempfile.mkdtemp())/'log.jsonl'))
import numpy as np
import zone_signals as zs
import zone_backtest as zb
import zone_report as zr
from prepare_research_cache import DDL
from quant_v3 import black_forward

def sessions(start,n):
    d=dt.date.fromisoformat(start);out=[]
    while len(out)<n:
        if d.weekday()<5:out.append(d.isoformat())
        d+=dt.timedelta(1)
    return out

def walk(days,seed=1,drift=0.,vol=6.,start=20000.):
    """Minute bars 09:15-15:29 for each day: a random walk with optional drift per minute."""
    rnd=random.Random(seed);p=start;out={}
    for d in days:
        rows=[]
        for m in range(zs.OPEN,zs.CLOSE):
            o=p;p=max(100.,p+drift+rnd.gauss(0,vol));rows.append((m,o,max(o,p)+1,min(o,p)-1,p))
        out[d]=rows
    return out

class Bars(unittest.TestCase):
    def test_45_minute_session_alignment(self):
        b=zs.aggregate(walk(['2024-01-02']),45)
        self.assertEqual([x.end for x in b],[600,645,690,735,780,825,870,915,930])
        self.assertEqual(b[-1].start,915);self.assertEqual(b[0].mark_minute,'09:59');self.assertEqual(b[-1].mark_minute,'15:29')
    def test_higher_bars_do_not_cross_sessions(self):
        b=zs.aggregate(walk(['2024-01-02','2024-01-03']),360)
        self.assertEqual([(x.day,x.start,x.end) for x in b],[('2024-01-02',555,915),('2024-01-02',915,930),('2024-01-03',555,915),('2024-01-03',915,930)])
    def test_bar_ohlc(self):
        m=walk(['2024-01-02']);b=zs.aggregate(m,45)[0];rows=[r for r in m['2024-01-02'] if r[0]<600]
        self.assertEqual((b.open,b.high,b.low,b.close),(rows[0][1],max(r[2] for r in rows),min(r[3] for r in rows),rows[-1][4]))
    def test_htf_value_arrives_only_when_higher_bar_closes(self):
        chart=zs.aggregate(walk(['2024-01-02']),45);h=zs.aggregate(walk(['2024-01-02']),90)
        v=zs.sample(chart,h,list(range(len(h))))
        self.assertTrue(math.isnan(v[0]));self.assertEqual(list(v[1:]),[0,0,1,1,2,2,3,4])

class Indicators(unittest.TestCase):
    def test_ema_seed_and_wma(self):
        e=zs.ema(np.array([10.,20.]),3);self.assertEqual(e[0],10.);self.assertAlmostEqual(e[1],15.)
        w=zs.wma(np.array([1.,2.,3.]),3);self.assertTrue(math.isnan(w[1]));self.assertAlmostEqual(w[2],(1+4+9)/6)
    def test_pine_round(self):self.assertEqual([zs.pine_round(math.sqrt(x)) for x in (6,7,16,24)],[2,3,4,5])
    def test_atr_is_rma_seeded_with_sma(self):
        b=[zs.Bar('d',0,0,10,12,9,11),zs.Bar('d',0,0,11,13,10,12),zs.Bar('d',0,0,12,15,11,14)]
        a=zs.atr(b,2);self.assertTrue(math.isnan(a[0]));self.assertAlmostEqual(a[1],3.);self.assertAlmostEqual(a[2],(3+4)/2)

class Zones(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        days=sessions('2023-01-02',160)
        m=walk(days[:60],drift=.6);m.update(walk(days[60:110],seed=2,drift=-.7,start=m[days[59]][-1][4]));m.update(walk(days[110:],seed=3,drift=.5,start=m[days[109]][-1][4]))
        cls.minutes=m;cls.bars,cls.final,cls.aux=zs.zones(m)
    def test_trend_gives_both_colours(self):
        self.assertIn('G',self.final);self.assertIn('R',self.final)
    def test_persistence_needs_three_bars(self):
        pre=self.aux['pre']
        for i in range(3,len(pre)):
            if self.final[i]!=self.final[i-1] and self.final[i] is not None:self.assertEqual(pre[i-2:i+1],[self.final[i]]*3)
    def test_v14_equals_prefinal(self):
        _,f14,aux=zs.zones(self.minutes,fixed=False);self.assertEqual(f14,aux['pre'])
    def test_fixed_filter_changes_colour_less_often(self):
        _,f14,_=zs.zones(self.minutes,fixed=False)
        flips=lambda f:sum(f[i]!=f[i-1] for i in range(1,len(f)))
        self.assertLessEqual(flips(self.final),flips(f14))
    def test_no_lookahead(self):
        days=sorted(self.minutes);cut=days[120];m=dict(self.minutes)
        for d in days[121:]:m[d]=[(t,o*1.3,h*1.3,l*1.3,c*1.3) for t,o,h,l,c in m[d]]
        b2,f2,_=zs.zones(m);n=sum(1 for b in self.bars if b.day<=cut)
        self.assertEqual(self.final[:n],f2[:n])
        s1=zs.signal_grid(self.bars,self.final,dict(N=(3,),k=(.5,),m=(8,),j=(.25,),tw=(2,)));s2=zs.signal_grid(b2,f2,dict(N=(3,),k=(.5,),m=(8,),j=(.25,),tw=(2,)))
        for c in s1:
            for side in ('bull','bear'):self.assertEqual([t for t in s1[c][side] if t<n-8],[t for t in s2[c][side] if t<n-8])

def bar(i,lo,hi):return zs.Bar('2024-01-02',i,i+1,(lo+hi)/2,hi,lo,(lo+hi)/2)

class Swings(unittest.TestCase):
    def series(self,lows):return [bar(i,l,l+10) for i,l in enumerate(lows)]
    def test_pivot_tie_rule(self):
        self.assertEqual(zs.pivots([5,4,3,3,4,5,6],2,'low'),[2])
    def test_rising_valley_qualifies(self):
        lows=[100,95,90,95,100,105,110,115,108,102,97,102,107,112,117]
        b=self.series(lows);a=np.full(len(b),4.)
        ev=zs.swing_events(b,a,2,1.,8,1.)
        self.assertEqual(ev['low'],[(12,10,97)])   # 97-90=7 >= 4; highest high between 125-97=28 >= 4; gap 8
        self.assertEqual(zs.swing_events(b,a,2,1.,9,1.)['low'],[])   # spacing too short
        self.assertEqual(zs.swing_events(b,a,2,1.,8,2.)['low'],[])   # rise 7 < 8
        self.assertEqual(zs.swing_events(b,a,2,7.5,8,1.)['low'],[])  # swing 28 < 30
    def test_entry_waits_tw_and_needs_colour(self):
        lows=[100,95,90,95,100,105,110,115,108,102,97,102,107,112,117,118,119,120,121,122]
        b=self.series(lows);a=np.full(len(b),4.);ev=zs.swing_events(b,a,2,1.,8,1.)
        final=['G']*len(b)
        self.assertEqual(zs.entries(b,final,ev,2)['bull'],[14])
        final2=['R']*15+['G']*5
        self.assertEqual(zs.entries(b,final2,ev,2)['bull'],[15])   # the valley came first, the colour after
        self.assertEqual(zs.entries(b,['R']*len(b),ev,2)['bull'],[])
    def test_entry_cancelled_below_valley(self):
        lows=[100,95,90,95,100,105,110,115,108,102,97,102,107,112,90,90,90,90,90,90]
        b=self.series(lows);b[14]=zs.Bar('2024-01-02',14,15,95,100,90,95)
        a=np.full(len(b),4.);ev=zs.swing_events(b,a,2,1.,8,1.)
        self.assertEqual(zs.entries(b,['G']*len(b),ev,2)['bull'],[])
    def test_zone_only_control(self):
        f=[None,'R','R','G','G','G','G','R']
        self.assertEqual(zs.zone_only_entries(f,2)['bull'],[5]);self.assertEqual(zs.zone_only_entries(f,2)['bear'],[])

class Market(unittest.TestCase):
    """A small cache: one weekly and one far expiry, a flat index unless a test moves it."""
    def build(self,spot_path=None,days=None,level=None,far='2024-03-28',weekly='2024-01-11',extra=()):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        path=Path(self.tmp.name)/'c.sqlite';db=sqlite3.connect(path);db.executescript(DDL)
        days=days or sessions('2024-01-02',8);level=level or (lambda d,m:20000.)
        opt=[];ix=0
        for d in days:
            db.execute('INSERT INTO spot_daily VALUES(?,?,?,?,?,?,?,?)',(d,20000,20100,19900,level(d,'15:29'),375,1,1))
            db.execute('INSERT INTO spot_daily_ext VALUES(?,?,?,?,?,?,?)',(d,level(d,'15:29'),30,0,0,0,'ok'))
            db.execute('INSERT INTO spot VALUES(?,?,?,?,?,?,?)',(f'{d} 15:29:00',d,level(d,'15:29'),level(d,'15:29'),0,1,ix));ix+=1
            for m in zb.ZONE_TIMES:
                s=level(d,m)
                for e in (weekly,far,*extra):
                    t=(dt.datetime.fromisoformat(e+' 15:30')-dt.datetime.fromisoformat(f'{d} {m}')).total_seconds()/(365.25*86400)
                    if t<=0:continue
                    for k in (19800.,19900.,20000.,20100.,20200.):
                        for cp in ('PE','CE'):
                            p=max(.05,round(black_forward(s,k,t,.15,cp,.0),2))
                            opt.append(('rissin_upstox',f'{d} {m}:00',d,e,k,cp,p,p,p,p,100000,1,1,ix));ix+=1
        db.executemany('INSERT INTO opt VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',opt);db.commit();db.close()
        self.addCleanup(lambda:self.__dict__.get('_m') and self._m.db.close())
        self.days=days;return zb.Market(str(path))
    def cfg(self,**kw):
        a=SimpleNamespace(slippage=0.,brokerage=0.,lots=1,max_participation=.1,min_short_days=4,long_target=60,contract_master=None,max_exit_lag_bars=9,forced_exit_haircut=.02);a.__dict__.update(kw);return zb.config(a)
    def bars_for(self,days,level=lambda d,e:20000.):
        return [zs.Bar(d,s,min(s+45,zs.CLOSE),0,0,0,level(d,zs.hhmm(min(s+45,zs.CLOSE)-1))) for d in days for s in range(zs.OPEN,zs.CLOSE,45)]

class Backtest(Market):
    def test_naked_put_settles_at_expiry_when_zone_holds(self):
        m=self.build();bars=self.bars_for(self.days);final=['G']*len(bars)
        sim=zb.Sim(m,bars,final,self.cfg());tr=sim.run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,),progress=False)
        t=tr[0];self.assertEqual(t['status'],'closed');self.assertEqual(t['reason'],'expiry');self.assertEqual(t['short_expiry'],'2024-01-11')
        self.assertEqual(t['entry_minute'],'10:00');self.assertEqual(t['fills'][-1]['event'],'settle')
        self.assertAlmostEqual(t['pnl_inr'],t['fills'][0]['cash'])   # ATM put at a flat index expires worthless
    def test_nearest_expiry_with_four_days(self):
        days=sessions('2024-01-08',6);m=self.build(days=days,weekly='2024-01-11',far='2024-03-28');bars=self.bars_for(days)
        sim=zb.Sim(m,bars,['G']*len(bars),self.cfg());tr=sim.run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,),progress=False)
        self.assertEqual(tr[0]['short_expiry'],'2024-03-28')   # 2024-01-11 is 3 days away
    def test_zone_flip_exits_next_bar_open(self):
        m=self.build();bars=self.bars_for(self.days);final=['G']*5+['R']*(len(bars)-5)
        tr=zb.Sim(m,bars,final,self.cfg()).run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,),progress=False)
        t=tr[0];self.assertEqual(t['reason'],'zone_flip');self.assertEqual(t['exit_bar'],5);self.assertEqual((t['exit_day'],t['exit_minute']),(bars[5].day,zs.hhmm(bars[5].end)))
    def test_last_bar_exit_fills_next_morning(self):
        m=self.build();bars=self.bars_for(self.days);final=['G']*8+['R']*(len(bars)-8)
        t=zb.Sim(m,bars,final,self.cfg()).run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,),progress=False)[0]
        self.assertEqual((t['exit_day'],t['exit_minute']),(self.days[1],'09:15'))
    def test_take_profit_triggers_on_mark(self):
        days=sessions('2024-01-02',8);lv=lambda d,mm:20000.+(150. if d>=days[2] else 0.)
        m=self.build(days=days,level=lv);bars=self.bars_for(self.days,lambda d,e:lv(d,e));final=['G']*len(bars)
        tr=zb.Sim(m,bars,final,self.cfg()).run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,.5),progress=False)
        by={t['tp']:t for t in tr};self.assertEqual(by[.5]['reason'],'take_profit');self.assertGreater(by[.5]['pnl_inr'],.45*by[.5]['base'])
        self.assertEqual(by[None]['reason'],'expiry')
    def test_calendar_rolls_on_short_expiry_day(self):
        days=sessions('2024-01-02',12);m=self.build(days=days,weekly='2024-01-11',extra=('2024-01-18',));bars=self.bars_for(days)
        sim=zb.Sim(m,bars,['G']*len(bars),self.cfg());tr=sim.run({0:['bull']},structures=('calendar',),offsets=(0,),tps=(None,),progress=False)
        first=tr[0];self.assertEqual(first['reason'],'short_expiry_roll');self.assertEqual((first['exit_day'],first['exit_minute']),('2024-01-11','15:15'))
        self.assertEqual(first['long_expiry'],'2024-03-28')
        second=[t for t in tr if t['roll']==1 and t['chain']==first['chain']]
        self.assertEqual(len(second),1);self.assertEqual(second[0]['short_expiry'],'2024-03-28') if False else self.assertEqual(second[0]['entry_minute'],'15:15')
        self.assertEqual(second[0]['short_expiry'],'2024-01-18');self.assertGreater(second[0]['long_expiry'],second[0]['short_expiry'])
    def test_calendar_long_is_a_later_expiry(self):
        days=sessions('2024-01-08',6);m=self.build(days=days,weekly='2024-01-11');bars=self.bars_for(days)
        sim=zb.Sim(m,bars,['G']*len(bars),self.cfg());tr=sim.run({0:['bull']},structures=('calendar',),offsets=(0,),tps=(None,),progress=False)
        self.assertEqual(tr[0]['status'],'no_fill');self.assertEqual(tr[0]['reason'],'no_long_expiry')
    def test_long_never_sold_while_short_open(self):
        m=self.build();bars=self.bars_for(self.days);final=['G']*3+['R']*(len(bars)-3)
        con=sqlite3.connect(m.db.execute('PRAGMA database_list').fetchone()[2])
        con.execute("DELETE FROM opt WHERE expiry='2024-01-11' AND cp='PE' AND strike=20000 AND day=? AND substr(ts,12,5) IN ('11:30','11:31','11:32')",(self.days[0],));con.commit();con.close()
        m=zb.Market(m.db.execute('PRAGMA database_list').fetchone()[2])
        t=zb.Sim(m,bars,final,self.cfg()).run({0:['bull']},structures=('calendar',),offsets=(0,),tps=(None,),progress=False)[0]
        closes=[f for f in t['fills'] if f['event']=='close'];self.assertEqual(closes[0]['units'],lot_short_cover(closes))
        self.assertGreater((closes[1]['day'],closes[1]['minute']),('2024-01-02','11:30'))
    def test_charges_reduce_pnl(self):
        m=self.build();bars=self.bars_for(self.days)
        a=zb.Sim(m,bars,['G']*len(bars),self.cfg()).run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,),progress=False)[0]
        b=zb.Sim(m,bars,['G']*len(bars),self.cfg(brokerage=20.,slippage=.5)).run({0:['bull']},structures=('naked',),offsets=(0,),tps=(None,),progress=False)[0]
        self.assertLess(b['pnl_inr'],a['pnl_inr'])
    def test_missing_cache_minutes_detected(self):
        m=self.build();self.assertEqual(m.missing_minutes,[])

class LagCap(Market):
    def run_thin(self,cap):
        m=self.build();path=m.db.execute('PRAGMA database_list').fetchone()[2];bars=self.bars_for(self.days);final=['G']*3+['R']*(len(bars)-3)
        con=sqlite3.connect(path);con.execute("UPDATE opt SET volume=0 WHERE expiry='2024-03-28' AND ts>?",(f'{self.days[0]} 11:00:00',));con.commit();con.close()
        return zb.Sim(zb.Market(path),bars,final,self.cfg(max_exit_lag_bars=cap)).run({0:['bull']},structures=('calendar',),offsets=(0,),tps=(None,),progress=False)[0]
    def test_cap_books_long_at_last_close_less_haircut(self):
        t=self.run_thin(2);f=[x for x in t['fills'] if x['event']=='forced_exit_lag_cap'][0]
        self.assertEqual(t['status'],'closed');self.assertAlmostEqual(f['price'],f['ref']*.98);self.assertFalse(f['executable_claim'])
    def test_no_cap_keeps_waiting(self):
        self.assertEqual(self.run_thin(-1)['status'],'open_at_data_end')

def lot_short_cover(closes):return closes[0]['units'] if closes[0]['units']>0 else None

class Report(unittest.TestCase):
    def db(self,rows,signals):
        p=Path(tempfile.mkdtemp())/'t.sqlite';con=sqlite3.connect(p);con.executescript(zb.DDL)
        con.executemany('INSERT INTO bars VALUES(?,?,?,?,?)',[(i,d,'10:00',1.,'G') for i,d in enumerate(sessions('2022-01-03',800))])
        con.executemany('INSERT INTO signals VALUES(?,?,?)',signals)
        cols=['id','chain','side','structure','offset','tp','signal_bar','roll','signal_day','entry_day','entry_minute','exit_day','exit_minute','exit_bar','short_expiry','long_expiry','long_days','strike','atm','lot','base','status','reason','pnl_inr','unit_pnl','fills']
        for r in rows:con.execute(f'INSERT INTO trades({",".join(r)}) VALUES({",".join("?"*len(r))})',tuple(r.values()))
        con.commit();con.close();return p
    def trade(self,t,day,xbar,xday,unit,tp=None,status='closed',roll=0,chain=None):
        tid=f'bull|naked|0.0|{tp}|{t}|{roll}'
        return dict(id=tid,chain=chain or tid,side='bull',structure='naked',offset=0.,tp=tp,signal_bar=t,roll=roll,entry_day=day,exit_day=xday,exit_bar=xbar,status=status,unit_pnl=unit)
    def test_one_position_at_a_time_and_split(self):
        rows=[self.trade(0,'2022-01-03',5,'2022-01-10',10.),self.trade(3,'2022-01-06',8,'2022-01-13',-50.),self.trade(6,'2022-01-11',9,'2022-01-14',5.),
              self.trade(400,'2023-07-10',405,'2023-07-17',99.)]
        data=zr.load(self.db(rows,[('c','bull',0),('c','bull',3),('c','bull',6),('c','bull',400)]))
        tr,counts=zr.trades_for([0,3,6,400],'bull','naked',0.,None,data[2],data[3],data[0],'2022-01-01','2023-01-01')
        self.assertEqual([c['unit'] for c in tr],[10.,5.]);self.assertEqual(counts['skipped_busy'],1)
    def test_roll_chain_is_one_trade(self):
        a=self.trade(0,'2022-01-03',5,'2022-01-10',10.);b=self.trade(0,'2022-01-10',9,'2022-01-17',-4.,roll=1,chain=a['id'])
        data=zr.load(self.db([a,b],[('c','bull',0)]))
        tr,_=zr.trades_for([0],'bull','naked',0.,None,data[2],data[3],data[0],'2022-01-01','2023-01-01')
        self.assertEqual(len(tr),1);self.assertAlmostEqual(tr[0]['unit'],6.)
    def test_tp_rule(self):
        by={None:dict(total=100.,win=.5),.25:dict(total=80.,win=.8),.5:dict(total=70.,win=.9)}
        self.assertEqual(zr.choose_tp(by,.75),.25)
    def test_train_window_ignores_later_outcomes(self):
        base=[self.trade(0,'2022-01-03',5,'2022-01-10',10.)]
        later=self.trade(700,'2024-09-02',705,'2024-09-09',-1e9)
        d1=zr.load(self.db(base,[('c','bull',0)]));d2=zr.load(self.db(base+[later],[('c','bull',0),('c','bull',700)]))
        r1=zr.evaluate(d1,'2021-09-01','2024-01-01',.75,1,['naked'],[0.],[None]);r2=zr.evaluate(d2,'2021-09-01','2024-01-01',.75,1,['naked'],[0.],[None])
        self.assertEqual(r1,r2)

if __name__=='__main__':unittest.main()
