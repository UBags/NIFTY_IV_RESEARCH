#!/usr/bin/env python3
"""Green + red portfolio selection on rupee returns, yearly floors, combined drawdown and available funds (V4.9.2).

A portfolio is one green (bull) strategy and one red (bear) strategy, each at its own size of whole lots (0..the paths file's
--lots; 0 = that leg not traded), run on one account. Each strategy is a grid combination (structure, strike offset, signal
configuration, profit rule, stop rule). The account is judged as a whole:

  size              a leg of k lots trades min(k, lots the historical path matched) whole lots on each trade: the paths were
                    simulated at --lots, and a trade whose market matched only m lots there fills min(k, m) at k (per-unit P&L
                    from that path; exits of smaller orders are, if anything, cheaper). --sizing constant (default): a lot is
                    --ref-units / --lots units (65) in every year, so a point is worth the same whatever the exchange lot size
                    was (50 / 25 / 75 / 65); --sizing actual: the exchange lot of the day.
  margin            per open position and session: rate x |units| x index close (--margin, defaults futures 12%, naked short
                    12%, calendar 4% of notional; ASSUMED, not SPAN). Called assumed_margin everywhere.
  available funds   capital + the account's mark-to-market P&L at the previous session close. Margin must stay within
                    (1 - --margin-buffer) x available funds: a training gate for each combination, and an order-admission rule
                    in the walk-forward account (an order is cut to the lots that fit, or rejected; rejections are logged).
  return per year   that calendar year's rupee P&L (mark-to-market at the year's last close) / capital, annualised for a part
                    year of at least --min-year-days; shorter part years are neither annualised nor held to the floor. Simple.
  drawdown          daily_close_drawdown: largest fall of the combined equity at session closes from its running peak (stale
                    marks carried forward, share reported). Not an intraday guarantee.
  gates             overall >= --target, every judged year >= --floor (no judged year: fails), drawdown <= --max-dd, assumed
                    margin within available funds at every session. Ranking among passing (pair, sizes): --rank dd (default),
                    worst_year or calmar; ties by higher overall return. Every survivor of the target and floor screens is
                    evaluated exactly (no truncation).

Walk-forward is a single chronological EXECUTABLE account. For test year Y the pair and sizes are chosen on [--start, Y) only.
The choice is adopted flat on 1 January (signals before then ignored), takes entries during Y only, and positions still open
at the year end run to their own exits (overlapping the next year's choice). Every entry, of every year's legs, goes through the
order-admission rule against the account's own funds and margin at that session. Every planned test year is reported: a year
with no passing pair (or no candidates) takes no new entries (--if-none cash; 'closest' trades the nearest failing pair,
research only, never deployable) while positions carried from the year before continue; a year counts as flat cash only if
the account held nothing in it. A year is deployable only if its choice passed every training gate and its funds were never
short. Training curves follow the grid's convention (one continuous strategy from --start), so pools agree with the grid.

Candidates: for each side and training window the union of the top --pool combinations by training total, worst training year
and the grid's stability score, each with >= --min-trades trades (walk-forward windows: --wf-min-trades, default
max(10, min-trades // 2), as the grid). Rule labels with identical trades are one candidate. Data gaps follow the grid's
--gap-policy (read from the grid index).

Robustness and uncertainty: share of one-step neighbour swaps that still pass (identical neighbours reported separately); the
test-year results of the top --wf-top distinct passing pairs per year; the account at several futures carry rates.

Futures are spot-proxy: an assumed carry (--carry, 5.5%/yr) is charged pro rata on futures legs (long pays, short receives).

Outputs (in --out): portfolio_walk_forward.csv, portfolio_account_daily.csv, portfolio_orders.csv, portfolio_pairs_in_sample.csv,
portfolio_gate_counts.csv, portfolio_report.json."""
import argparse,collections,csv,datetime as dt,json,math,sys,time
from pathlib import Path
import numpy as np
import zone_grid as zg
import zone_rules as zr

CAPITAL=2_500_000.
MARGIN={'futures_zone':.12,'futures_expiry':.12,'naked':.12,'calendar':.04}

# ---------------- candidate pools from the grid files ----------------
_P={}
def _year_factor(start,split):
    """Calendar years covered inside [start, split) and the annualisation factor of each (365 / days covered)."""
    a=dt.date.fromisoformat(start);b=dt.date.fromisoformat(split);out={}
    for y in range(a.year,b.year+1):
        lo=max(a,dt.date(y,1,1));hi=min(b,dt.date(y+1,1,1));d=(hi-lo).days
        if d>0:out[y]=365./d
    return out

def _pool_file(e):
    """Top candidates of one grid file for every (training window, criterion)."""
    c=_P;K=c['pool'];out=[]
    with np.load(c['grid']/e['file']) as z:Z={k:z[k] for k in ('n','total','configs','profits','stops','windows')}
    configs=list(Z['configs']);P=list(Z['profits']);S=list(Z['stops']);wn=list(Z['windows'])
    CN=zr.config_neighbours(configs);PN=zr.neighbours(P);SN=zr.compound_neighbours(S) if e['kind'].startswith('compound') else zr.neighbours(S)
    for fold,(wname,years,mt) in c['folds'].items():
        if wname not in wn:continue
        wi=wn.index(wname);N=Z['n'][:,wi].astype(np.int64);T=Z['total'][:,wi]
        ok=N>=mt
        if not ok.any():continue
        yw=lambda y:f'test_{y}' if f'test_{y}' in wn else f'train_{y+1}'          # the first (part) year has no test window: train_<next year> is that year alone
        yr=[Z['total'][:,wn.index(yw(y))]*c['factor'][y] for y in years if yw(y) in wn]
        worst=np.min(np.stack(yr),0) if yr else T
        stab,_=zg.stability(N,T,mt,CN,PN,SN)
        for crit,score in (('total',T),('worst_year',worst),('stable',stab)):
            sc=np.where(ok&np.isfinite(score),score,-np.inf).ravel();k=min(K,int(np.isfinite(sc).sum()))
            if not k:continue
            for f in np.argpartition(-sc,k-1)[:k]:
                ci,pi,si=np.unravel_index(int(f),N.shape)
                out.append((fold,crit,float(sc[f]),(e['side'],e['structure'],float(e['offset']),str(configs[ci]),str(P[pi]),str(S[si])),e['file']))
    return out

def pools(grid,folds,factor,pool,workers=1):
    """{(fold, side): {candidate key: file}} with the top `pool` per criterion across all files. folds: {fold: (window, years, min trades)}."""
    idx=zg.read_json(grid/'grid_index.json');_P.clear();_P.update(grid=grid,folds=folds,factor=factor,pool=pool)
    best=collections.defaultdict(list)
    for part in zg.pool_map(_pool_file,idx['groups'],workers):
        for fold,crit,score,key,f in part:best[fold,key[0],crit].append((score,key,f))
    out=collections.defaultdict(dict)
    for (fold,side,crit),lst in best.items():
        lst.sort(key=lambda x:(-x[0],x[1]))
        for _,key,f in lst[:pool]:out[fold,side][key]=f
    return out,idx

# ---------------- trades -> per-lot pieces -> daily equity and margin at k lots ----------------
class Sizing:
    """Units per lot and the lots a trade can hold at a leg size of k lots."""
    def __init__(self,sizing='constant',ref_units=650.,target_lots=10):
        self.sizing=sizing;self.ref=float(ref_units);self.L=int(target_lots or 10);self.stats=collections.Counter()
    def per_lot(self,x):
        if self.sizing=='constant':return self.ref/self.L
        if x.get('lot'):return float(x['lot'])
        self.stats['lot_unknown']+=1;return self.ref/self.L
    def matched(self,x):
        """Whole lots the historical path matched (its units / its lot), at most the simulated --lots."""
        if x.get('lot'):return max(0,min(self.L,int(round(float(x['units'])/x['lot']))))
        self.stats['lot_unknown']+=1;return self.L
    def units(self,x,k):return self.per_lot(x)*min(int(k),self.matched(x))

def prepare(trades,sess_ord,structure='naked',carry=0.,sess_close=None,margin_rate=0.):
    """Each valued trade as per-unit pieces on the session axis: (i0, hi, mark segment per unit, realised session or None,
    final per unit, margin per unit per session, trade). One position at a time; trades without a value are counted, not used."""
    T=len(sess_ord);out=[];bad=0;stale=0;nm=0;fut=structure.startswith('futures');busy_to=-1
    for x in trades:
        if not math.isfinite(x['unit']):bad+=1;continue
        e0=dt.date.fromisoformat(x['entry_day']).toordinal();e1=dt.date.fromisoformat(x['exit_day']).toordinal()
        c=x.get('sign',1.)*x.get('index',0.)*carry/365. if fut and carry else 0.     # assumed carry, points per unit per day
        i0=int(np.searchsorted(sess_ord,e0));i1=int(np.searchsorted(sess_ord,e1));hi=min(i1,T)
        mo=np.asarray(x['mark_ord'],np.int64);mv=np.asarray(x['marks'],float);fin=np.isfinite(mv)
        si=np.searchsorted(sess_ord,mo[fin]);mv=mv[fin]-c*(mo[fin]-e0)
        stale+=int(x.get('stale',0));nm+=int(x.get('marks_n',len(mo)))
        n=max(hi-i0,0);seg=np.zeros(0)
        if n:
            seg=np.full(n,np.nan);last=np.r_[si[1:]!=si[:-1],True] if len(si) else np.zeros(0,bool)   # marks in time order: the session's last close
            k=si[last];v=mv[last];inb=(k>=i0)&(k<hi);seg[k[inb]-i0]=v[inb]
            ok=np.isfinite(seg);fill=np.where(ok,np.arange(n),-1);np.maximum.accumulate(fill,out=fill)
            seg=np.where(fill>=0,seg[np.maximum(fill,0)],0.)
        if i0<busy_to and n:raise ValueError('overlapping trades inside one strategy')
        busy_to=max(busy_to,hi)
        final=x['unit']-c*(e1-e0)
        mrg=margin_rate*sess_close[i0:hi] if margin_rate and sess_close is not None else None
        out.append((i0,hi,seg,i1 if i1<T else None,final,mrg,x))
    return dict(pieces=out,bad=bad,stale=stale,marks=nm,n=len(trades),T=T)

def combine(prep,k,sz,pieces=None):
    """Daily rupee equity, open mask and assumed margin of the prepared trades at a leg size of k lots."""
    T=prep['T'];O=np.zeros(T);open_=np.zeros(T,bool);realised=np.zeros(T);M=np.zeros(T)
    for i0,hi,seg,ir,final,mrg,x in (prep['pieces'] if pieces is None else pieces):
        u=sz.units(x,k)
        if not u:continue
        if len(seg):O[i0:hi]=seg*u;open_[i0:hi]=True
        if mrg is not None:M[i0:i0+len(mrg)]=mrg*u
        if ir is not None:realised[ir]+=final*u
        elif T:O[T-1]=final*u;open_[T-1]=True                                   # open at the window end: its window-end value
    return np.cumsum(realised)+O,open_,M

def replay(trades,sess_ord,structure='naked',carry=0.,size=None,sess_close=None,margin_rate=0.):
    """V4.9.1 interface (one size function for all trades): dict(E, open, M, bad, stale, marks, n)."""
    p=prepare(trades,sess_ord,structure,carry,sess_close,margin_rate)
    class _S:
        def units(s,x,k):return size(x) if size else x['units']
    E,op,M=combine(p,1,_S());return dict(E=E,open=op,M=M,bad=p['bad'],stale=p['stale'],marks=p['marks'],n=p['n'])

def equity(trades,sess_ord,structure='naked',carry=0.):
    """V4.9.0 interface: (equity, open mask, trades without a value) at the units each trade held."""
    r=replay(trades,sess_ord,structure,carry);return r['E'],r['open'],r['bad']

def year_slices(sess_days,lo,hi,factor=None):
    """[(year, i_start, i_end, annualisation, calendar days covered)]: sessions of each calendar year inside [lo, hi). A part
    year (the window starts or ends inside it, or the data does) is annualised over the calendar days it covers: 365 / days."""
    out=[];inside=[i for i,d in enumerate(sess_days) if lo<=d<hi]
    if not inside:return out
    end=min(dt.date.fromisoformat(hi),dt.date.fromisoformat(sess_days[-1])+dt.timedelta(1));lo_d=dt.date.fromisoformat(lo)
    for y in sorted({sess_days[i][:4] for i in inside}):
        idx=[i for i in inside if sess_days[i][:4]==y];y=int(y)
        days=(min(end,dt.date(y+1,1,1))-max(lo_d,dt.date(y,1,1))).days
        out.append((y,idx[0],idx[-1],365./max(days,1),days))
    return out

def pair_metrics(G,R,i0,i1,ys,capital,span_years,chunk=64,min_days=90):
    """All green x red pairs at full size over sessions [i0, i1]: yearly returns (nG, nR, Y), overall return, worst judged
    year (NaN when no year covers min_days: not judged, V4.9.1), max drawdown."""
    base=lambda A,i:A[:,i-1] if i>i0 else np.zeros(len(A))
    fy=[f if d>=min_days else 1. for *_,f,d in ys];yG=np.stack([(G[:,b]-base(G,a))*f for (_,a,b,*_),f in zip(ys,fy)],1);yR=np.stack([(R[:,b]-base(R,a))*f for (_,a,b,*_),f in zip(ys,fy)],1)
    Y=(yG[:,None,:]+yR[None,:,:])/capital
    tot=((G[:,i1]-base(G,i0))[:,None]+(R[:,i1]-base(R,i0))[None,:])/capital/span_years
    dd=np.empty((len(G),len(R)))
    g0=base(G,i0);r0=base(R,i0)
    for a in range(0,len(G),chunk):
        S=(G[a:a+chunk,None,i0:i1+1]-g0[a:a+chunk,None,None])+(R[None,:,i0:i1+1]-r0[None,:,None])
        S=np.concatenate([np.zeros(S.shape[:2]+(1,)),S],2)
        dd[a:a+chunk]=(np.maximum.accumulate(S,2)-S).max(2)
    judged=[j for j,y in enumerate(ys) if y[4]>=min_days]
    worst=Y[:,:,judged].min(2) if judged else np.full(tot.shape,np.nan)
    return Y,tot,worst,dd

def _dd_rows(S):
    """Max drawdown of each row of S (rows x sessions), equity starting at 0 before the first session."""
    S=np.concatenate([np.zeros((len(S),1),S.dtype),S],1);return (np.maximum.accumulate(S,1)-S).max(1)

class Fold:
    """Training-window arrays of a side's candidate curves at one leg size; row n (the last) is the empty leg (zeros)."""
    def __init__(self,curves,i0,i1,ys,min_days,T):
        E=np.vstack([c[0] for c in curves]+[np.zeros(T)]);M=np.vstack([c[2] for c in curves]+[np.zeros(T)])
        b=E[:,i0-1] if i0>0 else np.zeros(len(E));self.n=len(curves)
        self.judged=[j for j,y in enumerate(ys) if y[4]>=min_days];fy=[y[3] if y[4]>=min_days else 1. for y in ys]
        self.y=np.stack([(E[:,bb]-(E[:,aa-1] if aa>i0 else b))*f for (_,aa,bb,*_),f in zip(ys,fy)],1)
        self.t=E[:,i1]-b;self.D=(E[:,i0:i1+1]-b[:,None]);self.M=M[:,i0:i1+1]
        self.open=np.vstack([c[1] for c in curves]+[np.zeros(T,bool)])[:,i0:i1+1]

def combo_eval(FG,FR,g,r,capital,span,buffer=0.):
    """Exact metrics of combinations (rows g of FG, r of FR, each already at its size): overall return, yearly returns, worst
    judged year (NaN if none), daily-close drawdown, peak assumed margin, and the largest margin excess over
    (1 - buffer) x available funds (capital + P&L at the previous close; <= 0 means the funds always sufficed)."""
    g=np.asarray(g,np.int64);r=np.asarray(r,np.int64);tot=(FG.t[g]+FR.t[r])/capital/span
    Y=(FG.y[g]+FR.y[r])/capital;worst=Y[:,FG.judged].min(1) if FG.judged else np.full(len(g),np.nan)
    dd=np.empty(len(g));mg=np.empty(len(g));ex=np.empty(len(g))
    for s in range(0,len(g),10000):
        sl=slice(s,s+10000);E=FG.D[g[sl]]+FR.D[r[sl]];M=FG.M[g[sl]]+FR.M[r[sl]]
        dd[sl]=_dd_rows(E);mg[sl]=M.max(1)
        prev=np.concatenate([np.zeros((len(E),1)),E[:,:-1]],1);ex[sl]=(M-(1-buffer)*(capital+prev)).max(1)
    return tot,Y,worst,dd,mg,ex

def search(FG,FR,leg_lots,capital,span,target,floor,max_dd,rank,top,buffer=0.,closest_keep=2000):
    """Every (green, red, green lots, red lots); FG / FR: {lots: Fold}. Target and floor screened for all combinations, then every
    survivor evaluated exactly (drawdown, funds) in chunks; nothing is truncated. Returns (rows best first, passed, counts)."""
    cnt=collections.Counter();keep=collections.defaultdict(list);close=[]
    for la in leg_lots:
        for lb in leg_lots:
            if not la and not lb:continue
            A=FG[la] if la else FG[0];B=FR[lb] if lb else FR[0]
            gi=np.arange(A.n) if la else np.array([A.n]);ri=np.arange(B.n) if lb else np.array([B.n])
            if not len(gi) or not len(ri):continue
            tot=(A.t[gi][:,None]+B.t[ri][None,:])/capital/span
            if A.judged:worst=((A.y[gi][:,None,:]+B.y[ri][None,:,:])[:,:,A.judged]/capital).min(2)
            else:worst=np.full(tot.shape,np.nan);cnt['no_judged_year']+=tot.size
            p1=tot>=target;p2=worst>=floor;ok=p1&p2
            cnt['combinations']+=tot.size;cnt['pass_target']+=int(p1.sum());cnt['pass_floor']+=int(p2.sum());cnt['pass_target_and_floor']+=int(ok.sum())
            ga,rb=np.nonzero(ok)
            for s in range(0,len(ga),200000):                                     # exact evaluation of every survivor
                g=gi[ga[s:s+200000]];r=ri[rb[s:s+200000]];t,Y,w,dd,mg,ex=combo_eval(A,B,g,r,capital,span,buffer)
                p3=dd<=max_dd;p4=ex<=0;cnt['evaluated_exactly']+=len(g);cnt['pass_drawdown_of_target_and_floor']+=int(p3.sum());cnt['pass_funds_of_target_and_floor']+=int(p4.sum())
                q=p3&p4;cnt['pass_all']+=int(q.sum())
                if q.any():
                    for k_,v in (('g',g[q]),('r',r[q]),('la',np.full(q.sum(),la)),('lb',np.full(q.sum(),lb)),('tot',t[q]),('Y',Y[q]),('worst',w[q]),('dd',dd[q]),('mg',mg[q]),('ex',ex[q])):keep[k_].append(v)
            sf=np.maximum(target-tot,0)/target+np.where(np.isfinite(worst),np.maximum(floor-worst,0)/max(floor,1e-9),10.)
            k=min(closest_keep,sf.size);f=np.argpartition(sf.ravel(),k-1)[:k];x,y=np.unravel_index(f,sf.shape)
            close.append((sf.ravel()[f],gi[x],ri[y],np.full(k,la),np.full(k,lb)))
    cnt.setdefault('pass_all',0);cnt.setdefault('evaluated_exactly',0)
    if keep:
        sel={k_:np.concatenate(v) for k_,v in keep.items()};k1,k2=rank_key(rank,sel['tot'],sel['worst'],sel['dd'])
        order=np.lexsort((sel['lb'],sel['la'],sel['r'],sel['g'],k2,k1))
        n_r=max(B.n for B in FR.values())+1;pair=sel['g'].astype(np.int64)*n_r+sel['r'];_,first=np.unique(pair[order],return_index=True)   # each pair once, at its best sizes
        order=order[np.sort(first)][:top];cnt['distinct_pairs_passing']=len(first)
        return [_row(sel,i,True) for i in order],True,cnt
    if not close:return [],False,cnt
    sf,g,r,la,lb=(np.concatenate(x) for x in zip(*close));k=np.argsort(sf,kind='stable')[:closest_keep];g,r,la,lb=g[k],r[k],la[k],lb[k]
    m=collections.defaultdict(list)
    for a_ in np.unique(la):
        for b_ in np.unique(lb[la==a_]):
            s=(la==a_)&(lb==b_);A=FG[a_] if a_ else FG[0];B=FR[b_] if b_ else FR[0];t,Y,w,dd,mg,ex=combo_eval(A,B,g[s],r[s],capital,span,buffer)
            for k_,v in (('g',g[s]),('r',r[s]),('la',la[s]),('lb',lb[s]),('tot',t),('Y',Y),('worst',w),('dd',dd),('mg',mg),('ex',ex)):m[k_].append(v)
    m={k_:np.concatenate(v) for k_,v in m.items()};w=np.where(np.isfinite(m['worst']),np.maximum(floor-m['worst'],0)/max(floor,1e-9),10.)
    short=np.maximum(target-m['tot'],0)/target+w+np.maximum(m['dd']-max_dd,0)/max_dd+np.maximum(m['ex'],0)/capital
    order=np.lexsort((m['lb'],m['la'],m['r'],m['g'],short))[:top]
    return [_row(m,i,False) for i in order],False,cnt

def _row(m,i,passed):return dict(g=int(m['g'][i]),r=int(m['r'][i]),la=int(m['la'][i]),lb=int(m['lb'][i]),tot=float(m['tot'][i]),Y=m['Y'][i],worst=float(m['worst'][i]),dd=float(m['dd'][i]),
                                 mg=float(m['mg'][i]),ex=float(m['ex'][i]),passed=passed)

def rank_key(rank,tot,worst,dd):
    if rank=='worst_year':return -worst,-tot
    if rank=='calmar':return -(tot/np.maximum(dd,1.)),-tot
    return dd,-tot

# ---------------- main flow ----------------
def run(grid,paths_db,out,capital=CAPITAL,target=.22,floor=.17,max_dd=250_000.,rank='dd',pool=150,min_trades=15,carry=.055,top=50,
        holidays=(),workers=1,progress=True,min_days=90,sizing='constant',ref_units=650.,margin=None,leg_lots=None,if_none='cash',wf_top=10,
        wf_min_trades=None,carry_scenarios=(0.,.03,.055,.08),buffer=.10):
    grid=Path(grid);out=Path(out);out.mkdir(parents=True,exist_ok=True);t0=time.time();margin=dict(MARGIN,**(margin or {}))
    gi=zg.read_json(grid/'grid_index.json');start,split=gi['start'],gi['split'];factor=_year_factor(start,split);gap_policy=gi.get('gap_policy','free')
    wins=[w[0] for w in gi['windows']];test_years=sorted(int(w[5:]) for w in wins if w.startswith('test_'))
    wmt=wf_min_trades if wf_min_trades is not None else max(10,min_trades//2)
    folds={f'test_{y}':(f'train_{y}',sorted({t for t in test_years+[int(start[:4])] if t<y}),wmt) for y in test_years}
    folds['in_sample']=('train_full',sorted(set(test_years+[int(start[:4])])),min_trades)
    P,_=pools(grid,{k:v for k,v in folds.items() if v[0] in wins},factor,pool,workers)
    if progress:print('pools: '+', '.join(f'{f} {s} {len(v)}' for (f,s),v in sorted(P.items()))+f' ({time.time()-t0:.0f}s)',flush=True)
    D=zg.Detail(paths_db,holidays,gap_policy);L=D.target_lots or 10
    leg_lots=sorted(set(leg_lots if leg_lots is not None else range(L+1)))
    sess_days=sorted({d for d in D.bars.day if start<=d<split});sess_ord=np.array([dt.date.fromisoformat(d).toordinal() for d in sess_days]);T=len(sess_days)
    last_close={};[last_close.__setitem__(d,c) for d,c in zip(D.bars.day,D.bars.close)];sess_close=np.array([last_close[d] for d in sess_days])
    sz=Sizing(sizing,ref_units,L)
    def sel_of(key):side,st,off,cfg,prof,stop=key;return dict(side=side,structure=st,offset=off,config=cfg,profit=prof,stop=stop)
    curves={};files={}
    def curve(key):
        """Training curve of a candidate: prepared trades plus its daily equity / open / margin at every searched size."""
        if key not in curves:
            p=prepare(D.trades(sel_of(key),start,split),sess_ord,key[1],carry,sess_close,margin.get(key[1],0.))
            curves[key]=dict(prep=p,at={k:combine(p,k,sz) for k in leg_lots if k},bad=p['bad'],n=p['n'],stale=p['stale'],marks=p['marks'],
                             reduced=sum(1 for *_,x in p['pieces'] if sz.matched(x)<L))
        return curves[key]
    allkeys=sorted({k for v in P.values() for k in v},key=lambda k:(k[1],k[2],k[0],k[3:]))
    for (f,s),v in P.items():files.update(v)
    for i,k in enumerate(allkeys):
        curve(k)
        if progress and (i+1)%500==0:print(f'  replayed {i+1}/{len(allkeys)} ({time.time()-t0:.0f}s)',flush=True)
    if progress:print(f'replayed {len(allkeys)} strategies ({time.time()-t0:.0f}s)',flush=True)
    dropped={s:sum(1 for k in allkeys if k[0]==s and curves[k]['bad']) for s in ('bull','bear')}
    zero=(np.zeros(T),np.zeros(T,bool),np.zeros(T))
    gates=[];picks={};ins=[];report=dict(start=start,split=split,planned_test_years=test_years,min_year_days=min_days,capital=capital,target=target,floor=floor,max_drawdown=max_dd,rank=rank,pool=pool,
        min_trades=min_trades,wf_min_trades=wmt,carry=carry,sizing=sizing,units_per_lot=ref_units/L if sizing=='constant' else 'exchange lot',simulated_lots=L,leg_lots=leg_lots,
        assumed_margin_rates=margin,margin_buffer=buffer,if_none=if_none,gap_policy=gap_policy,candidates_dropped_for_unvalued_trades=dropped,folds={},
        conventions=dict(returns='simple rupee P&L / capital per calendar year, part years >= min_year_days annualised, not compounded',
            size='a leg of k lots holds min(k, lots matched on the simulated path) whole lots per trade; per-unit P&L from the simulated path',
            training_curves='one continuous strategy from start (the grid convention)',
            account='executable: flat adoption on 1 January, entries that year only, open positions run to their own exits; every order admitted against (1 - buffer) x (capital + P&L) minus margin in use, cut to whole lots or rejected',
            margin='rate x |units| x index close per open position and session: an assumption, not SPAN',drawdown='daily close mark-to-market; not intraday',
            stale_marks='last known leg close carried forward; share of bar closes without a fresh print reported'))
    for fold,(wname,years,mt) in folds.items():
        y=int(fold[5:]) if fold.startswith('test_') else None
        g,dg=_distinct([k for k in P.get((fold,'bull'),{}) if not curves[k]['bad']],curves);r,dr=_distinct([k for k in P.get((fold,'bear'),{}) if not curves[k]['bad']],curves)
        lo=start;hi=f'{y}-01-01' if y else split
        ys=year_slices(sess_days,lo,hi)
        if (not g and not r) or not ys or wname not in wins:
            why='no_training_sessions' if not ys or wname not in wins else 'no_candidates'
            report['folds'][fold]=dict(note=why);gates.append(dict(fold=fold,note=why,green_candidates=len(g),red_candidates=len(r)))
            if y:picks[y]=([],False,why)
            continue
        i0=ys[0][1];i1=ys[-1][2];span=sum(d for *_,d in ys)/365.
        FG={k:Fold([curves[c]['at'][k] if k else zero for c in g],i0,i1,ys,min_days,T) for k in set(leg_lots)|{0}}
        FR={k:Fold([curves[c]['at'][k] if k else zero for c in r],i0,i1,ys,min_days,T) for k in set(leg_lots)|{0}}
        res,passed,cnt=search(FG,FR,leg_lots,capital,span,target,floor,max_dd,rank,max(top,wf_top),buffer)
        gates.append(dict(fold=fold,green_candidates=len(g),red_candidates=len(r),green_identical_dropped=dg,red_identical_dropped=dr,**cnt))
        rows=[_out(fold,x,g,r,curves,ys,min_days,FG,FR) for x in res]
        if rows:rows[0].update(_robust(rows[0],res[0],FG,FR,curves,curve,files,ys,i0,i1,capital,span,target,floor,max_dd,grid,min_days,T,buffer))
        if y:picks[y]=(rows,passed,'pass' if passed else 'no_pair_passed')
        else:ins=rows[:top]
        report['folds'][fold]=dict(green_candidates=len(g),red_candidates=len(r),**cnt,best={k:v for k,v in rows[0].items() if not k.startswith('_')} if rows else None)
        if progress:print(f'{fold}: {cnt["combinations"]:,} combinations, {cnt["evaluated_exactly"]:,} evaluated exactly, {cnt["pass_all"]:,} pass every gate ({time.time()-t0:.0f}s)',flush=True)
    for y in test_years:picks.setdefault(y,([],False,'no_training_sessions'))
    acc=Account(D,sess_days,sess_ord,sess_close,split,capital,buffer,min_days,margin,sz,sel_of)
    wf,daily,orders,summary=walk_forward(acc,picks,if_none,wf_top,floor,carry,carry_scenarios)
    D.close();report['walk_forward']=summary;report['sizing_lot_unknown']=sz.stats.get('lot_unknown',0)
    _csv(out/'portfolio_walk_forward.csv',wf);_csv(out/'portfolio_pairs_in_sample.csv',ins);_csv(out/'portfolio_gate_counts.csv',gates);_csv(out/'portfolio_account_daily.csv',daily);_csv(out/'portfolio_orders.csv',orders)
    report['gate_counts']=gates;zg.write_json(report,out/'portfolio_report.json',indent=1,default=str)
    return report,wf,ins,gates

def _distinct(keys,curves):
    """One candidate per distinct trading history (different rule labels with identical trades, e.g. a wide stop that never
    fires, or a layered policy whose only active part is its mandatory exit). Returns (kept keys, dropped count)."""
    seen={};out=[]
    for k in sorted(keys,key=lambda k:(k[1],k[2],k[3:])):
        c=curves[k];h=hash(b''.join(a[0].tobytes()+a[2].tobytes() for _,a in sorted(c['at'].items())))
        if h in seen:curves[seen[h]]['aliases']=curves[seen[h]].get('aliases',1)+1;continue
        seen[h]=k;out.append(k);c.setdefault('aliases',1)
    return out,len(keys)-len(out)

def _leg(name,key,lots,curves):
    if key is None or not lots:return {f'{name}_lots':0,f'{name}_structure':'none'}
    side,st,off,cfg,prof,stop=key;c=curves[key]
    return {f'{name}_lots':lots,f'{name}_structure':st,f'{name}_offset':off,f'{name}_config':cfg,f'{name}_profit':prof,f'{name}_stop':stop,f'{name}_trades':c['n'],
            f'{name}_trades_matched_below_simulated_lots':c['reduced'],f'{name}_stale_share':round(c['stale']/c['marks'],3) if c['marks'] else None,f'{name}_identical_rules':c.get('aliases',1)}

def _out(fold,x,g,r,curves,ys,min_days,FG,FR):
    gk=g[x['g']] if x['g']<len(g) else None;rk=r[x['r']] if x['r']<len(r) else None
    ov=int((FG[x['la']].open[x['g']]&FR[x['lb']].open[x['r']]).sum()) if x['la'] and x['lb'] else 0
    return dict(fold=fold,passed=x['passed'],overall=round(x['tot'],6),worst_year=None if math.isnan(x['worst']) else round(x['worst'],6),daily_close_drawdown=round(x['dd']),
                assumed_margin_peak=round(x['mg']),margin_excess_over_available=round(x['ex']),
                **{f'year_{y}'+('' if ys[j][4]>=min_days else f'_part_{ys[j][4]}d_not_annualised'):round(float(x['Y'][j]),6) for j,(y,*_) in enumerate(ys)},
                overlap_sessions=ov,**_leg('green',gk,x['la'],curves),**_leg('red',rk,x['lb'],curves),_g=gk,_r=rk)

# ---------------- executable walk-forward account ----------------
class Account:
    """One chronological account. legs: [(year, side name, key, lots)]. Every signal of every leg, in time order: a leg takes it
    if the leg is free (one position per leg; a data gap holds the leg as the grid does), then the order is admitted against
    the account: lots = min(leg lots, lots matched on the path, lots whose assumed margin fits into (1 - buffer) x (capital +
    P&L at the previous close) minus the margin already in use). Fewer than one lot: rejected (logged), the leg stays free."""
    def __init__(self,D,sess_days,sess_ord,sess_close,split,capital,buffer,min_days,margin,sz,sel_of):
        self.D=D;self.days=sess_days;self.ord=sess_ord;self.close=sess_close;self.split=split;self.capital=capital;self.buffer=buffer;self.min_days=min_days
        self.margin=margin;self.sz=sz;self.sel_of=sel_of;self._ev={}
    def events(self,key,y):
        """Signals of one leg adopted flat on 1 January of y with entries during y (cached per key and year)."""
        if (key,y) not in self._ev:
            lo=f'{y}-01-01';hi=min(f'{y+1}-01-01',self.split);ev=[]
            for kind,t,until,x in self.D.signal_outcomes(self.sel_of(key),self.split):
                day=x if kind=='gap' else x['entry_day']
                if lo<=day<hi:ev.append((kind,t,until,x))
            self._ev[key,y]=ev
        return self._ev[key,y]
    def run(self,legs,carry):
        T=len(self.days);A=np.zeros(T);M=np.zeros(T);opn={};orders=[];busy={}
        evs=sorted(((t,li,kind,until,x) for li,(y,name,key,k) in enumerate(legs) for kind,t,until,x in self.events(key,y)),key=lambda e:(e[0],e[1]))
        preps={}
        for t,li,kind,until,x in evs:
            y,name,key,k=legs[li]
            if t<=busy.get(li,-1):continue
            if kind=='gap':busy[li]=until;orders.append(dict(year=y,leg=name,signal_bar=t,day=x,decision='data gap: leg held, outcome unknown'));continue
            p=prepare([x],self.ord,key[1],carry,self.close,self.margin.get(key[1],0.))
            if not p['pieces']:busy[li]=until;orders.append(dict(year=y,leg=name,signal_bar=t,day=x['entry_day'],decision='trade without a value: leg held, not counted'));continue
            i0=p['pieces'][0][0];want=min(k,self.sz.matched(x))
            if i0>=T:continue
            avail=(1-self.buffer)*(self.capital+(A[i0-1] if i0>0 else 0.))-M[i0]
            per_lot=self.margin.get(key[1],0.)*self.sz.per_lot(x)*self.close[i0]
            fit=want if per_lot<=0 else int(max(0.,math.floor(avail/per_lot+1e-9)))
            lots=min(want,fit)
            rec=dict(year=y,leg=name,signal_bar=t,day=x['entry_day'],lots_wanted=k,lots_matched_on_path=self.sz.matched(x),lots_taken=lots,funds_available_for_margin=round(avail),margin_per_lot=round(per_lot))
            if lots<1:rec['decision']='rejected: assumed margin does not fit available funds';orders.append(rec);continue
            rec['decision']='taken' if lots==want else 'cut to fit available funds';orders.append(rec)
            E,op,Mi=combine(p,lots,self.sz);A+=E;M+=Mi;opn.setdefault((y,name),np.zeros(T,int))[:]+=op;busy[li]=until
        return A,M,opn,orders
    def year(self,A,y):
        ys=year_slices(self.days,f'{y}-01-01',min(f'{y+1}-01-01',self.split))
        if not ys:return None,None,None
        _,a,b,f,days=ys[0];e0=A[a-1] if a>0 else 0.;return (A[b]-e0)/self.capital*(f if days>=self.min_days else 1.),days,(a,b)

def walk_forward(acc,picks,if_none,wf_top,floor,carry,carry_scenarios):
    years=sorted(picks);legs=[];wf=[]
    for y in years:
        rows,passed,why=picks[y];row=rows[0] if rows else None;trade=row is not None and (passed or if_none=='closest')
        rec=dict(test_year=y,training_result=why,passed_in_training=bool(passed),traded=trade,
                 decision='new entries: pair passed every training gate' if passed else ('new entries: closest failing pair (research only)' if trade else
                          ('no new entries: no pair passed in training' if why=='no_pair_passed' else f'no new entries: {why}')))
        if trade:
            for name,key,l in (('green',row['_g'],row['green_lots']),('red',row['_r'],row['red_lots'])):
                if l and key is not None:legs.append((y,name,key,l))
            rec.update({k:v for k,v in row.items() if not k.startswith('_') and k!='fold'})
        wf.append(rec)
    A,M,opn,orders=acc.run(legs,carry);T=len(acc.days)
    for rec in wf:                                                                # the other top passing choices, alone, in their test year
        rows,passed,_=picks[rec['test_year']]
        if passed and len(rows)>1:
            alt=[]
            for x in rows[:wf_top]:
                l=[(rec['test_year'],n,kk,ll) for n,kk,ll in (('green',x['_g'],x['green_lots']),('red',x['_r'],x['red_lots'])) if ll and kk is not None]
                alt.append(acc.year(acc.run(l,carry)[0],rec['test_year'])[0])
            alt=[v for v in alt if v is not None]
            if alt:rec.update(top_k=len(alt),top_k_median_return=round(float(np.median(alt)),6),top_k_worst_return=round(float(min(alt)),6),top_k_share_meeting_floor=round(float(np.mean([v>=floor for v in alt])),3))
    if not years:return wf,[],orders,{}
    first=year_slices(acc.days,f'{years[0]}-01-01',acc.split)
    if not first:
        for rec in wf:rec.update(account_return=None,result='unavailable: no sessions')
        return wf,[],orders,{}
    i0=first[0][1];base=A[i0-1] if i0>0 else 0.;S=np.r_[0.,A[i0:]-base];run_dd=np.maximum.accumulate(S)-S
    G=sum((v for (y,n),v in opn.items() if n=='green'),np.zeros(T,int));R=sum((v for (y,n),v in opn.items() if n=='red'),np.zeros(T,int))
    short=M>(acc.capital+A)                                                      # assumed margin above capital + P&L at that close: a margin call
    for rec in wf:
        r_,days,ab=acc.year(A,rec['test_year'])
        if r_ is None:rec.update(account_return=None,result='unavailable: no sessions');continue
        a,b=ab;e0=A[a-1] if a>0 else 0.;s=np.r_[0.,A[a:b+1]-e0];n=[o for o in orders if o['year']==rec['test_year']]
        held=bool((M[a:b+1]>0).any() or (G[a:b+1]>0).any() or (R[a:b+1]>0).any())
        rec.update(account_return=round(float(r_),6),test_days=days,test_annualised=bool(days>=acc.min_days),account_daily_close_drawdown_in_year=round(float((np.maximum.accumulate(s)-s).max())),
                   assumed_margin_peak_in_year=round(float(M[a:b+1].max())),funds_short_sessions=int(short[a:b+1].sum()),orders_taken=sum(o['decision'] in ('taken','cut to fit available funds') for o in n),
                   orders_cut=sum(o['decision']=='cut to fit available funds' for o in n),orders_rejected=sum(o['decision'].startswith('rejected') for o in n),
                   flat_cash_year=not held,deployable=bool(rec['passed_in_training'] and not short[a:b+1].any()))
    full=[w for w in wf if w.get('account_return') is not None and w.get('test_annualised')];rets=[w['account_return'] for w in full]
    cs={}
    for cr in carry_scenarios:
        Ac=acc.run(legs,cr)[0];cs[str(cr)]={str(w['test_year']):round(float(acc.year(Ac,w['test_year'])[0]),6) for w in full}
    summary=dict(planned_years=years,reported_years=[w['test_year'] for w in wf],years=[w['test_year'] for w in full],returns=[float(v) for v in rets],
                 mean=round(float(np.mean(rets)),6) if rets else None,worst=round(float(min(rets)),6) if rets else None,
                 daily_close_drawdown_continuous=round(float(run_dd.max())),largest_in_year_drawdown=max([w.get('account_daily_close_drawdown_in_year',0) for w in wf],default=0),
                 assumed_margin_peak=round(float(M[i0:].max())) if T>i0 else 0,funds_short_sessions=int(short[i0:].sum()),
                 sessions_both_sides_open=int(((G>0)&(R>0))[i0:].sum()),sessions_two_positions_one_side=int(((G>1)|(R>1))[i0:].sum()),
                 orders_rejected=sum(o['decision'].startswith('rejected') for o in orders),orders_cut=sum(o['decision']=='cut to fit available funds' for o in orders),
                 deployable_years=sum(bool(w.get('deployable')) for w in wf),no_new_entry_years=sum(not w['traded'] for w in wf),flat_cash_years=sum(bool(w.get('flat_cash_year')) for w in wf),
                 every_year_deployable=all(w.get('deployable') for w in wf),carry_scenarios=cs,
                 note='single executable account: orders admitted against funds; continuous daily-close drawdown across year ends; mean / worst over full test years only')
    daily=[dict(day=d,equity=round(float(A[i]-base)),assumed_margin=round(float(M[i])),funds=round(float(acc.capital+A[i])),green_positions=int(G[i]),red_positions=int(R[i])) for i,d in enumerate(acc.days) if i>=i0]
    return wf,daily,orders,summary

def _neighbour_keys(key,grid,file):
    """One-step neighbours of a strategy inside its grid file (configuration, profit rule, stop rule)."""
    with np.load(grid/file) as z:configs=[str(x) for x in z['configs']];P=[str(x) for x in z['profits']];S=[str(x) for x in z['stops']]
    side,st,off,cfg,prof,stop=key;ci,pi,si=configs.index(cfg),P.index(prof),S.index(stop)
    CN=zr.config_neighbours(configs);PN=zr.neighbours(P);SN=zr.compound_neighbours(S) if stop.startswith('c:') else zr.neighbours(S)
    return [(side,st,off,configs[j],prof,stop) for j in CN[ci] if j>=0]+[(side,st,off,cfg,P[j],stop) for j in PN[pi] if j>=0]+[(side,st,off,cfg,prof,S[j]) for j in SN[si] if j>=0]

def _robust(row,x,FG,FR,curves,curve,files,ys,i0,i1,capital,span,target,floor,max_dd,grid,min_days,T,buffer):
    """Swap each traded leg for its one-step neighbours (other leg and sizes fixed): share of those that pass every gate (in-sample),
    and the share of neighbours whose trades are identical to the chosen leg's (those pass trivially and say nothing)."""
    res=[];same=[]
    for mine,is_green in ((row['_g'],True),(row['_r'],False)):
        k=x['la'] if is_green else x['lb']
        if mine is None or not k:continue
        f=files.get(mine)
        if f is None:continue
        me=curves[mine]['at'][k][0]
        for nk in _neighbour_keys(mine,grid,f):
            c=curve(nk)
            if c['bad']:res.append(False);same.append(False);continue
            same.append(bool(np.array_equal(c['at'][k][0],me)))
            Fn=Fold([c['at'][k]],i0,i1,ys,min_days,T)
            tot,Y,worst,dd,mg,ex=combo_eval(Fn,FR[x['lb']],[0],[x['r']],capital,span,buffer) if is_green else combo_eval(FG[x['la']],Fn,[x['g']],[0],capital,span,buffer)
            res.append(bool(tot[0]>=target and worst[0]>=floor and dd[0]<=max_dd and ex[0]<=0))
    distinct=[p for p,q in zip(res,same) if not q]
    return dict(neighbour_swaps=len(res),neighbour_pass_share=round(sum(res)/len(res),3) if res else None,neighbour_identical_share=round(sum(same)/len(same),3) if same else None,
                neighbour_pass_share_distinct=round(sum(distinct)/len(distinct),3) if distinct else None)

def _csv(path,rows):
    keys=[];[keys.append(k) for r in rows for k in r if k not in keys and not k.startswith('_')]
    with open(path,'w',newline='') as f:w=csv.DictWriter(f,keys,extrasaction='ignore');w.writeheader();w.writerows(rows)

def parse_margin(text):
    out={}
    for part in (text or '').split(','):
        if not part.strip():continue
        k,v=part.split('=');k=k.strip();v=float(v)
        if not 0<=v<=1:raise ValueError('--margin rates are shares of notional (0..1)')
        if k=='futures':out['futures_zone']=out['futures_expiry']=v
        elif k in MARGIN:out[k]=v
        else:raise ValueError(f'unknown structure in --margin: {k}')
    return out

def parse_lots(text,lots):
    """Leg sizes to search: whole lots, 0..the lots the paths were simulated at (larger sizes were never simulated)."""
    if not text:return None
    out=set()
    for part in text.split(','):
        if '-' in part:a,b=part.split('-');out.update(range(int(a),int(b)+1))
        else:out.add(int(part))
    if min(out)<0:raise ValueError('--leg-lots must be >= 0')
    if max(out)>lots:raise ValueError(f'--leg-lots above {lots}: the paths were simulated at {lots} lots (rebuild them with a larger --lots)')
    if not any(out):raise ValueError('--leg-lots needs a size above 0')
    return sorted(out)

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--grid',required=True,help='zone_grid.py output directory');ap.add_argument('--paths',required=True,help='the zone_paths.sqlite the grid was built from')
    ap.add_argument('--out',default='portfolio');ap.add_argument('--capital',type=float,default=CAPITAL)
    ap.add_argument('--target',type=float,default=.22,help='overall yearly return on capital (pre-tax)');ap.add_argument('--floor',type=float,default=.17,help='minimum return in every judged calendar year')
    ap.add_argument('--max-dd',type=float,default=250_000.,help='largest allowed fall of combined daily-close equity from its peak, rupees')
    ap.add_argument('--rank',choices=('dd','worst_year','calmar'),default='dd');ap.add_argument('--pool',type=int,default=150,help='candidates per side, window and criterion')
    ap.add_argument('--min-trades',type=int,default=15);ap.add_argument('--wf-min-trades',type=int,help='trade minimum in walk-forward training windows (default max(10, min-trades // 2), as the grid)')
    ap.add_argument('--carry',type=float,default=.055);ap.add_argument('--carry-scenarios',default='0,.03,.055,.08');ap.add_argument('--top',type=int,default=50)
    ap.add_argument('--min-year-days',type=int,default=90,help='a part year shorter than this is not annualised and not held to --floor')
    ap.add_argument('--sizing',choices=('constant','actual'),default='constant');ap.add_argument('--ref-units',type=float,default=650.,help='units of --lots lots under --sizing constant (650 = 10 lots of 65)')
    ap.add_argument('--margin',default='',help='assumed margin as a share of notional per structure, e.g. futures=.12,naked=.12,calendar=.04 (defaults shown)')
    ap.add_argument('--margin-buffer',type=float,default=.10,help='share of available funds kept free of assumed margin (0..0.9)')
    ap.add_argument('--leg-lots',help='whole lots per leg to search, e.g. 0-10 or 0,5,10 (default 0..the paths file --lots); 0 = leg not traded')
    ap.add_argument('--if-none',choices=('cash','closest'),default='cash',help='test year whose training has no passing pair: no new entries, or trade the closest failing pair (research only)')
    ap.add_argument('--wf-top',type=int,default=10,help='top distinct passing pairs whose test-year results are reported per year')
    ap.add_argument('--holidays');ap.add_argument('--workers',type=int,default=1)
    a=ap.parse_args(argv)
    if a.capital<=0 or a.max_dd<=0 or a.target<=0:sys.exit('--capital, --max-dd and --target must be positive')
    if a.floor>a.target:sys.exit('--floor above --target: every year would have to beat the overall target')
    if a.pool<1 or a.top<1 or a.wf_top<1 or a.min_trades<1:sys.exit('--pool, --top, --wf-top and --min-trades must be >= 1')
    if not 1<=a.min_year_days<=366:sys.exit('--min-year-days must be 1..366')
    if a.ref_units<=0:sys.exit('--ref-units must be positive')
    if not 0<=a.margin_buffer<=.9:sys.exit('--margin-buffer must be 0..0.9')
    try:margin=parse_margin(a.margin);cs=tuple(float(x) for x in a.carry_scenarios.split(',') if x.strip())
    except ValueError as e:sys.exit(str(e))
    idx=zg.verify(a.grid,a.paths)                                                  # every grid file's hash, the computation digest and the paths file
    hol=zr.read_holidays(a.holidays) if a.holidays else []
    if sorted(hol)!=sorted(idx.get('holidays',[])):sys.exit('--holidays must be the list the grid was built with')
    with zg.Detail(a.paths) as D:lots=D.target_lots or 10
    if a.sizing=='constant' and a.ref_units%lots:print(f'note: --ref-units {a.ref_units:g} is not a whole number of units per lot at {lots} lots')
    try:leg_lots=parse_lots(a.leg_lots,lots)
    except ValueError as e:sys.exit(str(e))
    rep,wf,ins,gates=run(a.grid,a.paths,a.out,a.capital,a.target,a.floor,a.max_dd,a.rank,a.pool,a.min_trades,a.carry,a.top,hol,a.workers,min_days=a.min_year_days,
                         sizing=a.sizing,ref_units=a.ref_units,margin=margin,leg_lots=leg_lots,if_none=a.if_none,wf_top=a.wf_top,wf_min_trades=a.wf_min_trades,carry_scenarios=cs,buffer=a.margin_buffer)
    print('\nCombinations passing each gate (training data of each window; every target-and-floor survivor evaluated exactly):')
    for g in gates:
        if 'note' in g:print(f"  {g['fold']:10} {g['note']}");continue
        print(f"  {g['fold']:10} {g.get('combinations',0):>12,}  target {g.get('pass_target',0):>10,}  floor {g.get('pass_floor',0):>10,}  both {g.get('pass_target_and_floor',0):>9,}  "
              f"drawdown {g.get('pass_drawdown_of_target_and_floor',0):>8,}  funds {g.get('pass_funds_of_target_and_floor',0):>8,}  all {g.get('pass_all',0):>7,}")
    print('\nWalk-forward executable account (choice made on earlier years only, adopted flat on 1 January, orders admitted against funds):')
    for w in wf:
        r=w.get('account_return');leg=lambda n:'none' if not w.get(f'{n}_lots') else f"{w[n+'_lots']}L {w[n+'_structure']} {w[n+'_offset']:+.0f} {w[n+'_config']} {w[n+'_profit']} {w[n+'_stop']}"
        print(f"  {w['test_year']}: {'n/a' if r is None else f'{r:.1%}'}{'' if w.get('test_annualised',True) else ' (part year, not annualised)'}  {w['decision']}"+
              (f"{' (carried positions only)' if not w['traded'] and not w.get('flat_cash_year',True) else ''}")+
              (f" | green {leg('green')} | red {leg('red')}" if w['traded'] else '')+
              (f"  [orders cut {w.get('orders_cut',0)}, rejected {w.get('orders_rejected',0)}; deployable {w.get('deployable')}]")+
              (f"  [top {w['top_k']}: median {w['top_k_median_return']:.1%}, worst {w['top_k_worst_return']:.1%}]" if w.get('top_k') else ''))
    s=rep.get('walk_forward') or {}
    if s.get('returns'):
        print(f"  mean {s['mean']:.1%}, worst year {s['worst']:.1%}; daily-close drawdown Rs {s['daily_close_drawdown_continuous']:,} continuous (largest within a year Rs {s['largest_in_year_drawdown']:,}); "
              f"assumed margin peak Rs {s['assumed_margin_peak']:,}, funds short {s['funds_short_sessions']} sessions; {s['no_new_entry_years']} no-new-entry, {s['flat_cash_years']} flat-cash year(s); every year deployable: {s['every_year_deployable']}")
        print('  futures carry sensitivity (yearly account returns): '+'; '.join(f"{float(k):.1%}: "+', '.join(f'{y} {v:.1%}' for y,v in d.items()) for k,d in s['carry_scenarios'].items()))
    if ins:
        b=ins[0];print(f"\nIn-sample best ({'passes' if b['passed'] else 'closest; none pass'}), fitted to {rep['start']}..{rep['split']}: overall {b['overall']:.1%}, worst year {'n/a' if b['worst_year'] is None else format(b['worst_year'],'.1%')}, "
                       f"drawdown Rs {b['daily_close_drawdown']:,}, assumed margin peak Rs {b['assumed_margin_peak']:,}, green {b['green_lots']} lots, red {b['red_lots']} lots, "
                       f"neighbour pass share {b.get('neighbour_pass_share')} (distinct neighbours only: {b.get('neighbour_pass_share_distinct')}, identical: {b.get('neighbour_identical_share')})")
    print(f'-> {a.out}/portfolio_walk_forward.csv, portfolio_account_daily.csv, portfolio_orders.csv, portfolio_pairs_in_sample.csv, portfolio_gate_counts.csv, portfolio_report.json')

if __name__=='__main__':main()

