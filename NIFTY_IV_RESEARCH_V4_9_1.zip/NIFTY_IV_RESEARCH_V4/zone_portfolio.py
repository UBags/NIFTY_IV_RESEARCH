#!/usr/bin/env python3
"""Green + red portfolio selection on rupee returns, yearly floors, combined drawdown and margin (V4.9.1).

A portfolio is one green (bull) strategy and one red (bear) strategy, each at its own size (0..--lots lots; 0 = that leg not
traded), run on one account. Each strategy is a grid combination (structure, strike offset, signal configuration, profit rule,
stop rule). The account is judged as a whole:

  sizing            --sizing constant (default): every trade is valued at --ref-units units (default 650 = 10 lots of 65) times
                    the share of its target size that filled, so a point is worth the same in every year whatever the exchange
                    lot size was (50 / 25 / 75 / 65 in the data). --sizing actual: the units the path really held (V4.9.0).
                    A leg at k lots of --lots scales its trades by k / --lots.
  margin            per open position and session: rate x |units| x index close (--margin, defaults futures 12%, naked short
                    12%, calendar 4% of notional; ASSUMPTIONS, check against your broker's SPAN). The peak of the combined daily
                    margin, both legs and any position carried across a strategy change, must be <= --capital.
  return per year   that calendar year's rupee P&L (mark-to-market at the year's last close) / capital, annualised for a part
                    year of at least --min-year-days; shorter part years are neither annualised nor held to the floor. Simple
                    (not compounded) returns.
  overall return    total rupee P&L / capital / years covered
  drawdown          largest fall of the combined daily equity from its running peak (session closes; stale marks carried
                    forward, their share is reported per leg)
  gates             overall >= --target, every judged year >= --floor (no judged year: fails, reported), drawdown <= --max-dd,
                    peak margin <= --capital
  ranking           among (pair, sizes) passing every gate: --rank dd (smallest drawdown, default), worst_year or calmar;
                    ties by higher overall return. Because P&L and drawdown scale with size, searching the sizes turns
                    "return >= target, drawdown <= limit" into the size that reaches the target with the least drawdown.

Selection is walk-forward: for test year Y the pair and sizes are chosen on [--start, Y) only (pools, gates, ranking). The
chosen pair is then traded in a single chronological ACCOUNT: adopted flat on 1 January of Y (signals entering before then are
ignored), entries only during Y, positions still open at the year end run to their own exits (their P&L and margin stay in the
account, overlapping the next year's pair). Yearly returns, the continuous drawdown and the peak margin come from that account.
A year whose training data has no passing pair is in cash (--if-none cash, default) or trades the closest failing pair
(--if-none closest, research only; never 'deployable'). Training curves follow the grid's convention (one continuous strategy
from --start), so pools and training gates agree with the grid's numbers.

Candidates: for each side and training window the union of the top --pool combinations by training total, worst training year
and the grid's stability score, each with >= --min-trades trades (walk-forward windows: --wf-min-trades, default
max(10, min-trades // 2), as the grid uses). Pools are ranked on the grid's per-unit points.

Robustness and uncertainty: for each chosen pair, the share of one-step neighbour swaps (one leg at a time, in-sample) that
still pass; for each test year, the test results of the top --wf-top passing choices (median / worst), not only the best;
the walk-forward account at several futures carry rates (--carry-scenarios).

Futures are spot-proxy: an assumed carry (--carry, 5.5%/yr) is charged pro rata on futures legs (long pays, short receives).

Outputs (in --out): portfolio_walk_forward.csv, portfolio_account_daily.csv, portfolio_pairs_in_sample.csv,
portfolio_gate_counts.csv, portfolio_report.json."""
import argparse,collections,csv,datetime as dt,heapq,json,math,sys,time
from pathlib import Path
import numpy as np
import zone_grid as zg
import zone_rules as zr

CAPITAL=2_500_000.
MARGIN={'futures_zone':.12,'futures_expiry':.12,'naked':.12,'calendar':.04}
NONE_LEG=('none',)

# ---------------- candidate pools from the grid files ----------------
_P={}
def _year_factor(start,split):
    """Calendar years covered inside [start, split) and the annualisation factor of each (365 / days covered)."""
    a=dt.date.fromisoformat(start);b=dt.date.fromisoformat(split);out={}
    for y in range(a.year,b.year+1):
        lo=max(a,dt.date(y,1,1));hi=min(b,dt.date(y+1,1,1));d=(hi-lo).days
        if d>0:out[y]=365./d
    return out

def _pool_file(e):
    """Top candidates of one grid file for every (training window, criterion)."""
    c=_P;K=c['pool'];out=[]
    with np.load(c['grid']/e['file']) as z:Z={k:z[k] for k in ('n','total','configs','profits','stops','windows')}
    configs=list(Z['configs']);P=list(Z['profits']);S=list(Z['stops']);wn=list(Z['windows'])
    CN=zr.config_neighbours(configs);PN=zr.neighbours(P);SN=zr.compound_neighbours(S) if e['kind'].startswith('compound') else zr.neighbours(S)
    for fold,(wname,years,mt) in c['folds'].items():
        if wname not in wn:continue
        wi=wn.index(wname);N=Z['n'][:,wi].astype(np.int64);T=Z['total'][:,wi]
        ok=N>=mt
        if not ok.any():continue
        yw=lambda y:f'test_{y}' if f'test_{y}' in wn else f'train_{y+1}'          # the first (part) year has no test window: train_<next year> is that year alone
        yr=[Z['total'][:,wn.index(yw(y))]*c['factor'][y] for y in years if yw(y) in wn]
        worst=np.min(np.stack(yr),0) if yr else T
        stab,_=zg.stability(N,T,mt,CN,PN,SN)
        for crit,score in (('total',T),('worst_year',worst),('stable',stab)):
            sc=np.where(ok&np.isfinite(score),score,-np.inf).ravel();k=min(K,int(np.isfinite(sc).sum()))
            if not k:continue
            for f in np.argpartition(-sc,k-1)[:k]:
                ci,pi,si=np.unravel_index(int(f),N.shape)
                out.append((fold,crit,float(sc[f]),(e['side'],e['structure'],float(e['offset']),str(configs[ci]),str(P[pi]),str(S[si])),e['file']))
    return out

def pools(grid,folds,factor,pool,workers=1):
    """{(fold, side): {candidate key: file}} with the top `pool` per criterion across all files. folds: {fold: (window, years, min trades)}."""
    idx=zg.read_json(grid/'grid_index.json');_P.clear();_P.update(grid=grid,folds=folds,factor=factor,pool=pool)
    best=collections.defaultdict(list)
    for part in zg.pool_map(_pool_file,idx['groups'],workers):
        for fold,crit,score,key,f in part:best[fold,key[0],crit].append((score,key,f))
    out=collections.defaultdict(dict)
    for (fold,side,crit),lst in best.items():
        lst.sort(key=lambda x:(-x[0],x[1]))
        for _,key,f in lst[:pool]:out[fold,side][key]=f
    return out,idx

# ---------------- daily rupee equity and margin of one strategy ----------------
def sizer(sizing='actual',ref_units=650.,target_lots=None):
    """Units a trade is valued at. constant: ref_units x (units filled / (lot x target lots)); actual: the units held."""
    stats=collections.Counter()
    def f(x):
        if sizing=='actual':return float(x['units'])
        lot=x.get('lot')
        if not lot or not target_lots:stats['lot_unknown']+=1;return float(ref_units)
        return float(ref_units)*min(1.,float(x['units'])/(lot*target_lots))
    f.stats=stats;return f

def replay(trades,sess_ord,structure='naked',carry=0.,size=None,sess_close=None,margin_rate=0.):
    """Daily rupee equity over sessions sess_ord (ordinals): closed trades plus the open trade valued at each session's last
    close (its last finite mark carried forward). A trade is open from its entry session up to the session of its last exit
    fill, where its P&L is realised; one still open at the end is valued at its window-end value. One position at a time.
    Returns dict(E equity, open mask, M margin in rupees, bad = trades without a value, stale / marks counts)."""
    T=len(sess_ord);O=np.zeros(T);open_=np.zeros(T,bool);realised=np.zeros(T);M=np.zeros(T);bad=0;stale=0;nm=0
    fut=structure.startswith('futures')                                          # V4.9.1: production labels are futures_zone / futures_expiry
    for x in trades:
        if not math.isfinite(x['unit']):bad+=1;continue
        u=size(x) if size else x['units'];e0=dt.date.fromisoformat(x['entry_day']).toordinal();e1=dt.date.fromisoformat(x['exit_day']).toordinal()
        c=x.get('sign',1.)*x.get('index',0.)*carry/365. if fut and carry else 0.     # assumed carry, points per unit per day
        i0=int(np.searchsorted(sess_ord,e0));i1=int(np.searchsorted(sess_ord,e1));hi=min(i1,T)
        mo=np.asarray(x['mark_ord'],np.int64);mv=np.asarray(x['marks'],float);fin=np.isfinite(mv)
        si=np.searchsorted(sess_ord,mo[fin]);mv=mv[fin]-c*(mo[fin]-e0)
        stale+=int(x.get('stale',0));nm+=int(x.get('marks_n',len(mo)))
        n=max(hi-i0,0)
        if n:
            seg=np.full(n,np.nan);last=np.r_[si[1:]!=si[:-1],True] if len(si) else np.zeros(0,bool)   # marks are in time order: the session's last close
            k=si[last];v=mv[last];inb=(k>=i0)&(k<hi);seg[k[inb]-i0]=v[inb]
            ok=np.isfinite(seg);fill=np.where(ok,np.arange(n),-1);np.maximum.accumulate(fill,out=fill)
            seg=np.where(fill>=0,seg[np.maximum(fill,0)],0.)
            if open_[i0:hi].any():raise ValueError('overlapping trades inside one strategy')
            O[i0:hi]=seg*u;open_[i0:hi]=True
            if margin_rate and sess_close is not None:M[i0:hi]=margin_rate*abs(u)*sess_close[i0:hi]
        final=(x['unit']-c*(e1-e0))*u
        if i1<T:realised[i1]+=final
        elif T:
            O[T-1]=final;open_[T-1]=True                                            # open at the window end: its window-end value
            if margin_rate and sess_close is not None:M[T-1]=margin_rate*abs(u)*sess_close[T-1]
    return dict(E=np.cumsum(realised)+O,open=open_,M=M,bad=bad,stale=stale,marks=nm,n=len(trades))

def equity(trades,sess_ord,structure='naked',carry=0.):
    """V4.9.0 interface: (equity, open mask, trades without a value) at the units each trade held."""
    r=replay(trades,sess_ord,structure,carry);return r['E'],r['open'],r['bad']

# ---------------- pair evaluation ----------------
def year_slices(sess_days,lo,hi,factor=None):
    """[(year, i_start, i_end, annualisation, calendar days covered)]: sessions of each calendar year inside [lo, hi). A part
    year (the window starts or ends inside it, or the data does) is annualised over the calendar days it covers: 365 / days."""
    out=[];inside=[i for i,d in enumerate(sess_days) if lo<=d<hi]
    if not inside:return out
    end=min(dt.date.fromisoformat(hi),dt.date.fromisoformat(sess_days[-1])+dt.timedelta(1));lo_d=dt.date.fromisoformat(lo)
    for y in sorted({sess_days[i][:4] for i in inside}):
        idx=[i for i in inside if sess_days[i][:4]==y];y=int(y)
        days=(min(end,dt.date(y+1,1,1))-max(lo_d,dt.date(y,1,1))).days
        out.append((y,idx[0],idx[-1],365./max(days,1),days))
    return out

def pair_metrics(G,R,i0,i1,ys,capital,span_years,chunk=64,min_days=90):
    """All green x red pairs at full size over sessions [i0, i1]: yearly returns (nG, nR, Y), overall return, worst judged
    year (NaN when no year covers min_days: not judged, V4.9.1), max drawdown."""
    base=lambda A,i:A[:,i-1] if i>i0 else np.zeros(len(A))
    fy=[f if d>=min_days else 1. for *_,f,d in ys];yG=np.stack([(G[:,b]-base(G,a))*f for (_,a,b,*_),f in zip(ys,fy)],1);yR=np.stack([(R[:,b]-base(R,a))*f for (_,a,b,*_),f in zip(ys,fy)],1)
    Y=(yG[:,None,:]+yR[None,:,:])/capital
    tot=((G[:,i1]-base(G,i0))[:,None]+(R[:,i1]-base(R,i0))[None,:])/capital/span_years
    dd=np.empty((len(G),len(R)))
    g0=base(G,i0);r0=base(R,i0)
    for a in range(0,len(G),chunk):
        S=(G[a:a+chunk,None,i0:i1+1]-g0[a:a+chunk,None,None])+(R[None,:,i0:i1+1]-r0[None,:,None])
        S=np.concatenate([np.zeros(S.shape[:2]+(1,)),S],2)
        dd[a:a+chunk]=(np.maximum.accumulate(S,2)-S).max(2)
    judged=[j for j,y in enumerate(ys) if y[4]>=min_days]
    worst=Y[:,:,judged].min(2) if judged else np.full(tot.shape,np.nan)
    return Y,tot,worst,dd

def _dd_rows(S):
    """Max drawdown of each row of S (rows x sessions), equity starting at 0 before the first session."""
    S=np.concatenate([np.zeros((len(S),1),S.dtype),S],1);return (np.maximum.accumulate(S,1)-S).max(1)

class Fold:
    """Training-window arrays of a side's candidate curves; row n (the last) is the empty leg (zeros)."""
    def __init__(self,curves,i0,i1,ys,min_days,T):
        E=np.vstack([c['E'] for c in curves]+[np.zeros(T)]);M=np.vstack([c['M'] for c in curves]+[np.zeros(T)])
        b=E[:,i0-1] if i0>0 else np.zeros(len(E));self.n=len(curves)
        self.judged=[j for j,y in enumerate(ys) if y[4]>=min_days];fy=[y[3] if y[4]>=min_days else 1. for y in ys]
        self.y=np.stack([(E[:,bb]-(E[:,aa-1] if aa>i0 else b))*f for (_,aa,bb,*_),f in zip(ys,fy)],1)
        self.t=E[:,i1]-b;self.D=(E[:,i0:i1+1]-b[:,None]).astype(np.float32);self.M=M[:,i0:i1+1].astype(np.float32)
        self.open=np.vstack([c['open'] for c in curves]+[np.zeros(T,bool)])[:,i0:i1+1]

def combo_eval(FG,FR,g,r,a,b,capital,span):
    """Metrics of explicit combinations (index arrays g, r into FG / FR rows; weights a, b)."""
    g=np.asarray(g);r=np.asarray(r);a=np.asarray(a,float);b=np.asarray(b,float)
    tot=(a*FG.t[g]+b*FR.t[r])/capital/span
    Y=(a[:,None]*FG.y[g]+b[:,None]*FR.y[r])/capital
    worst=Y[:,FG.judged].min(1) if FG.judged else np.full(len(g),np.nan)
    dd=np.empty(len(g));mg=np.empty(len(g))
    for s in range(0,len(g),20000):
        sl=slice(s,s+20000);aa=a[sl,None].astype(np.float32);bb=b[sl,None].astype(np.float32)
        dd[sl]=_dd_rows(aa*FG.D[g[sl]]+bb*FR.D[r[sl]]);mg[sl]=(aa*FG.M[g[sl]]+bb*FR.M[r[sl]]).max(1)
    return tot,Y,worst,dd,mg

def search(FG,FR,lots,leg_lots,capital,span,target,floor,max_dd,rank,top,max_evals=5_000_000,closest_keep=2000):
    """Every (green, red, green lots, red lots): target and floor screened for all, drawdown and peak margin for the
    survivors. Returns (rows sorted best first, passed flag, gate counts)."""
    cnt=collections.Counter();cand=[];close=[]
    for la in leg_lots:
        for lb in leg_lots:
            if not la and not lb:continue
            a=la/lots;b=lb/lots;gi=np.arange(FG.n) if la else np.array([FG.n]);ri=np.arange(FR.n) if lb else np.array([FR.n])
            if not len(gi) or not len(ri):continue
            tot=(a*FG.t[gi][:,None]+b*FR.t[ri][None,:])/capital/span
            if FG.judged:worst=((a*FG.y[gi][:,None,:]+b*FR.y[ri][None,:,:])[:,:,FG.judged]/capital).min(2)
            else:worst=np.full(tot.shape,np.nan);cnt['no_judged_year']+=tot.size
            p1=tot>=target;p2=worst>=floor;ok=p1&p2
            cnt['combinations']+=tot.size;cnt['pass_target']+=int(p1.sum());cnt['pass_floor']+=int(p2.sum());cnt['pass_target_and_floor']+=int(ok.sum())
            A,B=np.nonzero(ok)
            if len(A):cand.append((gi[A],ri[B],np.full(len(A),la),np.full(len(A),lb)))
            sf=np.maximum(target-tot,0)/target+np.where(np.isfinite(worst),np.maximum(floor-worst,0)/max(floor,1e-9),10.)
            k=min(closest_keep,sf.size);f=np.argpartition(sf.ravel(),k-1)[:k];A,B=np.unravel_index(f,sf.shape)
            close.append((sf.ravel()[f],gi[A],ri[B],np.full(k,la),np.full(k,lb)))
    def metrics(g,r,la,lb):
        tot,Y,worst,dd,mg=combo_eval(FG,FR,g,r,la/lots,lb/lots,capital,span);return dict(g=g,r=r,la=la,lb=lb,tot=tot,Y=Y,worst=worst,dd=dd,mg=mg)
    if cand:
        g,r,la,lb=(np.concatenate(x) for x in zip(*cand))
        if len(g)>max_evals:                                                      # keep the highest training totals; reported
            cnt['truncated_to_max_evals']=len(g)-max_evals;k=np.argsort(-(la/lots*FG.t[g]+lb/lots*FR.t[r]),kind='stable')[:max_evals];g,r,la,lb=g[k],r[k],la[k],lb[k]
        m=metrics(g,r,la,lb);p3=m['dd']<=max_dd;p4=m['mg']<=capital
        cnt['pass_drawdown_of_target_and_floor']=int(p3.sum());cnt['pass_margin_of_target_and_floor']=int(p4.sum());ok=p3&p4;cnt['pass_all']=int(ok.sum())
        if ok.any():
            sel={k:v[ok] for k,v in m.items()};k1,k2=rank_key(rank,sel['tot'],sel['worst'],sel['dd'])
            order=np.lexsort((sel['lb'],sel['la'],sel['r'],sel['g'],k2,k1))
            pair=sel['g'].astype(np.int64)*(FR.n+1)+sel['r'];_,first=np.unique(pair[order],return_index=True)   # each pair once, at its best sizes
            order=order[np.sort(first)][:top];cnt['distinct_pairs_passing']=len(first)
            return [_row(sel,i,True) for i in order],True,cnt
    cnt.setdefault('pass_all',0)
    if not close:return [],False,cnt
    sf,g,r,la,lb=(np.concatenate(x) for x in zip(*close));k=np.argsort(sf,kind='stable')[:closest_keep]
    m=metrics(g[k],r[k],la[k],lb[k]);w=np.where(np.isfinite(m['worst']),np.maximum(floor-m['worst'],0)/max(floor,1e-9),10.)
    short=np.maximum(target-m['tot'],0)/target+w+np.maximum(m['dd']-max_dd,0)/max_dd+np.maximum(m['mg']-capital,0)/capital
    order=np.lexsort((m['lb'],m['la'],m['r'],m['g'],short))[:top]
    return [_row(m,i,False) for i in order],False,cnt

def _row(m,i,passed):return dict(g=int(m['g'][i]),r=int(m['r'][i]),la=int(m['la'][i]),lb=int(m['lb'][i]),tot=float(m['tot'][i]),Y=m['Y'][i],worst=float(m['worst'][i]),dd=float(m['dd'][i]),mg=float(m['mg'][i]),passed=passed)

def rank_key(rank,tot,worst,dd):
    if rank=='worst_year':return -worst,-tot
    if rank=='calmar':return -(tot/np.maximum(dd,1.)),-tot
    return dd,-tot

# ---------------- main flow ----------------
def run(grid,paths_db,out,capital=CAPITAL,target=.22,floor=.17,max_dd=250_000.,rank='dd',pool=150,min_trades=15,carry=.055,top=50,
        holidays=(),workers=1,progress=True,min_days=90,sizing='constant',ref_units=650.,margin=None,leg_lots=None,if_none='cash',wf_top=10,
        wf_min_trades=None,carry_scenarios=(0.,.03,.055,.08),max_evals=5_000_000):
    grid=Path(grid);out=Path(out);out.mkdir(parents=True,exist_ok=True);t0=time.time();margin=dict(MARGIN,**(margin or {}))
    gi=zg.read_json(grid/'grid_index.json');start,split=gi['start'],gi['split'];factor=_year_factor(start,split)
    wins=[w[0] for w in gi['windows']];test_years=sorted(int(w[5:]) for w in wins if w.startswith('test_'))
    wmt=wf_min_trades if wf_min_trades is not None else max(10,min_trades//2)
    folds={f'test_{y}':(f'train_{y}',sorted({t for t in test_years+[int(start[:4])] if t<y}),wmt) for y in test_years if f'train_{y}' in wins}
    folds['in_sample']=('train_full',sorted(set(test_years+[int(start[:4])])),min_trades)
    P,_=pools(grid,folds,factor,pool,workers)
    if progress:print('pools: '+', '.join(f'{f} {s} {len(v)}' for (f,s),v in sorted(P.items()))+f' ({time.time()-t0:.0f}s)',flush=True)
    D=zg.Detail(paths_db,holidays);lots=D.target_lots or 10;leg_lots=sorted(set(leg_lots if leg_lots is not None else range(lots+1)))
    sess_days=sorted({d for d in D.bars.day if start<=d<split});sess_ord=np.array([dt.date.fromisoformat(d).toordinal() for d in sess_days])
    last_close={};[last_close.__setitem__(d,c) for d,c in zip(D.bars.day,D.bars.close)];sess_close=np.array([last_close[d] for d in sess_days])
    size=sizer(sizing,ref_units,lots)
    def sel_of(key):side,st,off,cfg,prof,stop=key;return dict(side=side,structure=st,offset=off,config=cfg,profit=prof,stop=stop)
    def rep(key,trades,carry_=carry):return replay(trades,sess_ord,key[1],carry_,size,sess_close,margin.get(key[1],0.))
    curves={};files={}
    def curve(key):
        if key not in curves:
            tr=D.trades(sel_of(key),start,split);curves[key]=dict(rep(key,tr),key=key)
        return curves[key]
    allkeys=sorted({k for v in P.values() for k in v},key=lambda k:(k[1],k[2],k[0],k[3:]))
    for (f,s),v in P.items():files.update(v)
    for i,k in enumerate(allkeys):
        curve(k)
        if progress and (i+1)%500==0:print(f'  replayed {i+1}/{len(allkeys)} ({time.time()-t0:.0f}s)',flush=True)
    if progress:print(f'replayed {len(allkeys)} strategies ({time.time()-t0:.0f}s)',flush=True)
    dropped={s:sum(1 for k in allkeys if k[0]==s and curves[k]['bad']) for s in ('bull','bear')}
    gates=[];picks={};ins=[];report=dict(start=start,split=split,min_year_days=min_days,capital=capital,target=target,floor=floor,max_drawdown=max_dd,rank=rank,pool=pool,
        min_trades=min_trades,wf_min_trades=wmt,carry=carry,sizing=sizing,ref_units=ref_units if sizing=='constant' else None,target_lots=lots,leg_lots=leg_lots,margin_rates=margin,if_none=if_none,
        candidates_dropped_for_unvalued_trades=dropped,folds={},
        conventions=dict(returns='simple rupee P&L / capital per calendar year, part years >= min_year_days annualised, not compounded',
            training_curves='one continuous strategy from start (the grid convention)',account='flat adoption on 1 January of each test year, entries during that year only, open positions run to their own exits',
            margin='rate x |units| x index close per open position and session: an assumption, not SPAN',stale_marks='last known leg close carried forward; share of bar closes without a fresh print reported'))
    for fold,(wname,years,mt) in folds.items():
        g,dg=_distinct([k for k in P.get((fold,'bull'),{}) if not curves[k]['bad']],curves);r,dr=_distinct([k for k in P.get((fold,'bear'),{}) if not curves[k]['bad']],curves)
        lo=start;hi=f'{fold[5:]}-01-01' if fold.startswith('test_') else split
        ys=year_slices(sess_days,lo,hi)
        if (not g and not r) or not ys:report['folds'][fold]=dict(note='no candidates');continue
        i0=ys[0][1];i1=ys[-1][2];span=sum(d for *_,d in ys)/365.
        T=len(sess_days);FG=Fold([curves[k] for k in g],i0,i1,ys,min_days,T);FR=Fold([curves[k] for k in r],i0,i1,ys,min_days,T)
        res,passed,cnt=search(FG,FR,lots,leg_lots,capital,span,target,floor,max_dd,rank,max(top,wf_top),max_evals)
        gates.append(dict(fold=fold,green_candidates=len(g),red_candidates=len(r),green_identical_dropped=dg,red_identical_dropped=dr,**cnt))
        rows=[_out(fold,x,g,r,curves,ys,min_days,FG,FR) for x in res]
        if rows:rows[0].update(_robust(rows[0],res[0],g,r,curves,curve,files,FG,FR,ys,i0,i1,lots,capital,span,target,floor,max_dd,grid,min_days))
        if fold=='in_sample':ins=rows[:top]
        else:picks[int(fold[5:])]=(rows,passed)
        report['folds'][fold]=dict(green_candidates=len(g),red_candidates=len(r),**cnt,best={k:v for k,v in rows[0].items() if not k.startswith('_')} if rows else None)
        if progress:print(f'{fold}: {cnt["combinations"]:,} combinations, {cnt["pass_all"]:,} pass every gate ({time.time()-t0:.0f}s)',flush=True)
    wf,daily,summary=account(picks,D,sess_days,sess_ord,sess_close,split,capital,min_days,if_none,wf_top,lots,carry,carry_scenarios,margin,size,sel_of,floor)
    D.close();report['walk_forward']=summary;report['sizing_lot_unknown']=size.stats.get('lot_unknown',0)
    _csv(out/'portfolio_walk_forward.csv',wf);_csv(out/'portfolio_pairs_in_sample.csv',ins);_csv(out/'portfolio_gate_counts.csv',gates);_csv(out/'portfolio_account_daily.csv',daily)
    report['gate_counts']=gates;zg.write_json(report,out/'portfolio_report.json',indent=1,default=str)
    return report,wf,ins,gates

def _distinct(keys,curves):
    """One candidate per distinct daily equity + margin history (different rule labels with identical trades, e.g. a wide stop
    that never fires, or a layered policy whose only active part is its mandatory exit). Returns (kept keys, dropped count);
    each kept curve records how many labels it stands for."""
    seen={};out=[]
    for k in sorted(keys,key=lambda k:(k[1],k[2],k[3:])):
        c=curves[k];h=hash(c['E'].tobytes()+c['M'].tobytes())
        if h in seen:curves[seen[h]]['aliases']=curves[seen[h]].get('aliases',1)+1;continue
        seen[h]=k;out.append(k);c.setdefault('aliases',1)
    return out,len(keys)-len(out)

def _leg(name,key,lots,curves):
    if key is None or not lots:return {f'{name}_lots':0,f'{name}_structure':'none'}
    side,st,off,cfg,prof,stop=key;c=curves[key]
    return {f'{name}_lots':lots,f'{name}_structure':st,f'{name}_offset':off,f'{name}_config':cfg,f'{name}_profit':prof,f'{name}_stop':stop,f'{name}_trades':c['n'],
            f'{name}_stale_share':round(c['stale']/c['marks'],3) if c['marks'] else None,f'{name}_identical_rules':c.get('aliases',1)}

def _out(fold,x,g,r,curves,ys,min_days,FG,FR):
    gk=g[x['g']] if x['g']<len(g) else None;rk=r[x['r']] if x['r']<len(r) else None
    ov=int((FG.open[x['g']]&FR.open[x['r']]).sum()) if x['la'] and x['lb'] else 0
    return dict(fold=fold,passed=x['passed'],overall=round(x['tot'],6),worst_year=None if math.isnan(x['worst']) else round(x['worst'],6),max_drawdown=round(x['dd']),peak_margin=round(x['mg']),
                **{f'year_{y}'+('' if ys[j][4]>=min_days else f'_part_{ys[j][4]}d_not_annualised'):round(float(x['Y'][j]),6) for j,(y,*_) in enumerate(ys)},
                overlap_sessions=ov,**_leg('green',gk,x['la'],curves),**_leg('red',rk,x['lb'],curves),_g=gk,_r=rk)

def account(picks,D,sess_days,sess_ord,sess_close,split,capital,min_days,if_none,wf_top,lots,carry,carry_scenarios,margin,size,sel_of,floor):
    """The walk-forward account: each test year's choice adopted flat on 1 January, entries during that year only."""
    T=len(sess_days);A=np.zeros(T);M=np.zeros(T);legs=[];wf=[];trades_by=[];years=sorted(picks)
    def leg_curve(key,y,carry_=carry,trades=None):
        lo=f'{y}-01-01';hi=min(f'{y+1}-01-01',split)
        tr=trades if trades is not None else D.trades(sel_of(key),lo,hi,flat=True,value_to=split)
        return tr,replay(tr,sess_ord,key[1],carry_,size,sess_close,margin.get(key[1],0.))
    def year_ret(E,y):
        ys=year_slices(sess_days,f'{y}-01-01',min(f'{y+1}-01-01',split))
        if not ys:return None,None,None
        _,a,b,f,days=ys[0];e0=E[a-1] if a>0 else 0.;return (E[b]-e0)/capital*(f if days>=min_days else 1.),days,(a,b)
    for y in years:
        rows,passed=picks[y];row=rows[0] if rows else None
        trade=row is not None and (passed or if_none=='closest')
        rec=dict(test_year=y,deployable=bool(row and passed),traded=trade,decision='pass' if row and passed else ('closest (research only)' if trade else 'cash: no pair passed in training'))
        Ey=np.zeros(T)
        if trade:
            for name,key,l in (('green',row['_g'],row['green_lots']),('red',row['_r'],row['red_lots'])):
                if not l or key is None:continue
                tr,c=leg_curve(key,y);w=l/lots;Ey+=w*c['E'];A+=w*c['E'];M+=w*c['M'];legs.append((y,name,c['open']));trades_by.append((key,y,w,tr))
            rec.update({k:v for k,v in row.items() if not k.startswith('_') and k!='fold'})
        ret,days,ab=year_ret(Ey,y)
        rec.update(test_return=None if ret is None else round(float(ret),6),test_days=days,test_annualised=bool(days and days>=min_days))
        alt=[]                                                                    # the other top passing choices, alone, in the same test year
        if passed:
            for x in rows[1:wf_top]:
                E2=np.zeros(T)
                for key,l in ((x['_g'],x['green_lots']),(x['_r'],x['red_lots'])):
                    if l and key is not None:E2+=l/lots*leg_curve(key,y)[1]['E']
                alt.append(year_ret(E2,y)[0])
        alt=[v for v in alt if v is not None]
        if alt:
            allr=[ret]+alt;rec.update(top_k=len(allr),top_k_median_return=round(float(np.median(allr)),6),top_k_worst_return=round(float(min(allr)),6),top_k_share_meeting_floor=round(float(np.mean([v>=floor for v in allr])),3))
        wf.append(rec)
    summary={}
    if years:
        first=year_slices(sess_days,f'{years[0]}-01-01',split)
        if first:
            i0=first[0][1];base=A[i0-1] if i0>0 else 0.;S=np.r_[0.,A[i0:]-base];run_dd=np.maximum.accumulate(S)-S
            for rec in wf:
                r_,_,ab=year_ret(A,rec['test_year'])
                rec['account_return']=None if r_ is None else round(float(r_),6)
                if ab:a,b=ab;e0=A[a-1] if a>0 else 0.;s=np.r_[0.,A[a:b+1]-e0];rec['account_max_drawdown_in_year']=round(float((np.maximum.accumulate(s)-s).max()))
            G=np.zeros(T,int);R_=np.zeros(T,int)
            for y,name,op in legs:(G if name=='green' else R_)[:]+=op
            full=[w for w in wf if w.get('account_return') is not None and w['test_annualised']];rets=[w['account_return'] for w in full]
            cs={}
            for cr in carry_scenarios:
                E=np.zeros(T)
                for key,y,w,tr in trades_by:E+=w*leg_curve(key,y,cr,tr)[1]['E']
                cs[str(cr)]={str(w['test_year']):round(float(year_ret(E,w['test_year'])[0]),6) for w in full}
            summary=dict(years=[w['test_year'] for w in full],returns=[float(v) for v in rets],mean=round(float(np.mean(rets)),6) if rets else None,worst=round(float(min(rets)),6) if rets else None,
                         continuous_max_drawdown=round(float(run_dd.max())),largest_in_year_drawdown=max([w.get('account_max_drawdown_in_year',0) for w in wf],default=0),
                         peak_margin=round(float(M[i0:].max())) if T>i0 else 0,margin_over_capital_sessions=int((M[i0:]>capital).sum()),
                         sessions_both_sides_open=int(((G>0)&(R_>0))[i0:].sum()),sessions_two_positions_one_side=int(((G>1)|(R_>1))[i0:].sum()),
                         deployable_years=sum(w['deployable'] for w in wf),cash_years=sum(not w['traded'] for w in wf),carry_scenarios=cs,
                         note='single chronological account; continuous drawdown runs across year ends; full test years only in mean / worst')
            daily=[dict(day=d,equity=round(float(A[i]-base)),margin=round(float(M[i])),green_positions=int(G[i]),red_positions=int(R_[i])) for i,d in enumerate(sess_days) if i>=i0]
            return wf,daily,summary
    return wf,[],summary

def _neighbour_keys(key,grid,file):
    """One-step neighbours of a strategy inside its grid file (configuration, profit rule, stop rule)."""
    with np.load(grid/file) as z:configs=[str(x) for x in z['configs']];P=[str(x) for x in z['profits']];S=[str(x) for x in z['stops']]
    side,st,off,cfg,prof,stop=key;ci,pi,si=configs.index(cfg),P.index(prof),S.index(stop)
    CN=zr.config_neighbours(configs);PN=zr.neighbours(P);SN=zr.compound_neighbours(S) if stop.startswith('c:') else zr.neighbours(S)
    return [(side,st,off,configs[j],prof,stop) for j in CN[ci] if j>=0]+[(side,st,off,cfg,P[j],stop) for j in PN[pi] if j>=0]+[(side,st,off,cfg,prof,S[j]) for j in SN[si] if j>=0]

def _robust(row,x,g,r,curves,curve,files,FG,FR,ys,i0,i1,lots,capital,span,target,floor,max_dd,grid,min_days):
    """Swap each traded leg for its one-step neighbours (other leg and sizes fixed): share of those that pass every gate (in-sample),
    and the share of neighbours whose trades are identical to the chosen leg's (those pass trivially and say nothing)."""
    res=[];same=[]
    for mine,is_green in ((row['_g'],True),(row['_r'],False)):
        if mine is None or not (x['la'] if is_green else x['lb']):continue
        f=files.get(mine)
        if f is None:continue
        me=curves[mine]
        for nk in _neighbour_keys(mine,grid,f):
            c=curve(nk)
            if c['bad']:res.append(False);same.append(False);continue
            same.append(bool(np.array_equal(c['E'],me['E'])))
            Fn=Fold([c],i0,i1,ys,min_days,len(c['E']))
            tot,Y,worst,dd,mg=combo_eval(Fn,FR,[0],[x['r']],[x['la']/lots],[x['lb']/lots],capital,span) if is_green else combo_eval(FG,Fn,[x['g']],[0],[x['la']/lots],[x['lb']/lots],capital,span)
            res.append(bool(tot[0]>=target and worst[0]>=floor and dd[0]<=max_dd and mg[0]<=capital))
    distinct=[p for p,q in zip(res,same) if not q]
    return dict(neighbour_swaps=len(res),neighbour_pass_share=round(sum(res)/len(res),3) if res else None,neighbour_identical_share=round(sum(same)/len(same),3) if same else None,
                neighbour_pass_share_distinct=round(sum(distinct)/len(distinct),3) if distinct else None)

def _csv(path,rows):
    keys=[];[keys.append(k) for r in rows for k in r if k not in keys and not k.startswith('_')]
    with open(path,'w',newline='') as f:w=csv.DictWriter(f,keys,extrasaction='ignore');w.writeheader();w.writerows(rows)

def parse_margin(text):
    out={}
    for part in (text or '').split(','):
        if not part.strip():continue
        k,v=part.split('=');k=k.strip();v=float(v)
        if k=='futures':out['futures_zone']=out['futures_expiry']=v
        elif k in MARGIN:out[k]=v
        else:raise ValueError(f'unknown structure in --margin: {k}')
        if not 0<=v<=1:raise ValueError('--margin rates are shares of notional (0..1)')
    return out

def parse_lots(text,lots):
    if not text:return None
    out=set()
    for part in text.split(','):
        if '-' in part:a,b=part.split('-');out.update(range(int(a),int(b)+1))
        else:out.add(int(part))
    if min(out)<0:raise ValueError('--leg-lots must be >= 0')
    return sorted(out)

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--grid',required=True,help='zone_grid.py output directory');ap.add_argument('--paths',required=True,help='the zone_paths.sqlite the grid was built from')
    ap.add_argument('--out',default='portfolio');ap.add_argument('--capital',type=float,default=CAPITAL)
    ap.add_argument('--target',type=float,default=.22,help='overall yearly return on capital (pre-tax)');ap.add_argument('--floor',type=float,default=.17,help='minimum return in every judged calendar year')
    ap.add_argument('--max-dd',type=float,default=250_000.,help='largest allowed fall of combined daily equity from its peak, rupees')
    ap.add_argument('--rank',choices=('dd','worst_year','calmar'),default='dd');ap.add_argument('--pool',type=int,default=150,help='candidates per side, window and criterion')
    ap.add_argument('--min-trades',type=int,default=15);ap.add_argument('--wf-min-trades',type=int,help='trade minimum in walk-forward training windows (default max(10, min-trades // 2), as the grid)')
    ap.add_argument('--carry',type=float,default=.055);ap.add_argument('--carry-scenarios',default='0,.03,.055,.08');ap.add_argument('--top',type=int,default=50)
    ap.add_argument('--min-year-days',type=int,default=90,help='a part year shorter than this is not annualised and not held to --floor')
    ap.add_argument('--sizing',choices=('constant','actual'),default='constant');ap.add_argument('--ref-units',type=float,default=650.,help='units of a full-size leg under --sizing constant (650 = 10 lots of 65)')
    ap.add_argument('--margin',default='',help='margin as a share of notional per structure, e.g. futures=.12,naked=.12,calendar=.04 (assumptions; defaults shown)')
    ap.add_argument('--leg-lots',help='lots per leg to search, e.g. 0-10 or 0,5,10 (default 0..the paths file --lots); 0 = leg not traded')
    ap.add_argument('--if-none',choices=('cash','closest'),default='cash',help='test year whose training has no passing pair: stay in cash, or trade the closest failing pair (research only)')
    ap.add_argument('--wf-top',type=int,default=10,help='top passing choices whose test-year results are reported per year')
    ap.add_argument('--max-evals',type=int,default=5_000_000,help='cap on combinations given the drawdown / margin computation per window')
    ap.add_argument('--holidays');ap.add_argument('--workers',type=int,default=1)
    a=ap.parse_args(argv)
    if a.capital<=0 or a.max_dd<=0 or a.target<=0:sys.exit('--capital, --max-dd and --target must be positive')
    if a.floor>a.target:sys.exit('--floor above --target: every year would have to beat the overall target')
    if a.pool<1 or a.top<1 or a.wf_top<1 or a.min_trades<1 or a.max_evals<1:sys.exit('--pool, --top, --wf-top, --min-trades and --max-evals must be >= 1')
    if not 1<=a.min_year_days<=366:sys.exit('--min-year-days must be 1..366')
    if a.ref_units<=0:sys.exit('--ref-units must be positive')
    try:margin=parse_margin(a.margin);cs=tuple(float(x) for x in a.carry_scenarios.split(',') if x.strip())
    except ValueError as e:sys.exit(str(e))
    idx=zg.verify(a.grid,a.paths)                                                  # V4.9.1: every grid file's hash, the computation digest and the paths file
    hol=zr.read_holidays(a.holidays) if a.holidays else []
    if sorted(hol)!=sorted(idx.get('holidays',[])):sys.exit('--holidays must be the list the grid was built with')
    with zg.Detail(a.paths) as D:lots=D.target_lots or 10
    try:leg_lots=parse_lots(a.leg_lots,lots)
    except ValueError as e:sys.exit(str(e))
    rep,wf,ins,gates=run(a.grid,a.paths,a.out,a.capital,a.target,a.floor,a.max_dd,a.rank,a.pool,a.min_trades,a.carry,a.top,hol,a.workers,min_days=a.min_year_days,
                         sizing=a.sizing,ref_units=a.ref_units,margin=margin,leg_lots=leg_lots,if_none=a.if_none,wf_top=a.wf_top,wf_min_trades=a.wf_min_trades,carry_scenarios=cs,max_evals=a.max_evals)
    print('\nCombinations passing each gate (training data of each window; drawdown and margin computed for target-and-floor survivors):')
    for g in gates:print(f"  {g['fold']:10} {g.get('combinations',0):>12,}  target {g.get('pass_target',0):>10,}  floor {g.get('pass_floor',0):>10,}  both {g.get('pass_target_and_floor',0):>9,}  "
                         f"drawdown {g.get('pass_drawdown_of_target_and_floor',0):>8,}  margin {g.get('pass_margin_of_target_and_floor',0):>8,}  all {g.get('pass_all',0):>7,}")
    print('\nWalk-forward account (choice made on earlier years only, adopted flat on 1 January):')
    for w in wf:
        r=w.get('account_return');leg=lambda n:'none' if not w.get(f'{n}_lots') else f"{w[n+'_lots']}L {w[n+'_structure']} {w[n+'_offset']:+.0f} {w[n+'_config']} {w[n+'_profit']} {w[n+'_stop']}"
        print(f"  {w['test_year']}: {'n/a' if r is None else f'{r:.1%}'}{'' if w['test_annualised'] else ' (part year, not annualised)'}  {w['decision']}"+
              (f" | green {leg('green')} | red {leg('red')}" if w['traded'] else '')+(f"  [top {w['top_k']}: median {w['top_k_median_return']:.1%}, worst {w['top_k_worst_return']:.1%}]" if w.get('top_k') else ''))
    s=rep.get('walk_forward') or {}
    if s.get('returns'):
        print(f"  mean {s['mean']:.1%}, worst year {s['worst']:.1%}; continuous drawdown Rs {s['continuous_max_drawdown']:,} (largest within a year Rs {s['largest_in_year_drawdown']:,}); "
              f"peak margin Rs {s['peak_margin']:,} ({s['margin_over_capital_sessions']} sessions over capital); {s['cash_years']} cash year(s)")
        print('  futures carry sensitivity (yearly account returns): '+'; '.join(f"{float(k):.1%}: "+', '.join(f'{y} {v:.1%}' for y,v in d.items()) for k,d in s['carry_scenarios'].items()))
    if ins:
        b=ins[0];print(f"\nIn-sample best ({'passes' if b['passed'] else 'closest; none pass'}), fitted to {rep['start']}..{rep['split']}: overall {b['overall']:.1%}, worst year {'n/a' if b['worst_year'] is None else format(b['worst_year'],'.1%')}, "
                       f"drawdown Rs {b['max_drawdown']:,}, peak margin Rs {b['peak_margin']:,}, green {b['green_lots']} lots, red {b['red_lots']} lots, neighbour pass share {b.get('neighbour_pass_share')} (distinct neighbours only: {b.get('neighbour_pass_share_distinct')}, identical: {b.get('neighbour_identical_share')})")
    print(f'-> {a.out}/portfolio_walk_forward.csv, portfolio_account_daily.csv, portfolio_pairs_in_sample.csv, portfolio_gate_counts.csv, portfolio_report.json')

if __name__=='__main__':main()
