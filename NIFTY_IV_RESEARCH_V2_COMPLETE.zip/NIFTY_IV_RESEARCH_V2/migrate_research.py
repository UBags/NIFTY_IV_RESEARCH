#!/usr/bin/env python3
"""Versioned additive migration runner; never writes to market_data schema."""
import argparse,hashlib,os
from pathlib import Path

def run():
 p=argparse.ArgumentParser();p.add_argument('--dry-run',action='store_true');a=p.parse_args()
 scripts=sorted((Path(__file__).parent/'migrations').glob('[0-9]*.sql'))
 for item in scripts:
  sql=item.read_text();print(item.name,hashlib.sha256(sql.encode()).hexdigest())
 if a.dry_run:return
 import psycopg
 conn=psycopg.connect(host=os.getenv('PGHOST','localhost'),port=os.getenv('PGPORT','5432'),
       dbname=os.getenv('PGDATABASE','nifty_data'),user=os.getenv('PGUSER','postgres'),
       password=os.getenv('PGPASSWORD'),connect_timeout=10)
 try:
  with conn.transaction():
   with conn.cursor() as c:
    c.execute("SELECT pg_advisory_xact_lock(hashtext('nifty_research_v2_migrations'))")
    c.execute('CREATE SCHEMA IF NOT EXISTS research_v2')
    c.execute('CREATE TABLE IF NOT EXISTS research_v2.schema_migrations (version TEXT PRIMARY KEY, sha256 TEXT NOT NULL, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())')
    for item in scripts:
     sql=item.read_text();hashval=hashlib.sha256(sql.encode()).hexdigest()
     c.execute('SELECT sha256 FROM research_v2.schema_migrations WHERE version=%s',(item.name,))
     old=c.fetchone()
     if old:
      if old[0]!=hashval:raise RuntimeError(f'Migration changed after applying: {item.name}; refuse')
      print('SKIP',item.name);continue
     if 'market_data.' in sql.lower():
      # Only in a SQL comment. No executable SQL touching market_data.
      statements=[x.strip() for x in sql.splitlines() if not x.strip().startswith('--')]
      if 'market_data.' in '\n'.join(statements).lower():raise RuntimeError('Forbidden market_data DDL')
     c.execute(sql)
     c.execute('INSERT INTO research_v2.schema_migrations(version,sha256) VALUES(%s,%s)',(item.name,hashval))
     print('APPLIED',item.name)
 finally:conn.close()
if __name__=='__main__':run()
