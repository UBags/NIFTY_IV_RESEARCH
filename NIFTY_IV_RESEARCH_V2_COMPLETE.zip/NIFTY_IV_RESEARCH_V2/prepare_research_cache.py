#!/usr/bin/env python3
"""Read-only PostgreSQL -> source-aware SQLite snapshot, NIFTY only.

Run AFTER the NIFTY import finishes; no PostgreSQL DDL. Retain ALL selected
raw option rows and a deterministic canonical view of each vendor's duplicate
minute. No cross-provider merges. Timepoints are INST with next-minute fills.
"""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,os,sqlite3
from pathlib import Path

TIMES=['09:45','09:46','09:47','09:48','09:49','09:50',
       '11:30','11:31','13:30','13:31','15:15','15:16','15:29']
DDL='''
CREATE TABLE meta(name TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE spot(ts TEXT PRIMARY KEY,day TEXT NOT NULL,open REAL,close REAL,
 volume INTEGER,source_id INTEGER,source_row INTEGER);
CREATE TABLE opt_raw (
 provider TEXT NOT NULL,ts TEXT NOT NULL,day TEXT NOT NULL,expiry TEXT NOT NULL,
 strike REAL NOT NULL,cp TEXT NOT NULL,open REAL,high REAL,low REAL,close REAL,
 volume INTEGER,oi INTEGER,source_id INTEGER NOT NULL,source_row INTEGER NOT NULL,
 PRIMARY KEY(source_id,source_row));
CREATE TABLE opt (
 provider TEXT NOT NULL,ts TEXT NOT NULL,day TEXT NOT NULL,expiry TEXT NOT NULL,
 strike REAL NOT NULL,cp TEXT NOT NULL,open REAL,high REAL,low REAL,close REAL,
 volume INTEGER,oi INTEGER,source_id INTEGER NOT NULL,source_row INTEGER NOT NULL,
 PRIMARY KEY(provider,ts,expiry,strike,cp));
CREATE TABLE duplicate_stats(provider TEXT NOT NULL,day TEXT NOT NULL,
 source_rows INTEGER NOT NULL DEFAULT 0,canonical_rows INTEGER NOT NULL DEFAULT 0,
 PRIMARY KEY(provider,day));
CREATE TABLE forward_cache(provider TEXT NOT NULL,ts TEXT NOT NULL,expiry TEXT NOT NULL,
 forward REAL,matched_pairs INTEGER NOT NULL,dispersion_bps REAL,quality TEXT NOT NULL,
 PRIMARY KEY(provider,ts,expiry));
CREATE TABLE greeks_cache(provider TEXT NOT NULL,ts TEXT NOT NULL,expiry TEXT NOT NULL,
 strike REAL NOT NULL,cp TEXT NOT NULL,iv REAL,delta_proxy REAL,gamma_proxy REAL,
 vega REAL,source_id INTEGER NOT NULL,source_row INTEGER NOT NULL,
 PRIMARY KEY(provider,ts,expiry,strike,cp));
'''

SPOT_SQL='''
WITH target AS MATERIALIZED (
 SELECT (d::date + mins.minute) AT TIME ZONE 'Asia/Kolkata' AS ts
 FROM generate_series(%s::date,%s::date,'1 day'::interval) AS d
 CROSS JOIN unnest(%s::time[]) AS mins(minute)
)
SELECT b.bar_time AT TIME ZONE 'Asia/Kolkata' AS local_time, b.trading_day,
 b.open,b.close,b.volume,b.source_file_id,b.source_row_index
FROM market_data.spot_bars b
JOIN target tgt ON b.bar_time=tgt.ts
JOIN market_data.import_files f ON f.file_id=b.source_file_id
WHERE b.symbol='NIFTY' AND b.trading_day BETWEEN %s AND %s
 AND f.dataset='thetrademarkk' AND f.status='completed'
'''
OPT_SQL='''
WITH target AS MATERIALIZED (
 SELECT (d::date + mins.minute) AT TIME ZONE 'Asia/Kolkata' AS ts
 FROM generate_series(%s::date,%s::date,'1 day'::interval) AS d
 CROSS JOIN unnest(%s::time[]) AS mins(minute)
)
SELECT b.bar_time AT TIME ZONE 'Asia/Kolkata' AS local_time,b.trading_day,b.expiry,
 b.strike,b.option_type,b.open,b.high,b.low,b.close,b.volume,b.open_interest,
 b.source_file_id,b.source_row_index,f.dataset
FROM market_data.option_bars b
JOIN target tgt ON b.bar_time=tgt.ts
JOIN market_data.import_files f ON f.file_id=b.source_file_id
WHERE b.underlying='NIFTY' AND b.trading_day BETWEEN %s AND %s
 AND b.option_type IN ('PE','CE') AND b.granularity='1min'
 AND f.dataset IN ('rissin_upstox','thetrademarkk') AND f.status='completed'
'''

def connect():
 import psycopg
 return psycopg.connect(host=os.getenv('PGHOST','localhost'),port=int(os.getenv('PGPORT','5432')),
     dbname=os.getenv('PGDATABASE','nifty_data'),user=os.getenv('PGUSER','postgres'),
     password=os.getenv('PGPASSWORD'),connect_timeout=15)

def ist_time(t):return t.strftime('%Y-%m-%d %H:%M:%S')


def ledger_check(pg,root):
 expected={p.relative_to(root).as_posix() for p in root.glob('NIFTY*.parquet')}
 expected|={p.relative_to(root).as_posix() for p in (root/'india-index-options-1m'/'options'/'NIFTY').glob('*.parquet')}
 spot=root/'india-index-options-1m'/'index'/'NIFTY.parquet'
 if spot.exists():expected.add(spot.relative_to(root).as_posix())
 if not expected:raise SystemExit(f'No NIFTY Parquets found under {root}')
 with pg.cursor() as c:
  c.execute('''SELECT relative_path,status,loaded_rows,expected_rows,file_bytes,mtime_ns
                FROM market_data.import_files''')
  ledger={r[0]:r[1:] for r in c.fetchall()}
 absent=expected-ledger.keys()
 incomplete=[x for x in expected if x in ledger and (ledger[x][0]!='completed' or ledger[x][1]!=ledger[x][2])]
 print(f'NIFTY source files {len(expected)}, missing ledger entries {len(absent)}, incomplete {len(incomplete)}',flush=True)
 if absent:print('Missing:',sorted(absent)[:5])
 if incomplete:print('Incomplete:',sorted(incomplete)[:5])
 digest=hashlib.sha256()
 for key in sorted(expected):digest.update(f'{key}|{ledger.get(key)}\n'.encode())
 return not absent and not incomplete, digest.hexdigest()


def insert_rows(db,rows,kind):
 if kind=='spot':
  db.executemany('''INSERT INTO spot VALUES(?,?,?,?,?,?,?) ON CONFLICT(ts) DO UPDATE SET
    open=excluded.open,close=excluded.close,volume=excluded.volume,
    source_id=excluded.source_id,source_row=excluded.source_row WHERE
    COALESCE(excluded.volume,0)>COALESCE(spot.volume,0) OR
    (COALESCE(excluded.volume,0)=COALESCE(spot.volume,0)
    AND (excluded.source_id,excluded.source_row)>(spot.source_id,spot.source_row))''',rows)
 else:
  db.executemany('INSERT INTO opt_raw VALUES('+','.join('?'*14)+')',rows)
  db.executemany('''INSERT INTO opt VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
   ON CONFLICT(provider,ts,expiry,strike,cp) DO UPDATE SET
   open=excluded.open,high=excluded.high,low=excluded.low,close=excluded.close,
   volume=excluded.volume,oi=excluded.oi,source_id=excluded.source_id,
   source_row=excluded.source_row WHERE
   COALESCE(excluded.volume,0)>COALESCE(opt.volume,0) OR
   (COALESCE(excluded.volume,0)=COALESCE(opt.volume,0) AND
   (excluded.source_id,excluded.source_row)>(opt.source_id,opt.source_row))''',rows)


def extract(pg,sql,db,params,kind,batch=10000):
 count=0
 with pg.cursor(name='nifty_v2_'+kind) as cur:
  cur.itersize=batch;cur.execute(sql,params)
  while True:
   src=cur.fetchmany(batch)
   if not src:break
   if kind=='spot':
    rows=[(ist_time(t),str(day),op,cl,v,sid,ridx) for t,day,op,cl,v,sid,ridx in src]
   else:
    rows=[(provider,ist_time(t),str(day),str(ex),float(k),cp,op,hi,lo,cl,v,oi,sid,ridx)
      for t,day,ex,k,cp,op,hi,lo,cl,v,oi,sid,ridx,provider in src]
   insert_rows(db,rows,kind);db.commit();count+=len(rows)
   if count%200000 < batch:print(f'{kind}: {count:,} source records processed',flush=True)
 return count


def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--root',default=str(Path(__file__).resolve().parent/'NIFTY_Data'))
 ap.add_argument('--from-date',default='2024-10-01');ap.add_argument('--to-date',default='2026-07-01')
 ap.add_argument('--out',default='research_cache_v2.sqlite')
 ap.add_argument('--times',default=','.join(TIMES));ap.add_argument('--check-only',action='store_true')
 ap.add_argument('--force-rebuild',action='store_true');ap.add_argument('--allow-partial',action='store_true',help='DIAGNOSTICS ONLY; no backtesting allowed')
 args=ap.parse_args();root=Path(args.root)
 if not root.exists():ap.error(f'root does not exist: {root}')
 start=dt.date.fromisoformat(args.from_date);end=dt.date.fromisoformat(args.to_date)
 if start>end:ap.error('from-date after to-date')
 times=[dt.time.fromisoformat(x.strip()) for x in args.times.split(',')]
 mandatory={'09:45','09:46','15:15','15:16','15:29'}
 if not mandatory.issubset({x.strftime('%H:%M') for x in times}):ap.error('minimum times missing')
 with connect() as pg:
  complete,digest=ledger_check(pg,root)
  if args.check_only:return
  if not complete and not args.allow_partial:raise SystemExit('Import incomplete. Refusing research snapshot until imports finish.')
  path=Path(args.out)
  if path.exists():
   if not args.force_rebuild:raise SystemExit('Output exists. Use --force-rebuild to replace it.')
   path.unlink()
  path.parent.mkdir(parents=True,exist_ok=True)
  db=sqlite3.connect(path)
  try:
   db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=NORMAL')
   db.executescript(DDL)
   items={'version':'2','cache_complete':'0','research_eligible':'0','source_fingerprint':digest,
          'range_start':str(start),'range_end':str(end),'minutes':','.join(x.strftime('%H:%M') for x in times),
          'partial_import':str(not complete),'source_provenance':'retained in opt_raw and opt'}
   db.executemany('INSERT INTO meta VALUES(?,?)',items.items());db.commit()
   params=(start,end,times,start,end)
   nspot=extract(pg,SPOT_SQL,db,params,'spot')
   nopt=extract(pg,OPT_SQL,db,params,'option')
   db.executescript('''CREATE INDEX opt_lookup ON opt(provider,ts,expiry,strike,cp);
     CREATE INDEX opt_contract ON opt(provider,expiry,strike,cp,ts);
     CREATE INDEX spot_day ON spot(day,ts);
     CREATE INDEX raw_group ON opt_raw(provider,day);
     INSERT INTO duplicate_stats SELECT provider,day,COUNT(*),0 FROM opt_raw GROUP BY provider,day;
     UPDATE duplicate_stats SET canonical_rows=(SELECT COUNT(*) FROM opt
        WHERE opt.provider=duplicate_stats.provider AND opt.day=duplicate_stats.day);''')
   ncan=db.execute('SELECT count(*) FROM opt').fetchone()[0]
   print(f'Loaded spot source={nspot:,}; option raw={nopt:,}; canonical={ncan:,}; duplicate surplus={nopt-ncan:,}')
   ok=complete and nspot>0 and ncan>0
   db.execute("UPDATE meta SET value='1' WHERE name='cache_complete'")
   db.execute('UPDATE meta SET value=? WHERE name=\'research_eligible\'',('1' if ok else '0',))
   db.commit();db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
  finally:db.close()
 print('V2 snapshot complete:',path,'eligible=',ok)
if __name__=='__main__':main()
