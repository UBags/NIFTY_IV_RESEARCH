#!/usr/bin/env python3
"""Read-only V2 SQLite coverage and parity-quality diagnostics, by month/provider."""
import argparse,csv,json,sqlite3
from collections import defaultdict
from datetime import date
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--cache',default='research_cache_v2.sqlite')
 p.add_argument('--out',default='coverage_v2');a=p.parse_args()
 db=sqlite3.connect(a.cache)
 meta=dict(db.execute('SELECT name,value FROM meta'))
 if meta.get('research_eligible')!='1':raise SystemExit('Cache ineligible')
 groups=defaultdict(lambda:dict(raw=0,canonical=0,zero_volume=0,
    eligible_weekly_days=set(),eligible_long_days=set(),paired_days=set(),
    multi_pair_forward=0,single_pair_forward=0,bad_forward=0))
 for provider,day,r,c in db.execute('SELECT provider,day,source_rows,canonical_rows FROM duplicate_stats'):
  g=groups[provider,day[:7]];g['raw']+=r;g['canonical']+=c
 for provider,day,n in db.execute('''SELECT provider,day,COUNT(*) FROM opt
     WHERE COALESCE(volume,0)=0 GROUP BY provider,day'''):
  groups[provider,day[:7]]['zero_volume']+=n
 for prov,ts,ex,q in db.execute('''SELECT provider,ts,expiry,quality FROM forward_cache'''):
  month=ts[:7];g=groups[prov,month]
  if q=='multi_pair':g['multi_pair_forward']+=1
  elif q=='single_pair':g['single_pair_forward']+=1
  else:g['bad_forward']+=1
 # Aggregated same-strike PE availability at 09:45 and paired next-minute fills.
 spot={ts:v for ts,v in db.execute("SELECT ts,close FROM spot WHERE substr(ts,12,5)='09:45'")}
 cp=defaultdict(lambda:defaultdict(set))
 for prov,ts,ex,k,vol in db.execute("""SELECT provider,ts,expiry,strike,volume FROM opt
     WHERE cp='PE' AND substr(ts,12,5)='09:45' AND close>0"""):
  s=spot.get(ts)
  if not s or abs(k-s)>1000 or not vol:continue
  d=ts[:10];days=(date.fromisoformat(ex)-date.fromisoformat(d)).days
  if 1<=days<=8:cp[prov,d]['short'].add(k)
  if 60<=days<=120:cp[prov,d]['long'].add(k)
 for (provider,day),ks in cp.items():
  g=groups[provider,day[:7]]
  if ks.get('short'):g['eligible_weekly_days'].add(day)
  if ks.get('long'):g['eligible_long_days'].add(day)
  if ks.get('short',set()) & ks.get('long',set()):g['paired_days'].add(day)
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 columns=['provider','month','raw_selected','canonical_selected','duplicate_surplus',
   'zero_volume_canonical','weekly_signal_days','long_signal_days','same_strike_pair_days',
   'multi_pair_forwards','single_pair_forwards','failed_forwards']
 with (out/'quality_by_month.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(columns)
  for (prov,month),v in sorted(groups.items()):
   w.writerow([prov,month,v['raw'],v['canonical'],v['raw']-v['canonical'],v['zero_volume'],
    len(v['eligible_weekly_days']),len(v['eligible_long_days']),len(v['paired_days']),
    v['multi_pair_forward'],v['single_pair_forward'],v['bad_forward']])
 summary={'dataset_fingerprint':meta['source_fingerprint'],'metadata':meta,
    'caveats':['Bar volume is not bid/ask liquidity.',
     'Same strike signal does not guarantee actual simultaneous executable fills.',
     'Absence of call-put pairs prevents reliable synthetic forward and IV calculation.']}
 (out/'quality_summary.json').write_text(json.dumps(summary,indent=2))
 print('Created',out/'quality_by_month.csv',out/'quality_summary.json')
if __name__=='__main__':main()
