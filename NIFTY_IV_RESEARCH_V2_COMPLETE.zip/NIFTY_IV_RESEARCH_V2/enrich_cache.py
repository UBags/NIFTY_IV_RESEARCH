#!/usr/bin/env python3
"""Compute expiry-specific parity forwards & IV/Greeks once per option bar.

Read/write local SQLite ONLY. Scans one (provider, timestamp, expiry) group at a
time; null IV when forward or no-arbitrage checks fail. Safe to rerun.
"""
from __future__ import annotations
import argparse,datetime as dt,math,sqlite3
from itertools import groupby
from quant_v2 import implied_forward,implied_vol_batch,black_greeks


def t_years(ex,ts):
 when=dt.datetime.fromisoformat(ts).replace(tzinfo=dt.timezone(dt.timedelta(hours=5,minutes=30)))
 end=dt.datetime.combine(dt.date.fromisoformat(ex),dt.time(15,30),when.tzinfo)
 return (end-when).total_seconds()/(365.25*86400.)

def main():
 p=argparse.ArgumentParser();p.add_argument('--cache',default='research_cache_v2.sqlite');p.add_argument('--rate',type=float,default=.06)
 p.add_argument('--min-pair-volume',type=int,default=1);p.add_argument('--max-parity-bps',type=float,default=40.)
 p.add_argument('--commit-groups',type=int,default=1000);a=p.parse_args()
 db=sqlite3.connect(a.cache);db.row_factory=sqlite3.Row
 meta=dict(db.execute('SELECT name,value FROM meta'))
 if meta.get('research_eligible')!='1':raise SystemExit('Cache not research-eligible')
 # SQLite is local; build transient canonical read index if needed.
 cur=db.execute('''SELECT provider,ts,expiry,strike,cp,close,volume,source_id,source_row
                    FROM opt ORDER BY provider,ts,expiry,strike,cp''')
 spot={row[0]:row[1] for row in db.execute('SELECT ts,close FROM spot WHERE close>0')}
 forward_rows=[];greek_rows=[];n=0;count=0
 for key,g in groupby(cur,key=lambda r:(r[0],r[1],r[2])):
  provider,ts,expiry=key;rows=list(g);s=spot.get(ts);t=t_years(expiry,ts)
  bars={(float(r['strike']),r['cp']):{'close':r['close'],'volume':r['volume']} for r in rows}
  fe=implied_forward(bars,s,t,a.rate,a.min_pair_volume,max_dispersion_bps=a.max_parity_bps) if s and t>0 else None
  f=fe.forward if fe else None
  forward_rows.append((provider,ts,expiry,f,fe.matched_pairs if fe else 0,
       fe.dispersion_bps if fe else None,fe.quality if fe else 'no_spot_or_expired'))
  if f:
   import numpy as np
   strikes=np.array([r['strike'] for r in rows],float)
   cp=np.array([r['cp'] for r in rows]);prices=np.array([r['close'] if r['close'] is not None else np.nan for r in rows])
   ivs=implied_vol_batch(f,strikes,t,prices,cp,rate=a.rate)
   for row,iv in zip(rows,ivs):
    v=float(iv) if math.isfinite(iv) else None
    gr=black_greeks(f,float(row['strike']),t,v,row['cp'],a.rate,s) if v else None
    greek_rows.append((provider,ts,expiry,float(row['strike']),row['cp'],v,
          gr['delta_proxy'] if gr else None,gr['gamma_proxy'] if gr else None,
          gr['vega'] if gr else None,row['source_id'],row['source_row']))
  n+=1
  if n%a.commit_groups==0:
   db.executemany('INSERT OR REPLACE INTO forward_cache VALUES(?,?,?,?,?,?,?)',forward_rows)
   db.executemany('INSERT OR REPLACE INTO greeks_cache VALUES(?,?,?,?,?,?,?,?,?,?,?)',greek_rows)
   count+=len(greek_rows);forward_rows=[];greek_rows=[];db.commit()
   print(f'Expiry/time groups {n:,}, IV rows {count:,}',flush=True)
 if forward_rows or greek_rows:
  db.executemany('INSERT OR REPLACE INTO forward_cache VALUES(?,?,?,?,?,?,?)',forward_rows)
  db.executemany('INSERT OR REPLACE INTO greeks_cache VALUES(?,?,?,?,?,?,?,?,?,?,?)',greek_rows)
  count+=len(greek_rows);db.commit()
 db.execute("INSERT OR REPLACE INTO meta VALUES('enrichment_complete','1')")
 db.execute("INSERT OR REPLACE INTO meta VALUES('enrichment_rate',?)",(str(a.rate),))
 db.execute("INSERT OR REPLACE INTO meta VALUES('enrichment_min_pair_volume',?)",(str(a.min_pair_volume),))
 db.execute("INSERT OR REPLACE INTO meta VALUES('enrichment_max_parity_bps',?)",(str(a.max_parity_bps),))
 cur.close()  # Release active reader before attempting WAL checkpoint.
 db.commit()
 db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
 db.close();print('Enriched groups',n,'greeks',count)
if __name__=='__main__':main()
