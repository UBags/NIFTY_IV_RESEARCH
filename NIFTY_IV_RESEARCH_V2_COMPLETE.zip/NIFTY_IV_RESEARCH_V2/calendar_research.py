#!/usr/bin/env python3
"""NIFTY calendar v2: real option bar legs, parity-IV signals, MTM, rolling writes.

Results are RESEARCH ONLY. OHLC minute candles are not executable bid/ask quotes.
Spot-index hedging is a theoretical proxy, NOT a traded futures position.
"""
from __future__ import annotations
import argparse,datetime as dt,json,hashlib,math,sqlite3
from bisect import bisect_right
from collections import Counter
from functools import lru_cache
from pathlib import Path
from scipy.special import ndtri
from quant_v2 import implied_forward,implied_vol,black_greeks,forward_variance
from contract_specs_v2 import LotMaster

IST=dt.timezone(dt.timedelta(hours=5,minutes=30))
TENORS=(5,15,30,45,60,75,90,120)
CHECKPOINTS=(('11:30','11:31'),('13:30','13:31'),('15:15','15:16'))


def years(ex,day,time):
 when=dt.datetime.combine(dt.date.fromisoformat(day),dt.time.fromisoformat(time),IST)
 end=dt.datetime.combine(dt.date.fromisoformat(ex),dt.time(15,30),IST)
 return (end-when).total_seconds()/(365.25*86400)

def dte(day,ex):return (dt.date.fromisoformat(ex)-dt.date.fromisoformat(day)).days

def is_quote(q,field='close',volume=0):
 return q is not None and q.get(field) is not None and math.isfinite(q[field]) and q[field]>0 and (q.get('volume') or 0)>=volume

class Data:
 def __init__(self,path):
  self.db=sqlite3.connect(path);self.db.row_factory=sqlite3.Row
  self.meta=dict(self.db.execute('SELECT name,value FROM meta'))
  if self.meta.get('version')!='2' or self.meta.get('research_eligible')!='1':
   raise ValueError('V2 research-eligible cache required; see prepare_research_cache.py')
  self.days=[r[0] for r in self.db.execute('''SELECT DISTINCT day FROM spot
       WHERE substr(ts,12,5)='09:45' ORDER BY day''')]
  self.dayset=set(self.days)
  self.enriched=self.meta.get('enrichment_complete')=='1'
 @lru_cache(16000)
 def spot(self,day,minute):
  x=self.db.execute('SELECT * FROM spot WHERE ts=?',(f'{day} {minute}:00',)).fetchone()
  return dict(x) if x else None
 @lru_cache(80)
 def surface(self,provider,day,minute):
  rows=self.db.execute('SELECT * FROM opt WHERE provider=? AND ts=?',(provider,f'{day} {minute}:00')).fetchall()
  out={}
  for x in rows:out.setdefault(x['expiry'],{})[(float(x['strike']),x['cp'])]=dict(x)
  return out
 @lru_cache(30000)
 def opt(self,provider,day,minute,expiry,strike,cp):
  x=self.db.execute('''SELECT * FROM opt WHERE provider=? AND ts=? AND expiry=?
    AND strike=? AND cp=?''',(provider,f'{day} {minute}:00',expiry,float(strike),cp)).fetchone()
  return dict(x) if x else None
 @lru_cache(30000)
 def forward(self,provider,day,minute,expiry,rate,minvol,maxdisp):
  ts=f'{day} {minute}:00'
  if (self.enriched and rate==float(self.meta.get('enrichment_rate','nan'))
      and minvol==int(self.meta.get('enrichment_min_pair_volume','-1'))
      and maxdisp==float(self.meta.get('enrichment_max_parity_bps','nan'))):
   x=self.db.execute('SELECT forward,matched_pairs,dispersion_bps,quality FROM forward_cache WHERE provider=? AND ts=? AND expiry=?',
       (provider,ts,expiry)).fetchone()
   if x:
    return dict(forward=x['forward'],quality=x['quality'],matched_pairs=x['matched_pairs'],dispersion_bps=x['dispersion_bps'])
  s=self.spot(day,minute)
  quotes=self.surface(provider,day,minute).get(expiry,{})
  t=years(expiry,day,minute)
  est=implied_forward(quotes,s['close'],t,rate,minvol,max_dispersion_bps=maxdisp) if s and is_quote(s) and t>0 else None
  if est:return dict(forward=est.forward,quality=est.quality,matched_pairs=est.matched_pairs,dispersion_bps=est.dispersion_bps)
  return dict(forward=None,quality='no_spot',matched_pairs=0,dispersion_bps=None)
 @lru_cache(50000)
 def greek(self,provider,day,minute,ex,k,cp,rate,minvol,disp):
  q=self.opt(provider,day,minute,ex,k,cp)
  s=self.spot(day,minute)
  if not is_quote(q,volume=0) or not is_quote(s):return None
  if (self.enriched and rate==float(self.meta.get('enrichment_rate','nan'))
      and minvol==int(self.meta.get('enrichment_min_pair_volume','-1'))
      and disp==float(self.meta.get('enrichment_max_parity_bps','nan'))):
   x=self.db.execute('''SELECT iv,delta_proxy,gamma_proxy,vega FROM greeks_cache
     WHERE provider=? AND ts=? AND expiry=? AND strike=? AND cp=?''',
     (provider,f'{day} {minute}:00',ex,float(k),cp)).fetchone()
   if x and x['iv'] is not None:return dict(x)
  f=self.forward(provider,day,minute,ex,rate,minvol,disp)['forward']
  t=years(ex,day,minute)
  if not f or t<=0:return None
  iv=implied_vol(f,k,t,q['close'],cp,rate)
  if not iv:return None
  gr=black_greeks(f,k,t,iv,cp,rate,s['close']);gr['iv']=iv
  return gr
 def close(self):self.db.close()


def fill_cash(cp,px,qty,day,cfg):
 """qty positive buys, negative sells; all currency INR and qty index units."""
 if qty==0:return 0.
 if not px or not math.isfinite(px):raise ValueError('invalid fill')
 # Selling receives price - slippage; buying pays price + slippage.
 filled=max(.01,px+(cfg.slippage if qty>0 else -cfg.slippage))
 premium=abs(qty)*filled
 stt=(.000625 if day<'2024-10-01' else .001 if day<'2026-04-01' else .0015)
 levies=premium*(cfg.exchange_bps/10000*(1+cfg.gst)+(cfg.stt if cfg.stt is not None else stt) if qty<0 else cfg.exchange_bps/10000*(1+cfg.gst)+cfg.stamp)
 return -qty*filled-levies-cfg.brokerage*(1+cfg.gst)


def possible_strikes(s,forward,sig,tshort,cfg):
 # Always snap to an exchange strike interval, do not assume all strikes exist.
 for step in cfg.round_steps:
  for val in cfg.strike_values:
   if cfg.strike_mode=='points':target=s+val
   elif cfg.strike_mode=='pct':target=forward*math.exp(val/100)
   elif cfg.strike_mode=='std':target=forward*math.exp(val*sig*math.sqrt(tshort))
   elif cfg.strike_mode=='delta':
    # target put delta: -0.25 -> d1=Phi^-1(0.75)
    if not -1<val<0:continue
    d1=ndtri(1+val)
    target=forward*math.exp(-d1*sig*math.sqrt(tshort)+.5*sig*sig*tshort)
   else:raise ValueError('unknown strike mode')
   k=math.floor(target/step+.5)*step
   if k>0:yield float(k),step,val


def curve(data,provider,chain,day,k,cfg):
 observations=[]
 for ex,qs in chain.items():
  q=qs.get((k,'PE'));t=years(ex,day,'09:45')
  if not is_quote(q,volume=cfg.min_signal_volume) or not (0<t<1):continue
  f=data.forward(provider,day,'09:45',ex,cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)['forward']
  if not f:continue
  sigma=implied_vol(f,k,t,q['close'],'PE',cfg.rate)
  if sigma:observations.append((t*365.25,sigma*sigma*t))
 observations.sort()
 out={}
 for tenor in TENORS:
  below=max((x for x in observations if x[0]<=tenor),default=None,key=lambda x:x[0])
  above=min((x for x in observations if x[0]>=tenor),default=None,key=lambda x:x[0])
  if not below or not above:out[f'iv_{tenor}']=None;continue
  if below[0]==above[0]:var=below[1]
  else:
   weight=(tenor-below[0])/(above[0]-below[0]);var=(1-weight)*below[1]+weight*above[1]
  out[f'iv_{tenor}']=math.sqrt(var/(tenor/365.25)) if var>0 else None
 return out


def generate(data,cfg,stats):
 for day in data.days:
  if not cfg.start<=day<=cfg.end or dt.date.fromisoformat(day).weekday() not in cfg.weekdays:continue
  st=data.spot(day,'09:45');en=data.spot(day,'09:46')
  if not is_quote(st) or not is_quote(en,'open'):stats['missing_spot']+=1;continue
  chain=data.surface(cfg.provider,day,'09:45')
  expiries=sorted((dte(day,ex),ex) for ex in chain if 1<=dte(day,ex)<=cfg.max_short_dte)
  if not expiries:stats['no_short_expiry']+=1;continue
  sd,short_exp=expiries[0]
  f_info=data.forward(cfg.provider,day,'09:45',short_exp,cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
  shortf=f_info['forward']
  if not shortf:stats['no_short_forward']+=1;continue
  # Forward-ATM volatility: nearest liquid put at current short expiry.
  atm_q=sorted(((abs(k-shortf),k,q) for (k,cp),q in chain[short_exp].items()
                if cp=='PE' and is_quote(q,volume=cfg.min_signal_volume)),key=lambda x:x[0])
  if not atm_q:stats['missing_atm_option']+=1;continue
  kt=atm_q[0][1];vol=implied_vol(shortf,kt,years(short_exp,day,'09:45'),atm_q[0][2]['close'],'PE',cfg.rate)
  if not vol:stats['bad_atm_iv']+=1;continue
  seen=set()
  for k,step,val in possible_strikes(st['close'],shortf,vol,years(short_exp,day,'09:45'),cfg):
   if (k,step,val) in seen:continue
   seen.add((k,step,val))
   sq=chain[short_exp].get((k,'PE'))
   if not is_quote(sq,volume=cfg.min_signal_volume):stats['missing_short_signal']+=1;continue
   sv=implied_vol(shortf,k,years(short_exp,day,'09:45'),sq['close'],'PE',cfg.rate)
   if not sv:stats['bad_short_iv']+=1;continue
   vols=curve(data,cfg.provider,chain,day,k,cfg)
   for target in cfg.long_tenors:
    opts=[]
    for ex,quotes in chain.items():
     ld=dte(day,ex)
     if ld>sd and abs(ld-target)<=cfg.tenor_tolerance and is_quote(quotes.get((k,'PE')),volume=cfg.min_signal_volume):
      opts.append((abs(ld-target),ld,ex))
    if not opts:stats['no_long_tenor']+=1;continue
    _,ld,lex=min(opts)
    lf_info=data.forward(cfg.provider,day,'09:45',lex,cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
    lf=lf_info['forward']
    if not lf:stats['no_long_forward']+=1;continue
    lq=chain[lex][(k,'PE')];lv=implied_vol(lf,k,years(lex,day,'09:45'),lq['close'],'PE',cfg.rate)
    if not lv:stats['bad_long_iv']+=1;continue
    lot_s=cfg.lot_master.get(day,short_exp);lot_l=cfg.lot_master.get(day,lex)
    if lot_s.qty is None or lot_l.qty is None:stats['ambiguous_lot_size']+=1;continue
    if lot_s.qty!=lot_l.qty:stats['mismatched_lots']+=1;continue
    t1=years(short_exp,day,'09:45');t2=years(lex,day,'09:45')
    sessions=bisect_right(data.days,short_exp)-bisect_right(data.days,day)
    fwd_vol=forward_variance(sv,lv,t1,t2)
    if fwd_vol is None:stats['nonpositive_forward_variance']+=1;continue
    gs=black_greeks(shortf,k,t1,sv,'PE',cfg.rate,st['close'])
    gl=black_greeks(lf,k,t2,lv,'PE',cfg.rate,st['close'])
    row=dict(day=day,provider=cfg.provider,strike=k,strike_step=step,strike_value=val,
          strike_mode=cfg.strike_mode,short_expiry=short_exp,long_expiry=lex,
          short_dte=sd,long_dte=ld,target_tenor=target,qty=lot_s.qty,
          short_lot_evidence=lot_s.source,long_lot_evidence=lot_l.source,
          short_f=shortf,long_f=lf,short_forward_quality=f_info['quality'],
          long_forward_quality=lf_info['quality'],moneyness_pct=(k/st['close']-1)*100,
          iv_short=sv,iv_long=lv,iv_ratio=sv/lv,iv_spread_pp=(sv-lv)*100,
          forward_iv=fwd_vol,forward_iv_ratio=sv/fwd_vol,
          net_vega=gl['vega']-gs['vega'],
          short_sessions=sessions,short_dte_bucket='1-2' if sessions<=2 else '3-5' if sessions<=5 else '6-8')
    row.update(vols)
    stats['eligible_signals']+=1
    yield row


class Missing(Exception):pass


def require(q,field='open',volume=1,label='option'):
 if not is_quote(q,field,volume):raise Missing('missing_'+label+'_'+field)
 return float(q[field])


def simulate(data,cfg,cand,policy,hedge):
 day=cand['day'];se=cand['short_expiry'];le=cand['long_expiry'];k=cand['strike'];qty=cand['qty']
 provider=cfg.provider
 is_roll=policy=='rolling';is_carry=policy=='carry30'
 if is_roll and hedge!='none':raise Missing('roll_hedge_not_implemented')
 if is_carry and hedge!='none':raise Missing('carry_hedge_not_implemented')
 cash=0.;hedge_pnl=0.;deltahedge=0.;lastspot=0.;curshort=None;gamma_qty=0
 fills=[];gamma_reduction_pct=None
 def book(label,cp,price,units,trade_day,minute):
  flow=fill_cash(cp,price,units,trade_day,cfg)
  fills.append(dict(label=label,day=trade_day,minute=minute,cp=cp,qty=units,
                    observed_price=price,net_cash_flow_inr=flow))
  return flow
 short_sales=0;closed=False;initial_debit=0.;marks=[];mark_quality=[]
 entry_index=data.days.index(day)
 first_buy_long=data.opt(provider,day,'09:46',le,k,'PE')
 first_sell_short=data.opt(provider,day,'09:46',se,k,'PE')
 pxlong=require(first_buy_long,volume=cfg.min_fill_volume,label='long_entry')
 pxshort=require(first_sell_short,volume=cfg.min_fill_volume,label='short_entry')
 initial_debit=(pxlong-pxshort)*qty
 if initial_debit<=cfg.min_debit:raise Missing('nonpositive_initial_debit')
 cash+=book('long_put_buy','PE',pxlong,qty,day,'09:46')+book('weekly_put_sell','PE',pxshort,-qty,day,'09:46')
 curshort=se;short_sales=1
 if hedge=='gamma_reduced_delta_proxy':
  gcall=data.opt(provider,day,'09:46',se,k,'CE')
  gp=require(gcall,volume=cfg.min_fill_volume,label='gamma_entry')
  gs=data.greek(provider,day,'09:45',se,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
  gl=data.greek(provider,day,'09:45',le,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
  gc=data.greek(provider,day,'09:45',se,k,'CE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
  if not gs or not gl or not gc or gc['gamma_proxy']<=1e-10:raise Missing('bad_gamma')
  call_lots=min(cfg.max_gamma_lots,max(0,int(round((gs['gamma_proxy']-gl['gamma_proxy'])/gc['gamma_proxy']))))
  if not call_lots:raise Missing('gamma_rounds_zero')
  gamma_qty=call_lots*qty
  net_before=qty*(gl['gamma_proxy']-gs['gamma_proxy'])
  net_after=net_before+gamma_qty*gc['gamma_proxy']
  gamma_reduction_pct=100*(1-abs(net_after)/max(abs(net_before),1e-12))
  cash+=book('gamma_call_buy','CE',gp,gamma_qty,day,'09:46')
 if hedge!='none':
  s=data.spot(day,'09:46');lastspot=require(s,'open',0,'entry_spot')
  gs=data.greek(provider,day,'09:45',se,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
  gl=data.greek(provider,day,'09:45',le,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
  gc=data.greek(provider,day,'09:45',se,k,'CE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps) if gamma_qty else None
  if not gs or not gl or (gamma_qty and not gc):raise Missing('missing_entry_greeks')
  deltahedge=qty*gs['delta_proxy']-qty*gl['delta_proxy']-gamma_qty*(gc['delta_proxy'] if gc else 0)
  cash-=abs(deltahedge)*lastspot*cfg.hedge_bps/10000
 long_open=True;exit_day='';exit_reason='';missing_marks=0
 for d in data.days[entry_index:]:
  if d>le:break
  si=data.spot(d,'09:46')
  if not si or not is_quote(si,'open'):raise Missing('missing_spot_daily')
  spot_open=si['open']
  if hedge!='none' and d!=day:
   hedge_pnl+=deltahedge*(spot_open-lastspot)
   lastspot=spot_open
   if hedge in ('delta_daily_proxy','gamma_reduced_delta_proxy') and curshort:
    # Rebalance using PRIOR minute signal; never use fill-bar close for Greek.
    gs=data.greek(provider,d,'09:45',curshort,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
    gl=data.greek(provider,d,'09:45',le,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
    gc=data.greek(provider,d,'09:45',se,k,'CE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps) if gamma_qty else None
    if not gs or not gl or (gamma_qty and not gc):raise Missing('missing_hedge_rebalance_greeks')
    desired=qty*gs['delta_proxy']-qty*gl['delta_proxy']-gamma_qty*(gc['delta_proxy'] if gc else 0)
    if abs(desired-deltahedge)>=cfg.delta_band*qty:
     cash-=abs(desired-deltahedge)*spot_open*cfg.hedge_bps/10000
     deltahedge=desired
  # Rolling calendars: issue a second weekly put only after previous one closed.
  if is_roll and d!=day and curshort is None and dte(d,le)>30 and dt.date.fromisoformat(d).weekday() in cfg.weekdays:
   surf=data.surface(provider,d,'09:45')
   avail=sorted((dte(d,e),e) for e,qs in surf.items() if 1<=dte(d,e)<=cfg.max_short_dte
              and is_quote(qs.get((k,'PE')),volume=cfg.min_signal_volume))
   if avail and dte(d,le)>30:
    newexp=avail[0][1]
    if dte(newexp,le)<=30:
     avail=[]
   if avail and dte(d,le)>30:
    lots=cfg.lot_master.get(d,newexp)
    if lots.qty!=qty:raise Missing('rolling_lot_mismatch_or_unknown')
    q=data.opt(provider,d,'09:46',newexp,k,'PE')
    price=require(q,volume=cfg.min_fill_volume,label='rolling_entry')
    cash+=book('rolling_weekly_put_sell','PE',price,-qty,d,'09:46')
    curshort=newexp;short_sales+=1
  # Conditional exits: signal checkpoint close, later same-day minute OPEN fill.
  early_exit=None
  if policy in ('p25_s50','p50_s100','iv_converge') and curshort:
   for sig,fill in CHECKPOINTS:
    so=data.opt(provider,d,sig,curshort,k,'PE');lo=data.opt(provider,d,sig,le,k,'PE')
    if not is_quote(so,volume=cfg.min_mark_volume) or not is_quote(lo,volume=cfg.min_mark_volume):continue
    mark=cash+hedge_pnl+(-qty*so['close']+qty*lo['close'])
    if gamma_qty:
     gg=data.opt(provider,d,sig,se,k,'CE')
     if not is_quote(gg,volume=cfg.min_mark_volume):continue
     mark+=gamma_qty*gg['close']
    if hedge!='none':
     sp=data.spot(d,sig)
     if not is_quote(sp):continue
     mark+=deltahedge*(sp['close']-lastspot)
    trig=False
    if policy.startswith('p'):
     take,stop={'p25_s50':(.25,-.50),'p50_s100':(.50,-1.0)}[policy]
     trig=(mark>=take*initial_debit or mark<=stop*initial_debit)
    elif policy=='iv_converge':
     gs=data.greek(provider,d,sig,curshort,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
     gl=data.greek(provider,d,sig,le,k,'PE',cfg.rate,cfg.min_pair_volume,cfg.max_parity_bps)
     trig=bool(gs and gl and gs['iv']/gl['iv']<=cfg.iv_convergence)
    if trig:early_exit=(fill,'checkpoint_'+policy);break
  # Expiry close before settlement, or exit the long put at <=30DTE.
  short_exit_time=None
  if curshort and (d==curshort or ((is_roll or is_carry) and dte(d,le)<=30)):
   short_exit_time='15:16'
  if early_exit:short_exit_time=early_exit[0]
  if short_exit_time:
   exrow=data.opt(provider,d,short_exit_time,curshort,k,'PE')
   px=require(exrow,volume=cfg.min_exit_volume,label='short_exit')
   cash+=book('weekly_put_buy_to_close','PE',px,qty,d,short_exit_time)
   curshort=None
  end_long=(bool(early_exit) or (not (is_roll or is_carry) and short_exit_time) or
            ((is_roll or is_carry) and dte(d,le)<=30 and curshort is None))
  if end_long:
   fillminute=early_exit[0] if early_exit else '15:16'
   lx=data.opt(provider,d,fillminute,le,k,'PE')
   lp=require(lx,volume=cfg.min_exit_volume,label='long_exit')
   cash+=book('long_put_sell_to_close','PE',lp,-qty,d,fillminute)
   if gamma_qty:
    gg=data.opt(provider,d,fillminute,se,k,'CE')
    cash+=book('gamma_call_sell_to_close','CE',require(gg,volume=cfg.min_exit_volume,label='gamma_exit'),-gamma_qty,d,fillminute)
   if hedge!='none':
    si2=data.spot(d,fillminute);v=require(si2,'open',0,'hedge_exit')
    hedge_pnl+=deltahedge*(v-lastspot)
    cash-=abs(deltahedge)*v*cfg.hedge_bps/10000
   long_open=False;closed=True;exit_day=d
   exit_reason=early_exit[1] if early_exit else ('long_30DTE' if is_roll or is_carry else 'weekly_preclose')
  # Compute mark after every trading session; missing quotes are NOT discarded silently.
  pnl=cash+hedge_pnl
  quality='closed' if closed else 'bar'
  if long_open:
   lm=data.opt(provider,d,'15:29',le,k,'PE')
   if not is_quote(lm,volume=cfg.min_mark_volume):raise Missing('missing_long_daily_mark')
   pnl+=qty*lm['close']
   if curshort:
    sh=data.opt(provider,d,'15:29',curshort,k,'PE')
    if not is_quote(sh,volume=cfg.min_mark_volume):raise Missing('missing_short_daily_mark')
    pnl-=qty*sh['close']
    if (lm['volume'] or 0)==0 or (sh['volume'] or 0)==0:quality='zero_volume_mark'
   elif (lm['volume'] or 0)==0:quality='zero_volume_mark'
   if gamma_qty:
    g=data.opt(provider,d,'15:29',se,k,'CE')
    if not is_quote(g,volume=cfg.min_mark_volume):raise Missing('missing_gamma_daily_mark')
    pnl+=gamma_qty*g['close']
   if hedge!='none':
    sp=data.spot(d,'15:29')
    if not is_quote(sp):raise Missing('missing_hedge_spot_mark')
    pnl+=deltahedge*(sp['close']-lastspot)
  marks.append((d,pnl,quality))
  if closed:break
  if curshort is None and not (is_roll or is_carry):break
 if not closed:raise Missing('unresolved_position_after_cache')
 return dict(cand,hedge=hedge,exit_policy=policy,exit_day=exit_day,exit_reason=exit_reason,
       short_sales=short_sales,gamma_call_units=gamma_qty,
       initial_debit_inr=initial_debit,pnl_inr=cash+hedge_pnl,
       mtm_low_inr=min(x[1] for x in marks),mtm_observations=len(marks),
       zero_volume_marks=sum(x[2]=='zero_volume_mark' for x in marks),
       proxy_hedge=(hedge!='none'),gamma_reduction_pct=gamma_reduction_pct,
       fills=fills,option_cash_flow_inr=sum(f['net_cash_flow_inr'] for f in fills),
       proxy_hedge_net_and_cost_inr=cash+hedge_pnl-sum(f['net_cash_flow_inr'] for f in fills)),marks

RESULT_SQL='''
CREATE TABLE meta(name TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE trades (
 id TEXT PRIMARY KEY,day TEXT NOT NULL,exit_day TEXT NOT NULL,provider TEXT NOT NULL,
 strike_mode TEXT NOT NULL,strike_step INTEGER NOT NULL,strike_value REAL NOT NULL,
 target_tenor INTEGER NOT NULL,hedge TEXT NOT NULL,exit_policy TEXT NOT NULL,
 iv_ratio REAL NOT NULL,forward_iv_ratio REAL NOT NULL,short_dte_bucket TEXT NOT NULL,
 iv5 REAL,iv15 REAL,iv30 REAL,iv45 REAL,iv60 REAL,iv75 REAL,iv90 REAL,iv120 REAL,
 pnl_inr REAL NOT NULL,initial_debit_inr REAL NOT NULL,
 risk_proxy_inr REAL NOT NULL,short_sales INTEGER NOT NULL,observed_marks INTEGER NOT NULL,
 zero_volume_marks INTEGER NOT NULL,details TEXT NOT NULL);
CREATE INDEX trades_filter ON trades(hedge,exit_policy,strike_mode,strike_step,strike_value,target_tenor,day);
CREATE TABLE marks(trade_id TEXT NOT NULL,day TEXT NOT NULL,pnl_inr REAL NOT NULL,
 quality TEXT NOT NULL,PRIMARY KEY(trade_id,day));
CREATE INDEX marks_day ON marks(day);
'''

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--cache',default='research_cache_v2.sqlite');p.add_argument('--out',default='research_trades_v2.sqlite')
 p.add_argument('--provider',choices=('rissin_upstox','thetrademarkk'),default='rissin_upstox')
 p.add_argument('--from-date',dest='start',default='2024-10-01');p.add_argument('--to-date',dest='end',default='2026-07-01')
 p.add_argument('--weekdays',default='2,3,4');p.add_argument('--long-tenors',default='30,45,60,75,90,120')
 p.add_argument('--tenor-tolerance',type=int,default=9);p.add_argument('--max-short-dte',type=int,default=8)
 p.add_argument('--strike-mode',choices=('points','pct','std','delta'),default='points')
 p.add_argument('--round-steps',default='100,500');p.add_argument('--strike-values',default='-500,-250,-100,0,100,250,500')
 p.add_argument('--hedges',default='none,delta_entry_proxy,delta_daily_proxy,gamma_reduced_delta_proxy')
 p.add_argument('--policies',default='weekly,p25_s50,p50_s100,iv_converge,carry30,rolling')
 p.add_argument('--contract-master',default=None,help='CSV trading_day,expiry,lot_size,source for authoritative transition overrides')
 p.add_argument('--min-signal-volume',type=int,default=1);p.add_argument('--min-pair-volume',type=int,default=1)
 p.add_argument('--max-parity-bps',type=float,default=40.)
 p.add_argument('--min-fill-volume',type=int,default=1);p.add_argument('--min-exit-volume',type=int,default=1)
 p.add_argument('--min-mark-volume',type=int,default=0)
 p.add_argument('--rate',type=float,default=.06)
 p.add_argument('--brokerage',type=float,default=20.);p.add_argument('--gst',type=float,default=.18)
 p.add_argument('--exchange-bps',type=float,default=3.5);p.add_argument('--stt',type=float,default=None)
 p.add_argument('--stamp',type=float,default=.00003);p.add_argument('--slippage',type=float,default=.5)
 p.add_argument('--hedge-bps',type=float,default=2.0);p.add_argument('--delta-band',type=float,default=.1)
 p.add_argument('--max-gamma-lots',type=int,default=3);p.add_argument('--iv-convergence',type=float,default=1.)
 p.add_argument('--min-debit',type=float,default=1.);p.add_argument('--max-candidates',type=int,default=0)
 args=p.parse_args();args.weekdays={int(x) for x in args.weekdays.split(',')}
 args.long_tenors=[int(x) for x in args.long_tenors.split(',')]
 args.round_steps=[int(x) for x in args.round_steps.split(',')]
 args.strike_values=[float(x) for x in args.strike_values.split(',')]
 hedges=args.hedges.split(',');policies=args.policies.split(',')
 if set(hedges)-{'none','delta_entry_proxy','delta_daily_proxy','gamma_reduced_delta_proxy'}:p.error('unknown hedge')
 if set(policies)-{'weekly','p25_s50','p50_s100','iv_converge','carry30','rolling'}:p.error('unknown policy')
 args.lot_master=LotMaster(args.contract_master)
 if Path(args.out).exists():raise SystemExit('Output exists: refusing to overwrite prior research run')
 data=Data(args.cache);db=sqlite3.connect(args.out)
 db.executescript(RESULT_SQL);db.execute("INSERT INTO meta VALUES('complete','0')")
 conf={k:v for k,v in vars(args).items() if k!='lot_master'}
 db.execute('INSERT INTO meta VALUES(?,?)',('configuration',json.dumps(conf,default=str)))
 db.execute('INSERT INTO meta VALUES(?,?)',('cache_fingerprint',data.meta['source_fingerprint']))
 db.commit();status=Counter();eligible=0;kept=0
 try:
  for cand in generate(data,args,status):
   eligible+=1
   for pol in policies:
    for hedge in hedges:
     if pol in ('rolling','carry30') and hedge!='none':continue
     key=hashlib.sha256(json.dumps([cand["day"],cand["short_expiry"],cand["long_expiry"],cand["strike"],cand["strike_mode"],cand["strike_step"],cand["strike_value"],cand["target_tenor"],pol,hedge],sort_keys=True).encode()).hexdigest()[:32]
     try:
      result,marks=simulate(data,args,cand,pol,hedge)
     except Missing as err:
      status[str(err)]+=1;continue
     risk_proxy=max(result['initial_debit_inr'],0.)
     db.execute('INSERT INTO trades VALUES('+','.join(['?']*28)+')',
       (key,result['day'],result['exit_day'],result['provider'],result['strike_mode'],result['strike_step'],
        result['strike_value'],result['target_tenor'],hedge,pol,result['iv_ratio'],result['forward_iv_ratio'],result['short_dte_bucket'],
        *(result[f'iv_{x}'] for x in TENORS),result['pnl_inr'],result['initial_debit_inr'],risk_proxy,result['short_sales'],
        result['mtm_observations'],result['zero_volume_marks'],json.dumps(result,default=str)))
     db.executemany('INSERT INTO marks VALUES(?,?,?,?)',((key,d,pnl,q) for d,pnl,q in marks))
     kept+=1
   if eligible%100==0:
    db.commit();print('Candidates',eligible,'simulations',kept,flush=True)
   if args.max_candidates and eligible>=args.max_candidates:break
  db.execute("UPDATE meta SET value='1' WHERE name='complete'")
  db.execute('INSERT INTO meta VALUES(?,?)',('failure_counts',json.dumps(status)))
  db.commit()
 finally:db.close();data.close()
 Path(str(args.out)+'.diagnostics.json').write_text(json.dumps({'signals':eligible,'valid_variants':kept,'rejections':status},indent=2))
 print('V2 simulation finished:',args.out,'signals',eligible,'valid',kept)
 print('Invalid/missing reasons:',status)
if __name__=='__main__':main()
