#!/usr/bin/env python3
"""Train-only ranking with portfolio DAILY MARK-TO-MARKET drawdown.

Ranking never uses final holdout observations. Historical one-minute OHLC,
not executable quotes. All capital proxies exclude SPAN/exposure margin.
"""
from __future__ import annotations
import argparse,csv,datetime as dt,json,math,sqlite3,statistics
from collections import defaultdict
from itertools import combinations
from pathlib import Path


def max_drawdown(series):
 peak=0.;dd=0.
 for x in series:
  peak=max(peak,x);dd=max(dd,peak-x)
 return dd

def selected_trades(rows,max_open):
 # Arbitrary tie-breaking across candidates is deterministic, never by outcome.
 active=[];chosen=[]
 for row in sorted(rows,key=lambda x:(x['day'],x['id'])):
  active=[end for end in active if end>=row['day']]
  if len(active)>=max_open:continue
  active.append(row['exit_day']);chosen.append(row)
 return chosen


def metrics(trades,mark_map,max_open):
 selected=selected_trades(trades,max_open)
 if not selected:return dict(n=0,total_inr=0,mean_inr=0,win_pct=0,mtm_dd_inr=0,daily_sharpe=None,
  monthly_win_pct=None,worst_inr=0,peak_open_debit_proxy=0,days=0)
 first=min(x['day'] for x in selected);last=max(x['exit_day'] for x in selected)
 begin=dt.date.fromisoformat(first);end=dt.date.fromisoformat(last)
 all_days=sorted({day for tid,ms in mark_map.items() for day in ms if first<=day<=last})
 # Mark to end of each observed trading session (not merely trade settlements).
 equity=[];exposures=[]
 for day in all_days:
  value=0.;capital=0.
  for x in selected:
   if day<x['day']:continue
   if day>x['exit_day']:value+=x['pnl_inr']
   else:
    m=mark_map[x['id']].get(day)
    if m is None:raise ValueError('Selected trade missing daily mark: '+x['id']+' '+day)
    value+=m
    capital+=x['risk_proxy_inr']
  equity.append(value);exposures.append(capital)
 increments=[equity[0]]+[b-a for a,b in zip(equity,equity[1:])]
 sharpe=(statistics.mean(increments)/statistics.stdev(increments)*math.sqrt(252)
         if len(increments)>=5 and statistics.stdev(increments)>0 else None)
 months=defaultdict(list)
 for day,val in zip(all_days,equity):months[day[:7]].append(val)
 month_changes=[];prior=0.
 for month,vals in sorted(months.items()):
  month_changes.append(vals[-1]-prior);prior=vals[-1]
 pnl=[x['pnl_inr'] for x in selected]
 return dict(n=len(selected),total_inr=round(sum(pnl),2),mean_inr=round(statistics.mean(pnl),2),
   win_pct=round(100*sum(v>0 for v in pnl)/len(pnl),2),
   mtm_dd_inr=round(max_drawdown(equity),2),
   daily_sharpe=round(sharpe,3) if sharpe is not None else None,
   monthly_win_pct=round(100*sum(x>0 for x in month_changes)/len(month_changes),2) if month_changes else None,
   worst_inr=round(min(pnl),2),peak_open_debit_proxy=round(max(exposures),2) if exposures else 0,
   days=len(all_days),monthly_pnl={k:round(v,2) for k,v in zip(sorted(months),month_changes)})


TENORS=(5,15,30,45,60,75,90,120)
SIGNAL_SQL={'iv_ratio':'iv_ratio','forward_iv_ratio':'forward_iv_ratio'}
SIGNAL_SQL.update({f'{a}_{b}':f'(iv{a}/NULLIF(iv{b},0))' for a,b in combinations(TENORS,2)})

def rows_matching(db,key,signal,lower,upper,where_day,day_param,max_zero):
 query=f'''SELECT id,day,exit_day,provider,strike_mode,strike_step,strike_value,
 target_tenor,hedge,exit_policy,iv_ratio,forward_iv_ratio,short_dte_bucket,pnl_inr,initial_debit_inr,
 risk_proxy_inr,short_sales,observed_marks,zero_volume_marks FROM trades
 WHERE strike_mode=? AND strike_step=? AND strike_value=? AND target_tenor=?
 AND hedge=? AND exit_policy=? AND (?='all' OR short_dte_bucket=?)
 AND {SIGNAL_SQL[signal]}>=? AND {SIGNAL_SQL[signal]}<?
 AND zero_volume_marks<=? AND {where_day} ORDER BY day,id'''
 return [dict(r) for r in db.execute(query,(*key[:6],key[6],key[6],lower,upper,max_zero,*day_param))]


def regimes_from_cache(path):
    """Labels at morning entry from previous 21 EOD closes; no look-ahead."""
    db=sqlite3.connect(path)
    try:
        rows=db.execute("SELECT day,close FROM spot WHERE substr(ts,12,5)='15:29' AND close>0 ORDER BY day").fetchall()
    finally:db.close()
    prices=[];output={}
    for day,close in rows:
        if len(prices)>=21:
            change=prices[-1]/prices[-21]-1.
            trend='up' if change>.02 else 'down' if change<-.02 else 'sideways'
            returns=[math.log(prices[i]/prices[i-1]) for i in range(len(prices)-20,len(prices))]
            sigma=statistics.stdev(returns)*math.sqrt(252) if len(returns)>2 else 0.
            output[day]=trend+'_'+('high_realized_vol' if sigma>=.20 else 'low_realized_vol')
        prices.append(close)
    return output


def regime_summary(rows,regimes):
    groups=defaultdict(list)
    for row in rows:groups[regimes.get(row['day'],'insufficient_history')].append(row['pnl_inr'])
    return {name:{'trades':len(v),'net_inr':round(sum(v),2),
                  'win_pct':round(100*sum(x>0 for x in v)/len(v),2)}
            for name,v in sorted(groups.items())}


def load_marks(db,chosen):
 marks=defaultdict(dict)
 # Only load marks for selected position-capped trades. Avoid giant in-memory dicts.
 for i in range(0,len(chosen),400):
  part=chosen[i:i+400]
  if not part:continue
  placeholders=','.join('?'*len(part))
  for tid,day,pnl in db.execute(f'''SELECT trade_id,day,pnl_inr FROM marks
       WHERE trade_id IN ({placeholders})''',[r['id'] for r in part]):
   marks[tid][day]=pnl
 return marks


def measure(db,rows,max_open):
 chosen=selected_trades(rows,max_open)
 marks=load_marks(db,chosen)
 return metrics(chosen,marks,max_open)


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--trades',default='research_trades_v2.sqlite');p.add_argument('--cache',default='research_cache_v2.sqlite')
 p.add_argument('--split',default='2026-01-01',help='Final untouched holdout starts here')
 p.add_argument('--embargo-days',type=int,default=35)
 p.add_argument('--lower-ratios',default='.8,1.0,1.1,1.2,1.3,1.5')
 p.add_argument('--upper-ratios',default='1.2,1.5,2.0,999')
 p.add_argument('--signals',default='iv_ratio,forward_iv_ratio')
 p.add_argument('--short-dte-buckets',default='all',help='all or comma-separated 1-2,3-5,6-8 buckets')
 p.add_argument('--min-train',type=int,default=25);p.add_argument('--min-holdout',type=int,default=10)
 p.add_argument('--max-open',type=int,default=3);p.add_argument('--max-zero-volume-marks',type=int,default=0)
 p.add_argument('--screen-pool',type=int,default=200,help='Cheap training-only pre-screen before expensive MTM ranking')
 p.add_argument('--top',type=int,default=25);p.add_argument('--out',default='strategy_rankings_v2')
 a=p.parse_args();split=dt.date.fromisoformat(a.split)
 cutoff=(split-dt.timedelta(days=a.embargo_days)).isoformat()
 if a.max_open<=0:p.error('--max-open must be positive')
 if a.min_train<5:p.error('--min-train must be >=5')
 signals=list(SIGNAL_SQL) if a.signals=='all' else [x.strip() for x in a.signals.split(',')]
 if any(x not in SIGNAL_SQL for x in signals):p.error('invalid signal')
 buckets=[x.strip() for x in a.short_dte_buckets.split(',')]
 if any(x not in ('all','1-2','3-5','6-8') for x in buckets):p.error('invalid short DTE bucket')
 lowers=[float(x) for x in a.lower_ratios.split(',')]
 uppers=[float(x) for x in a.upper_ratios.split(',')]
 regimes=regimes_from_cache(a.cache)
 db=sqlite3.connect(a.trades);db.row_factory=sqlite3.Row
 try:
  if dict(db.execute('SELECT name,value FROM meta')).get('complete')!='1':raise SystemExit('Incomplete V2 trade database')
  total=db.execute('SELECT COUNT(*) FROM trades').fetchone()[0]
  if total==0:raise SystemExit('No completed candidate trades; check diagnostics')
  ntrain=db.execute('SELECT COUNT(*) FROM trades WHERE day<? AND exit_day<? AND zero_volume_marks<=?',
       (cutoff,cutoff,a.max_zero_volume_marks)).fetchone()[0]
  ntest=db.execute('SELECT COUNT(*) FROM trades WHERE day>=? AND zero_volume_marks<=?',
       (a.split,a.max_zero_volume_marks)).fetchone()[0]
  if not ntrain:raise SystemExit('No clean training trades before embargo cutoff')
  if not ntest:raise SystemExit('No final holdout trades. Choose split inside historical range.')
  # Cheap group screening. SQL aggregates are TRAIN only; final holdout untouched.
  prelim=[]
  for sig in signals:
   for bucket in buckets:
    for lo in lowers:
     for up in uppers:
      if lo>=up:continue
      query=f'''SELECT strike_mode,strike_step,strike_value,target_tenor,hedge,exit_policy,
        COUNT(*) n,AVG(pnl_inr) m,AVG(pnl_inr*pnl_inr) sq,AVG(initial_debit_inr) debit
        FROM trades WHERE day<? AND exit_day<? AND zero_volume_marks<=?
        AND (?='all' OR short_dte_bucket=?)
        AND {SIGNAL_SQL[sig]}>=? AND {SIGNAL_SQL[sig]}<?
        GROUP BY strike_mode,strike_step,strike_value,target_tenor,hedge,exit_policy
        HAVING COUNT(*)>=?'''
      for r in db.execute(query,(cutoff,cutoff,a.max_zero_volume_marks,bucket,bucket,lo,up,a.min_train)):
       mode,step,value,tenor,hedge,policy,n,mean,mean_sq,debit=r
       sigma=math.sqrt(max(0.,mean_sq-mean*mean))
       screen=(mean-.25*sigma)/max(100.,debit)
       prelim.append((screen,(mode,step,value,tenor,hedge,policy,bucket),sig,lo,up))
  prelim.sort(key=lambda x:x[0],reverse=True)
  print('Cheap train-only candidates:',len(prelim),'; MTM screen pool:',a.screen_pool,flush=True)
  if not prelim:raise SystemExit('No parameter sets meet training count; decrease grid, adjust dates, verify data')
  finalist=[]
  for idx,(screen,key,sig,lo,up) in enumerate(prelim[:a.screen_pool],1):
   trrows=rows_matching(db,key,sig,lo,up,'day<? AND exit_day<?',(cutoff,cutoff),a.max_zero_volume_marks)
   if len(trrows)<a.min_train:continue
   train=measure(db,trrows,a.max_open)
   train['regimes']=regime_summary(selected_trades(trrows,a.max_open),regimes)
   if train['n']<a.min_train:continue
   # Score is computed exclusively from training DAILY MTM.
   capital=max(train['peak_open_debit_proxy'],1.)
   score=(train['total_inr']-.7*train['mtm_dd_inr'])/capital
   score+=.1*((train['monthly_win_pct'] or 0)/100-.5)
   finalist.append((score,key,sig,lo,up,train,screen))
   if idx%50==0:print('MTM scored',idx,flush=True)
  finalist.sort(key=lambda x:(x[0],x[5]['n']),reverse=True)
  results=[];seen=set()
  for score,key,sig,lo,up,train,screen in finalist:
   ident=(key,sig,lo,up)
   if ident in seen:continue
   seen.add(ident)
   tsrows=rows_matching(db,key,sig,lo,up,'day>=?',(a.split,),a.max_zero_volume_marks)
   test=measure(db,tsrows,a.max_open)
   test['regimes']=regime_summary(selected_trades(tsrows,a.max_open),regimes)
   results.append(dict(strategy=dict(zip(('mode','step','value','tenor','hedge','policy','short_dte_bucket'),key)),
     signal=sig,lower=lo,upper=up,train_score=round(score,5),preliminary_score=round(screen,5),
     train=train,holdout=test,holdout_sufficient=test['n']>=a.min_holdout,
     hedge_executable=(key[4]=='none')))
   if len(results)>=a.top:break
 finally:db.close()
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 payload=dict(engine='V2',selection='TRAINING ONLY; holdout never reorders finalists',
   limitations=['Minute OHLC does not establish bid/ask execution',
      'Delta hedges use non-tradeable spot proxy; gamma reduction is NOT exact neutrality',
      'Capital proxy is initial debit and omits SPAN/exposure margin',
      'Exclude zero-volume marks by default; selection bias requires coverage analysis',
      'No profitable-in-all-market-conditions guarantee'],
   train_end_exclusive=cutoff,holdout_start=a.split,embargo_days=a.embargo_days,
   n_input=total,n_train_clean=ntrain,n_test_clean=ntest,n_preliminary_grid=len(prelim),
   n_mtm_qualified=len(finalist),results=results)
 (out/'ranking.json').write_text(json.dumps(payload,indent=2))
 with (out/'ranking.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['rank','mode','step','value','long_tenor','hedge','policy','short_dte_bucket','iv_signal','min','max',
   'train_n','train_net_inr','train_mtm_dd_inr','train_daily_sharpe','train_monthly_win_pct',
   'holdout_n','holdout_net_inr','holdout_mtm_dd_inr','holdout_daily_sharpe','holdout_sufficient'])
  for i,x in enumerate(results,1):
   s=x['strategy'];tr=x['train'];te=x['holdout']
   w.writerow([i,s['mode'],s['step'],s['value'],s['tenor'],s['hedge'],s['policy'],s['short_dte_bucket'],
       x['signal'],x['lower'],x['upper'],tr['n'],tr['total_inr'],tr['mtm_dd_inr'],tr['daily_sharpe'],
       tr['monthly_win_pct'],te['n'],te['total_inr'],te['mtm_dd_inr'],te['daily_sharpe'],x['holdout_sufficient']])
 print('Results:',out/'ranking.csv','test NOT used to rank. No claim of executable live returns.')
if __name__=='__main__':main()
