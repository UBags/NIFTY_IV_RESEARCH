#!/usr/bin/env python3
"""Optional: publish completed V2 ranking JSON to research_v2.* only.

Never modifies market_data.*. Requires running migrate_research.py once.
"""
from __future__ import annotations
import argparse,hashlib,json,os
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--ranking',default='strategy_rankings_v2/ranking.json')
 p.add_argument('--trades',default='research_trades_v2.sqlite');p.add_argument('--name',default='v2_candidate_screen')
 a=p.parse_args()
 ranking=json.loads(Path(a.ranking).read_text())
 import sqlite3,psycopg
 with sqlite3.connect(a.trades) as db:meta=dict(db.execute('SELECT name,value FROM meta'))
 if meta.get('complete')!='1':raise SystemExit('Trade run is incomplete')
 params=json.loads(meta['configuration']);fingerprint=meta['cache_fingerprint']
 with psycopg.connect(host=os.getenv('PGHOST','localhost'),port=os.getenv('PGPORT','5432'),
       dbname=os.getenv('PGDATABASE','nifty_data'),user=os.getenv('PGUSER','postgres'),
       password=os.getenv('PGPASSWORD')) as pg:
  with pg.cursor() as c:
   c.execute("SELECT 1 FROM information_schema.schemata WHERE schema_name='research_v2'")
   if not c.fetchone():raise SystemExit('Run migrate_research.py first')
   from psycopg.types.json import Jsonb
   c.execute('''INSERT INTO research_v2.experiments
      (experiment_name,engine_version,source_manifest_sha256,parameters,lifecycle,notes,completed_at)
      VALUES(%s,'V2',%s,%s,'complete',%s,now()) RETURNING experiment_id''',
      (a.name,fingerprint,Jsonb(params),'Published from immutable local SQLite simulation'))
   run_id=c.fetchone()[0]
   for item in ranking['results']:
    key=json.dumps({'strategy':item['strategy'],'signal':item['signal'],
                    'lower':item['lower'],'upper':item['upper']},sort_keys=True)
    for cohort in ('train','holdout'):
     stats=item[cohort]
     c.execute('''INSERT INTO research_v2.experiment_results
        (experiment_id,strategy_key,sample_name,counts,metrics)
        VALUES(%s,%s,%s,%s,%s)''',
        (run_id,key,cohort,Jsonb({'trades':stats['n']}),Jsonb(stats)))
 print('Published experiment_id:',run_id)
if __name__=='__main__':main()
