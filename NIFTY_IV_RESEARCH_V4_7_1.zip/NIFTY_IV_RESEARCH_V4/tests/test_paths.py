"""Path engine and exit grid tests: where the old engine and the new one model the same thing, they must agree exactly.
Synthetic only; none of this is evidence of profitability."""
import sys,unittest,tempfile,sqlite3,math,datetime as dt,random,collections
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import zone_signals as zs
import zone_backtest as zb
import zone_paths as zp
import zone_grid as zg
import zone_report as zr
from contract_specs_v2 import LotMaster
from tests.test_zone import Market,sessions,walk

def pcfg(**kw):
    a=SimpleNamespace(slippage=0.,brokerage=0.,lots=1,max_participation=.1,min_short_days=4,long_target=60,contract_master=None,max_exit_lag_bars=9,forced_exit_haircut=.02,slippage_points=0.)
    a.__dict__.update(kw);return zp.config(a)

def grid_path(p):
    L=len(p['rows']['cash_total']);return dict(p,rows=zp.unpack(zp.pack(p['rows']),L))

class Paths(Market):
    def paths(self,m,bars,final,entries={0:['bull']},structures=('naked',),cfg=None,offsets=(0,)):
        sim=zp.PathSim(m,bars,final,cfg or pcfg());out=[];sim.run(entries,structures,offsets,sink=out.extend,progress=False);return out,sim
    def test_naked_to_expiry_matches_old_engine(self):
        m=self.build();bars=self.bars_for(self.days);old=self.go(m,bars,['G']*len(bars))[0][0];p=self.paths(m,bars,['G']*len(bars))[0][0]
        self.assertEqual(p['reason'],'expiry');self.assertAlmostEqual(p['end_pnl'],old['pnl_inr'],6)
    def test_zone_flip_matches_old_engine(self):
        m=self.build();bars=self.bars_for(self.days);final=['G']*5+['R']*(len(bars)-5)
        old=self.go(m,bars,final)[0][0];p=self.paths(m,bars,final)[0][0]
        self.assertEqual((p['reason'],p['end_bar']),('zone_flip',5));self.assertAlmostEqual(p['end_pnl'],old['pnl_inr'],6)
        self.assertEqual(p['rows']['exit_bar'][-1],old['exit_bar'])
    def test_calendar_roll_chain_matches_old_engine(self):
        days=sessions('2024-01-02',12);m=self.build(days=days,weekly='2024-01-11',extra=('2024-01-18',));bars=self.bars_for(days);final=['G']*75+['R']*(len(bars)-75)
        tr,_=self.go(m,bars,final,structures=('calendar',));p=self.paths(m,bars,final,structures=('calendar',))[0][0]
        self.assertEqual((p['pairs'],p['reason']),(2,'zone_flip'));self.assertEqual(sum(p['rows']['roll']),1)
        self.assertAlmostEqual(p['end_pnl'],sum(t['pnl_inr'] for t in tr),6)
    def test_spilled_roll_matches_old_engine(self):
        days=sessions('2024-01-02',12);m=self.build(days=days,weekly='2024-01-11',extra=('2024-01-18',))
        m=self.edit("UPDATE opt_1m SET volume=0 WHERE expiry='2024-03-28' AND day='2024-01-11' AND minute>='15:15'")
        bars=self.bars_for(days);final=['G']*85+['R']*(len(bars)-85)
        tr,_=self.go(m,bars,final,structures=('calendar',));sim=zp.PathSim(m,bars,final,pcfg());out=[];sim.run({0:['bull']},('calendar',),(0,),sink=out.extend,progress=False);p=out[0]
        self.assertEqual(sim.counts['roll_exit_spilled'],1);self.assertEqual(p['pairs'],2);self.assertEqual(len(tr),2)
        self.assertEqual(tr[1]['entry_day'],'2024-01-12');self.assertAlmostEqual(p['end_pnl'],sum(t['pnl_inr'] for t in tr),6)
    def test_data_end_is_open_not_unresolved(self):
        days=sessions('2024-01-02',4);m=self.build(days=days);bars=self.bars_for(days);p=self.paths(m,bars,['G']*len(bars))[0][0]
        self.assertEqual((p['status'],p['reason']),('open_at_data_end','open_at_data_end'));self.assertTrue(math.isfinite(p['end_pnl']))
    def test_long_sold_after_short_matches_old_engine(self):
        m=self.build();m=self.edit("UPDATE opt_1m SET volume=0 WHERE expiry='2024-03-28' AND day=? AND minute BETWEEN '12:15' AND '12:24'",(self.days[0],))
        bars=self.bars_for(self.days);final=['G']*3+['R']*(len(bars)-3)
        old=self.go(m,bars,final,structures=('calendar',))[0][0];p=self.paths(m,bars,final,structures=('calendar',))[0][0]
        self.assertAlmostEqual(p['end_pnl'],old['pnl_inr'],6)
    def test_lag_cap_matches_old_engine(self):
        m=self.build();m=self.edit("UPDATE opt_1m SET volume=0 WHERE expiry='2024-03-28' AND (day>? OR minute>'11:00')",(self.days[0],))
        bars=self.bars_for(self.days);final=['G']*3+['R']*(len(bars)-3)
        old=self.go(m,bars,final,structures=('calendar',),cfg=self.cfg(max_exit_lag_bars=2))[0][0]
        p=self.paths(m,bars,final,structures=('calendar',),cfg=pcfg(max_exit_lag_bars=2))[0][0]
        self.assertTrue(old['forced']);self.assertEqual(p['rows']['exit_forced'][-1],1);self.assertAlmostEqual(p['end_pnl'],old['pnl_inr'],6)
    def test_entry_sliced_across_minutes(self):
        m=self.build();lot=LotMaster(None).get(self.days[0],'2024-01-11').qty
        m=self.edit('UPDATE opt_1m SET volume=?',(lot*10,))           # 10% of a minute = one lot
        bars=self.bars_for(self.days);final=['G']*len(bars)
        p=self.paths(m,bars,final,cfg=pcfg(lots=3))[0][0];self.assertEqual((p['status'],p['units']),('closed',3*lot))
        old=self.go(m,bars,final,cfg=self.cfg(lots=3))[0][0];self.assertEqual(old['status'],'no_fill')   # old engine needed 3 lots in ONE minute
        p=self.paths(m,bars,final,cfg=pcfg(lots=46))[0][0];self.assertEqual((p['status'],p['reason']),('no_fill','no_liquid_entry'))   # 45 minutes, one lot each
    def test_entry_price_is_average_of_slices(self):
        m=self.build();lot=LotMaster(None).get(self.days[0],'2024-01-11').qty;m=self.edit('UPDATE opt_1m SET volume=?',(lot*10,))
        m=self.edit("UPDATE opt_1m SET open=open+2,high=high+2,low=low+2,close=close+2 WHERE day=? AND minute='10:01'",(self.days[0],))
        bars=self.bars_for(self.days);sim=zp.PathSim(m,bars,['G']*len(bars),pcfg(lots=2))
        pair,_=sim.open_pair(0,'bull','naked',0);c=pair['held'][0][0]
        p0=m.quote(self.days[0],'10:00',*c)[3];p1=m.quote(self.days[0],'10:01',*c)[3];self.assertGreater(p1,p0+1);self.assertAlmostEqual(pair['px'][c],(p0+p1)/2,6)
    def test_unresolved_when_settlement_missing(self):
        m=self.build();bars=self.bars_for(self.days);m.twap.clear();m.last.clear()
        p=self.paths(m,bars,['G']*len(bars))[0][0];self.assertEqual(p['status'],'unresolved')

class Offline(Market):
    def test_take_profit_read_off_path_matches_old_engine(self):
        days=sessions('2024-01-02',8);lv=lambda d,mm:20000.+(150. if d>=days[2] else 0.)
        m=self.build(days=days,level=lv);bars=self.bars_for(days,lv);final=['G']*len(bars)
        old={t['tp']:t for t in self.go(m,bars,final,tps=(None,.5))[0]}
        sim=zp.PathSim(m,bars,final,pcfg());out=[];sim.run({0:['bull']},('naked',),(0,),sink=out.extend,progress=False)
        db=self.paths_db(bars,final,out);B=zg.Bars(db);o=zg.outcomes(grid_path(out[0]),B,['none','tp50'],['none'],[])
        u=out[0]['units'];self.assertAlmostEqual(o['pnl'][1,0]*u,old[.5]['pnl_inr'],1);self.assertAlmostEqual(o['pnl'][0,0]*u,old[None]['pnl_inr'],1)
    def paths_db(self,bars,final,out):
        db=sqlite3.connect(':memory:');db.executescript(zp.DDL)
        db.executemany('INSERT INTO bars VALUES(?,?,?,?,?,?,?,?)',[(i,b.day,zs.hhmm(b.end),b.open,b.high,b.low,b.close,final[i]) for i,b in enumerate(bars)]);return db
    def atr_case(self):
        days=sessions('2024-01-02',10);lv=lambda d,mm:20000.-(100. if d>=days[4] else 0.)
        m=self.build(days=days,level=lv,weekly='2024-01-18',far='2024-03-28')
        bars=[zs.Bar(b.day,b.start,b.end,b.close,b.close+20,b.close-20,b.close) for b in self.bars_for(days,lv)];return m,bars
    def test_atr_stop_read_off_path_matches_old_engine(self):
        m,bars=self.atr_case();final=['G']*len(bars)
        old=zb.Sim(m,bars,final,self.cfg(atr_mult=1.)).run({20:['bull']},structures=('naked',),offsets=(0,),tps=(None,),stops=(15,),progress=False)[0]
        sim=zp.PathSim(m,bars,final,pcfg());out=[];sim.run({20:['bull']},('naked',),(0,),sink=out.extend,progress=False)
        o=zg.outcomes(grid_path(out[0]),zg.Bars(self.paths_db(bars,final,out)),['none'],['none','atr15x1','atr15x5'],[])
        self.assertEqual(old['reason'],'atr_stop');self.assertAlmostEqual(o['pnl'][0,1]*out[0]['units'],old['pnl_inr'],6)
        self.assertEqual(o['J'][0,2],len(out[0]['rows']['cash_total'])-1)        # wide stop never fires
    def test_boundary_value_matches_old_engine(self):
        m=self.build();bars=self.bars_for(self.days);final=['G']*len(bars)
        old=self.go(m,bars,final,boundaries=(self.days[3],))[0][0]
        sim=zp.PathSim(m,bars,final,pcfg());out=[];sim.run({0:['bull']},('naked',),(0,),sink=out.extend,progress=False)
        o=zg.outcomes(grid_path(out[0]),zg.Bars(self.paths_db(bars,final,out)),['none'],['none'],[dt.date.fromisoformat(self.days[3]).toordinal()])
        self.assertAlmostEqual(float(o['vh'][0,0,0]),old['marks_at'][self.days[3]],3)
    def test_trailing_and_pct_and_target(self):
        B=SimpleNamespace(close=np.array([100.,101,103,102,99,105]),atr={15:np.full(6,1.),30:np.full(6,np.nan),45:np.full(6,1.)})
        rows={k:np.zeros(5) for k in zp.FLOATS};rows['value']=np.full(5,np.nan);rows.update({k:np.zeros(5,np.int64) for k in zp.INTS})
        p=dict(signal_bar=0,rows=rows)
        J=zg.first_hits(['trail15x2','trail15x5','pct1','target15x2','atr30x1','target15x10'],p,B,1)
        self.assertEqual(list(J),[3,4,4,1,4,4])   # trail: 99<103-2 at row 3; pct1: 99 is not below 99; ATR(30) not ready: never
    def test_premium_rules_need_printed_legs(self):
        B=SimpleNamespace(close=np.full(6,100.),atr={p:np.full(6,1.) for p in zg.PERIODS})
        rows={k:np.zeros(5) for k in zp.FLOATS};rows.update({k:np.zeros(5,np.int64) for k in zp.INTS})
        rows['base'][:]=100;rows['cash_pair'][:]=100;rows['value']=np.array([-90.,np.nan,-40,-260,0]);rows['roll'][2]=1
        J=zg.first_hits(['tp50','loss50','loss100'],dict(signal_bar=0,rows=rows),B,1)
        self.assertEqual(list(J),[4,3,3])   # +60 at row 2 is a roll bar (no take-profit there); row 1 has no print; -160 at row 3 hits both loss stops

class Selection(unittest.TestCase):
    def test_sequence_one_position_at_a_time_per_rule(self):
        out=[dict(xb=np.array([[5,1]]),vh=np.array([[[1.,2.]]]),entry_day='2024-02-01'),dict(xb=np.array([[9,9]]),vh=np.array([[[3.,-4.]]]),entry_day='2024-02-02')]
        n,s,w,ss,sk=zg.sequence([0,3],{0:0,3:1},out,[('w','2024-01-01','2025-01-01')],{'2025-01-01':0},(1,2))
        self.assertEqual(n[0].tolist(),[[1,2]]);self.assertEqual(s[0].tolist(),[[1.,-2.]]);self.assertEqual(w[0].tolist(),[[1,1]]);self.assertEqual(sk,1)
    def test_all_configs_at_once_equals_one_by_one(self):
        rnd=np.random.default_rng(5);T=60;shape=(3,4);out=[];idx={}
        for t in range(T):
            if rnd.random()<.2:continue
            idx[t]=len(out);out.append(dict(xb=t+rnd.integers(0,12,shape),vh=rnd.normal(size=(2,)+shape).astype(np.float32),entry_day=f'202{3+t//30}-0{1+t%9}-10'))
        wins=[('a','2023-01-01','2024-01-01'),('b','2023-01-01','2025-01-01')];hi={'2024-01-01':0,'2025-01-01':1}
        sig={c:sorted(rnd.choice(T,15,replace=False).tolist()) for c in range(7)};by=collections.defaultdict(list)
        for c,v in sig.items():
            for t in v:by[t].append(c)
        n,s,w,ss,sk=zg.sequence_all({t:np.array(v) for t,v in by.items()},idx,out,wins,hi,7,shape)
        for c in range(7):
            n1,s1,w1,ss1,_=zg.sequence(sig[c],idx,out,wins,hi,shape)
            self.assertTrue(np.array_equal(n[:,c],n1));self.assertTrue(np.allclose(s[:,c],s1));self.assertTrue(np.array_equal(w[:,c],w1));self.assertTrue(np.allclose(ss[:,c],ss1))
    def test_vectorised_tp_rule_matches_report(self):
        rnd=random.Random(3)
        for _ in range(200):
            P=5;n=[rnd.choice([0,5,40,60]) for _ in range(P)];tot=[rnd.uniform(-50,100) for _ in range(P)];wins=[rnd.randint(0,x) if x else 0 for x in n]
            G=dict(n=np.array(n).reshape(1,1,P,1),total=np.array(tot).reshape(1,1,P,1),wins=np.array(wins).reshape(1,1,P,1),sumsq=np.zeros((1,1,P,1)))
            pick,nn,tt,ww,_,elig=zg.choose(G,0,30,.75,np.array([True]),np.array([True]))
            by={i:dict(n=n[i],total=tot[i],win=wins[i]/n[i] if n[i] else None) for i in range(P)}
            ref=zr.choose_tp(by,.75,30)
            if ref is zr.NO_TP_QUALIFIES:self.assertFalse(elig[0,0]);continue
            self.assertTrue(elig[0,0]);self.assertEqual(int(pick[0,0]),ref)
    def test_rule_labels_parse(self):
        for f in (False,True):
            for lab in zg.profit_rules(f)+zg.stop_rules(f):zg.parse(lab)
        self.assertEqual(len(zg.stop_rules()),61);self.assertEqual(len(zg.profit_rules()),24);self.assertEqual(len(zg.stop_rules(True)),55)
        self.assertEqual(zg.parse('atr30x1.5'),('atr',30,1.5));self.assertEqual(zg.parse('tp25'),('tp',.25));self.assertEqual(zg.parse('loss150'),('loss',1.5))

class Futures(unittest.TestCase):
    def test_futures_path_matches_benchmark(self):
        import zone_futures as zf
        days=sessions('2024-01-02',10);mins=walk(days,drift=.3);bars=zs.aggregate(mins,45);final=['G']*30+['R']*(len(bars)-30)
        listing={d:{'2024-01-11','2024-01-18'} for d in days}
        c=SimpleNamespace(brokerage=0.,gst=.18,hedge_bps=0.,hedge_statutory=False,slippage_points=0.,lots=1,atr_mult=1.,min_short_days=4,contract_master=None)
        ref=[x for x in zf.Futures(bars,final,mins,listing,c).run({2:['bull']},('futures_zone',),(None,)) if x['status']=='closed'][0]
        cfg=pcfg();cfg.hedge_statutory=False
        sim=zp.PathSim(zb.PlanMarket(listing),bars,final,cfg,mins);out=[];sim.run({2:['bull']},('futures_zone',),(0,),sink=out.extend,progress=False)
        self.assertEqual(out[0]['end_bar'],30);self.assertAlmostEqual(out[0]['end_pnl'],ref['pnl_inr'],6)

class EndToEnd(Market):
    def test_grid_files_and_walk_forward_shape(self):
        days=sessions('2024-01-02',12);lv=lambda d,mm:20000.+(80. if d>=days[3] else 0.)
        m=self.build(days=days,level=lv,extra=('2024-01-18',));bars=self.bars_for(days,lv);final=['G']*40+['R']*(len(bars)-40)
        bars=[zs.Bar(b.day,b.start,b.end,b.close,b.close+10,b.close-10,b.close) for b in bars]
        sig={'zone_only_tw2':{'bull':[0,10],'bear':[45]},'N3_k0.25_m8_j0.25_tw2':{'bull':[0,20],'bear':[]}}
        p=Path(tempfile.mkdtemp())/'p.sqlite';db=sqlite3.connect(p);db.executescript(zp.DDL)
        db.executemany('INSERT INTO bars VALUES(?,?,?,?,?,?,?,?)',[(i,b.day,zs.hhmm(b.end),b.open,b.high,b.low,b.close,final[i]) for i,b in enumerate(bars)])
        db.executemany('INSERT INTO signals VALUES(?,?,?)',[(c,s,t) for c,v in sig.items() for s in v for t in v[s]])
        sim=zp.PathSim(m,bars,final,pcfg());sim.run(zb.entry_map(bars,sig,'2024-01-01','2024-12-31'),('naked','calendar'),(0,100),sink=zp.writer(db),progress=False);db.commit();db.close()
        out=Path(tempfile.mkdtemp());zg.run_grid(p,out,'2023-06-01','2025-01-01',progress=False);res=zg.report(out,min_trades=1,paths_db=p)
        z=np.load(out/'grid_bull_naked_+0.npz');self.assertEqual(z['n'].shape,(2,len(z['windows']),24,61));self.assertEqual(z['total'].dtype,np.float64);self.assertEqual(z['sumsq'].dtype,np.float64)
        ci=list(z['configs']).index('N3_k0.25_m8_j0.25_tw2');wi=list(z['windows']).index('train_full')
        self.assertEqual(int(z['n'][ci,wi,0,0]),1)   # signal 20 falls inside the trade from signal 0 (zone holds to bar 40)
        fam=[f for f in res['families'] if f['side']=='bull' and f['structure']=='naked' and f['stops']=='any' and f['configs']=='all'][0]
        self.assertIsNotNone(fam['train_best']);d=fam['train_best_detail'];self.assertEqual(d['n'],fam['train_best']['n']);self.assertAlmostEqual(d['total'],fam['train_best']['total'],0)
        self.assertEqual(res['buy_and_hold']['train_full']['index_start'],20000.)

if __name__=='__main__':unittest.main()


class ReviewV470(Market):
    """Regression tests for the four defects reproduced in the V4.7.0 review (A: spilled roll, B: futures with no exit print,
    C: float32 statistics, D: trailing anchor) and for temporal prefix invariance."""
    def spilled(self,scale_after=None):
        days=sessions('2024-01-02',12);m=self.build(days=days,weekly='2024-01-11',extra=('2024-01-18',))
        m=self.edit("UPDATE opt_1m SET volume=0 WHERE expiry='2024-03-28' AND day='2024-01-11' AND minute>='15:15'")
        if scale_after:m=self.edit("UPDATE opt_1m SET open=open*1.7,high=high*1.7,low=low*1.7,close=close*1.7,volume=volume*3 WHERE day>=?",(scale_after,))
        bars=self.bars_for(days);final=['G']*85+['R']*(len(bars)-85)
        sim=zp.PathSim(m,bars,final,pcfg());out=[];sim.run({0:['bull']},('calendar',),(0,),sink=out.extend,progress=False);return m,bars,final,out[0]
    def test_A_spilled_roll_rows_hold_only_cash_already_received(self):
        m,bars,final,p=self.spilled();R=p['rows'];j=next(i for i,x in enumerate(R['roll']) if x);k=p['first_bar']+j
        self.assertEqual((bars[k].day,bars[k].end),('2024-01-11',915))
        # the wait row at 15:30 has the short buy-back (filled 15:15-15:29) but not the long sold next morning
        self.assertLess(R['cash_total'][j+1],R['cash_total'][j+1]+R['exit_cash'][j+1])
        self.assertGreater(R['exit_bar'][j+1],0);self.assertGreaterEqual(R['exit_bar'][j+1],k+1)
        old=zb.Sim(m,bars,final,self.cfg(),boundaries=('2024-01-12',)).run({0:['bull']},structures=('calendar',),offsets=(0,),tps=(None,),progress=False)
        first=[t for t in old if t['roll']==0][0]
        o=zg.outcomes(grid_path(p),zg.Bars(Offline.paths_db(self,bars,final,[p])),['none'],['none'],[dt.date.fromisoformat('2024-01-12').toordinal()])
        self.assertAlmostEqual(float(o['vh'][0,0,0]),first['marks_at']['2024-01-12'],6)   # as-of value equals the old engine's boundary mark
    def test_A01_prefix_invariance(self):
        cut='2024-01-12';_,bars,_,a=self.spilled();_,_,_,b=self.spilled(scale_after=cut)
        n=sum(1 for i in range(len(a['rows']['mark'])) if bars[a['first_bar']+i].day<cut);self.assertGreater(n,60)
        for k in ('cash_total','cash_pair','base','value','mark','roll','forced_before'):
            np.testing.assert_array_equal(np.asarray(a['rows'][k][:n]),np.asarray(b['rows'][k][:n]),err_msg=k)
        self.assertNotAlmostEqual(a['end_pnl'],b['end_pnl'],2)    # later data does change the outcome
    def test_B_futures_exit_waits_for_a_print(self):
        days=sessions('2024-01-02',2);m=self.build(days=days);bars=self.bars_for(days);final=['G']*2+['R']*(len(bars)-2)
        mins={days[0]:[(600,20000.,20000.,20000.,20000.)]}
        s=zp.PathSim(m,bars,final,pcfg(),mins);s.futures_path(0,'bull','futures_zone');p=s.done[0]
        self.assertEqual(p['status'],'open_at_data_end');self.assertTrue(np.isnan(p['rows']['exit_cash'][-1]))
        mins={days[0]:[(600,20000.,20000.,20000.,20000.)],days[1]:[(700,19900.,19900.,19900.,19900.)]}   # first print after the flip: next day 11:40
        c=pcfg();c.hedge_statutory=False;s=zp.PathSim(m,bars,final,c,mins);s.futures_path(0,'bull','futures_zone');p=s.done[0]
        self.assertEqual((p['status'],p['reason']),('closed','zone_flip'));xb=p['rows']['exit_bar'][-1]
        self.assertEqual((bars[xb].day,bars[xb].end),(days[1],690));self.assertAlmostEqual(p['end_pnl'],(19900-20000)*p['units'],6)
    def test_C_statistics_survive_low_dispersion(self):
        x=np.array([100.+(i%2)*.001 for i in range(1000)]);self.assertTrue(np.isfinite(zg.tstat(len(x),float(x.sum()),float(np.square(x).sum()))))
    def test_D_trailing_stop_starts_at_the_fill(self):
        B=SimpleNamespace(close=np.array([120.,101.,102.,103.]),atr={p:np.ones(4) for p in zg.PERIODS})
        R={k:np.zeros(3) for k in zp.FLOATS};R.update({k:np.zeros(3,dtype=np.int64) for k in zp.INTS});R['value'][:]=np.nan
        J=zg.first_hits(['trail15x2','strail15x2'],dict(signal_bar=0,rows=R,entry_index=100.),B,1)
        self.assertEqual(list(J),[2,0])    # from the fill: never more than 2 below the best close; from the signal: at once
    def test_paths_record_index_at_fill(self):
        days=sessions('2024-01-02',8);lv=lambda d,mm:20000.+(50. if mm>='10:05' else 0.)
        m=self.build(days=days,level=lv);bars=self.bars_for(days,lv)
        mins={d:[(mi,)+(lv(d,zs.hhmm(mi)),)*4 for mi in range(zs.OPEN,zs.CLOSE)] for d in days}
        sim=zp.PathSim(m,bars,['G']*len(bars),pcfg(),mins);out=[];sim.run({0:['bull']},('naked',),(0,),sink=out.extend,progress=False)
        self.assertEqual(out[0]['entry_index'],20000.)          # filled in the 10:00 minute, before the move
