#!/usr/bin/env python3
"""Every strategy the grid tested, checked against three requirements: average yearly return, minimum yearly return, and the largest
open loss of any single trade, all as a share of --capital.

Strategy = side x structure x strike level x signal configuration x profit rule x stop rule (every combination in the grid files of
the groups that pass the fill-rate gate). Trades one position at a time, as the grid sequences them, at the simulated size (V4.9.7:
40% of the margin-table lots).

  yearly return   rupee P&L of the trades ENTERED in that calendar year (each to its exit) / --capital
  requirements    judged on --judge-years (default the in-sample full years 2022, 2023, 2024):
                    mean of those years >= --min-mean (13%), every one >= --min-year (10%),
                    every trade's worst open loss (mark-to-market at 45-minute bar closes, after costs) <= --max-trade-dd (3%)
  also reported   2025 and 2026H1 (annualised): returns, worst trade, and whether those years meet the same requirements

Two stages, so that ~10^8 combinations are feasible:
  1. screen from the grid files: per (configuration, profit, stop) the points per unit of each judged year x that group's median
     units in that year; kept if every year and the mean clear the thresholds less --screen-slack (default 25%: the unit
     conversion is approximate; nothing is lost that is within that margin)
  2. exact: each survivor's trades are replayed from the paths (rupees, entry years, worst open loss of every trade)
Rules with identical trades are reported once (with the number of identical labels). Bar-close marks: intraday lows are not seen,
so true per-trade drawdowns are somewhat deeper. 2025-26 was studied already; the in-sample years decide, the rest is a check."""
import argparse,collections,csv,datetime as dt,hashlib,json,math,sqlite3,statistics as stt,sys,time
from pathlib import Path
import numpy as np
import zone_grid as zg
import zone_rules as zr

def unit_table(paths):
    db=sqlite3.connect(f'file:{paths}?mode=ro',uri=True);u=collections.defaultdict(list)
    for side,st,off,y,units in db.execute("SELECT side,structure,offset,substr(entry_day,1,4),units FROM paths WHERE status!='no_fill' AND units>0"):u[side,st,float(off),y].append(units)
    db.close();return {k:float(stt.median(v)) for k,v in u.items()}

def screen_file(e):
    c=zg._CTX;key=(e['side'],e['structure'],float(e['offset']))
    with np.load(c['grid']/e['file']) as z:
        wn=list(z['windows']);cfg=list(z['configs']);P=list(z['profits']);S=list(z['stops'])
        cols=[wn.index(f'test_{y}') for y in c['years']]
        n=z['n'][:,cols].astype(np.int32);t=z['total'][:,cols]
    u=np.array([c['units'].get(key+(y,),np.nan) for y in c['years']])[None,:,None,None]
    rup=t*u;cap=c['capital'];s=1-c['slack']
    ok=(n.sum(1)>=c['min_trades'])&np.all(rup>=s*c['min_year']*cap,1)&(rup.mean(1)>=s*c['min_mean']*cap)
    ok&=np.isfinite(rup).all(1)
    ci,pi,si=np.nonzero(ok)
    return [(key[0],key[1],key[2],str(cfg[a]),str(P[b]),str(S[d])) for a,b,d in zip(ci,pi,si)]

def evaluate(keys,c):
    """Exact figures of one group's survivors (all keys share side, structure, level)."""
    out=[];sel=lambda k:dict(side=k[0],structure=k[1],offset=k[2],config=k[3],profit=k[4],stop=k[5])
    with zg.Detail(c['paths'],c['holidays'],c['gap_policy']) as D:
        for k in keys:
            tr=D.trades(sel(k),c['start'],c['end'],value_to=c['end'])
            if not tr:continue
            yr=collections.defaultdict(float);worst=0.;bad=0;h=hashlib.sha1()
            for x in tr:
                if not math.isfinite(x['unit']):bad+=1;continue
                r=x['unit']*x['units'];yr[x['entry_day'][:4]]+=r
                m=x['marks'][np.isfinite(x['marks'])];worst=min(worst,float(m.min())*x['units'] if len(m) else 0.,r)
                h.update(repr((x['signal_bar'],x['units'],round(x['unit'],4))).encode())
            out.append(dict(key=k,years=dict(yr),worst_trade=worst,trades=len(tr),unvalued=bad,ident=h.hexdigest(),
                            worst_by_year=_worst_by_year(tr)))
    return out

def _worst_by_year(tr):
    w=collections.defaultdict(float)
    for x in tr:
        if not math.isfinite(x['unit']):continue
        m=x['marks'][np.isfinite(x['marks'])];v=min(float(m.min())*x['units'] if len(m) else 0.,x['unit']*x['units'])
        w[x['entry_day'][:4]]=min(w[x['entry_day'][:4]],v)
    return dict(w)

def _eval_group(item):return evaluate(item,zg._CTX)

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--grid',required=True);ap.add_argument('--paths',required=True);ap.add_argument('--holidays')
    ap.add_argument('--capital',type=float,default=2.5e6,help='base of every percentage (default 25 lakh; 1041667 = one strategy\'s 5/12 allocation)')
    ap.add_argument('--min-mean',type=float,default=.13);ap.add_argument('--min-year',type=float,default=.10);ap.add_argument('--max-trade-dd',type=float,default=.03)
    ap.add_argument('--judge-years',default='2022,2023,2024',help='full calendar years the requirements are judged on (2025 needs no grid window: it is judged in stage 2 only)')
    ap.add_argument('--min-trades',type=int,default=10,help='trades in the judged years (screen)');ap.add_argument('--screen-slack',type=float,default=.25)
    ap.add_argument('--min-fill-rate',type=float,default=zg.MIN_FILL_RATE);ap.add_argument('--end',default='2026-07-01',help='trades entered before this date are replayed')
    ap.add_argument('--max-exact',type=int,default=200000,help='stop with a message if more screen survivors than this (raise it or tighten the screen)')
    ap.add_argument('--workers',type=int,default=4);ap.add_argument('--out',default='strategy_scan.csv')
    a=ap.parse_args(argv);t0=time.time()
    idx=zg.verify(a.grid,a.paths);hol=zr.read_holidays(a.holidays) if a.holidays else []
    judge=[y.strip() for y in a.judge_years.split(',') if y.strip()];gyears=[w[5:] for w,_,_ in idx['windows'] if w.startswith('test_')]
    years=[y for y in judge if y in gyears]
    if not years:sys.exit(f'none of --judge-years {judge} has a grid window ({gyears}): the screen needs at least one')
    units=unit_table(a.paths)
    groups=[e for e in idx['groups'] if zg.testable(e,a.min_fill_rate)]
    zg._CTX.clear();zg._CTX.update(grid=Path(a.grid),years=years,units=units,capital=a.capital,slack=a.screen_slack,min_year=a.min_year,min_mean=a.min_mean,min_trades=a.min_trades)
    surv=[k for part in zg.pool_map(screen_file,groups,a.workers) for k in part];surv=sorted(set(surv))
    print(f'screen: {len(groups)} grid files of testable groups, {len(surv):,} combinations within {a.screen_slack:.0%} of the thresholds on {years} ({time.time()-t0:.0f}s)',flush=True)
    if len(surv)>a.max_exact:sys.exit(f'{len(surv):,} survivors > --max-exact {a.max_exact:,}: tighten --screen-slack or raise --max-exact')
    by=collections.defaultdict(list)
    for k in surv:by[k[:3]].append(k)
    items=[];[items.extend([v[i:i+2000] for i in range(0,len(v),2000)]) for v in by.values()]
    zg._CTX.clear();zg._CTX.update(paths=a.paths,holidays=hol,gap_policy=idx.get('gap_policy','free'),start=idx['start'],end=a.end)
    res=[];done=0
    for part in zg.pool_map(_eval_group,items,a.workers):res+=part;done+=1
    print(f'exact: {len(res):,} strategies replayed ({time.time()-t0:.0f}s)',flush=True)
    cap=a.capital;oos_years=[y for y in ('2025','2026') if y not in judge];ann={'2026':365/181}
    def meets(r,ys):
        v=[r['years'].get(y,0.)/cap*ann.get(y,1.) for y in ys]
        w=min([r['worst_by_year'].get(y,0.) for y in ys] or [0.])
        return v and min(v)>=a.min_year and stt.mean(v)>=a.min_mean and -w<=a.max_trade_dd*cap
    seen={};rows=[]
    for r in sorted(res,key=lambda r:r['key']):
        if not meets(r,judge):continue
        if r['ident'] in seen:seen[r['ident']]['identical_rules']+=1;continue
        k=r['key'];row=dict(side=k[0],structure=k[1],level=int(k[2]),config=k[3],profit=k[4],stop=k[5],trades=r['trades'],identical_rules=1,
            **{f'ret_{y}':round(r['years'].get(y,0.)/cap*ann.get(y,1.),4) for y in sorted(set(judge+oos_years+['2021']))},
            mean_judged=round(stt.mean(r['years'].get(y,0.)/cap*ann.get(y,1.) for y in judge),4),min_judged=round(min(r['years'].get(y,0.)/cap*ann.get(y,1.) for y in judge),4),
            worst_trade_pct_judged=round(min(r['worst_by_year'].get(y,0.) for y in judge)/cap,4),
            worst_trade_pct_oos=round(min([r['worst_by_year'].get(y,0.) for y in oos_years] or [0.])/cap,4),
            oos_meets=bool(oos_years) and bool(meets(r,oos_years)),unvalued=r['unvalued'])
        seen[r['ident']]=row;rows.append(row)
    rows.sort(key=lambda r:(-r['oos_meets'],-r['min_judged'],-r['mean_judged']))
    if rows:
        with open(a.out,'w',newline='') as fh:w=csv.DictWriter(fh,list(rows[0]));w.writeheader();w.writerows(rows)
    print(f"\n{len(rows):,} distinct strategies meet: mean >= {a.min_mean:.0%}, every year >= {a.min_year:.0%} ({', '.join(judge)}), worst trade open loss <= {a.max_trade_dd:.1%} of Rs {cap:,.0f}"
          f"; {sum(r['oos_meets'] for r in rows):,} of them also meet it in {', '.join(oos_years) or '-'} (2026 = Jan-Jun, annualised)")
    pc=lambda v:f'{100*v:.1f}%'
    by_group=collections.Counter((r['side'],r['structure'],r['level']) for r in rows)
    if by_group:print('by group: '+'; '.join(f'{s} {t} {l:+d}: {n}' for (s,t,l),n in sorted(by_group.items())))
    for r in rows[:30]:
        ys=' / '.join(pc(r[f'ret_{y}']) for y in judge);os_=' / '.join(f"{y} {pc(r[f'ret_{y}'])}" for y in oos_years)
        print(f"{'OOS OK ' if r['oos_meets'] else '       '}{r['side']} {r['structure']} {r['level']:+d} {r['config']} {r['profit']}/{r['stop']}: {ys} (mean {pc(r['mean_judged'])}), worst trade {pc(r['worst_trade_pct_judged'])}"
              f" | {os_}, worst trade {pc(r['worst_trade_pct_oos'])}  [{r['trades']} trades, {r['identical_rules']} identical rules]")
    print(f'-> {a.out} ({time.time()-t0:.0f}s)')

if __name__=='__main__':main()
